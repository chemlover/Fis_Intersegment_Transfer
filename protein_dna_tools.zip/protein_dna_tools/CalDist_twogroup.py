import sys
import os
import numpy as np
import math
atom_desc = {'1' : 'P', '2' : 'O5', '3' : 'XXX', '4' : 'XXX', '5' : 'XXX', '6' : 'XXX','7' : 'P_start2','8' : 'XXX','9' : 'XXX','10' : 'P_start1','11' : 'XXX','12' : 'XXX','13' : 'P_end','14' : 'XXX','15' : 'C-Alpha', '16' : 'N', '17' : 'O', '18' : 'C-Beta', '19' : 'H-Beta', '20' : 'C-Prime'}
from math import *
def vector(p1, p2):
    return [p2[0]-p1[0], p2[1]-p1[1], p2[2]-p1[2]]

def vabs(a):
    return sqrt(pow(a[0],2)+pow(a[1],2)+pow(a[2],2))

def sigma_sq(sep):
        return pow((1+sep),0.15)*pow((1+sep), 0.15)

def calc_dist(p1, p2):
        v=vector(p1,p2)
        return vabs(v)

def get_file_len(filename):
    exeline="wc -l "+filename ;
    stdout=os.popen(exeline).readline();
    stdout=stdout.split()
    return int(stdout[0])

def getline_range(filename, line1, line2):
    assert(line1 <= line2)
    nline=line2-line1+1
    exeline="head -n"+str(line2)+" "+filename+" | tail -n"+str(nline) ;
    #print exeline
    stdout=os.popen(exeline).readlines()
    return stdout

def get_natoms(dump_file):
        n = 0
        with open(dump_file) as fopen:
             for line in fopen.readlines():
                 n+= 1
                 if line[0:3] == "END":
                    break
        return n

def get_dump_i(dump_file, i):
        nline=get_natoms(dump_file)-1
        #print nline
        line_start = 1 + nline*i +1; line_end = nline*(i+1) +1
        dump_part=getline_range(dump_file, line_start, line_end)
        return dump_part

def get_protein_len(filename):
    exeline="wc -l" + filename
    stdout=os.popen(exeline).readline()
    stdout=stdout.split()
    return int(stdout[2]-1)

def get_atoms(pdb_part):
    #with open(pdbfile,"r") as fopen:
    #     pdb_part = fopen.readlines()
    ca_atoms = []
    cb_atoms = []
    p_atoms = []
    CB_p = []
    P_d = []
    for line in pdb_part:
        if line.split()[0] != 'END' or line.split()[0] != 'ENDMDL':
           #if line.split()[2] == 'CA' or line.split()[2] == 'S':
           #print linei
           if len(line.split()) > 5:
              x=float(line[30:38])
              y=float(line[38:46])
              z=float(line[46:54])
              resid = int(line[22:26])
              atom = [x,y,z]
              atoms = [atom,resid]
              atoms = atom
           if line[13:15] == "CA":
                 CB_p.append(atoms)
           #elif line[13:15] == "CA" and line[17:20] == "GLY":
           #      CB_p.append(atoms)
           if line[13:14] == "P":
                 P_d.append(atoms)
    print (len(P_d),len(CB_p))
    #print ((CB_p))
    return CB_p,P_d

def compute_bind_site(cb_atoms,p_atoms,cutoff):
    dna_length = int(len(p_atoms)/2)
    p1_atoms  =  p_atoms[0:dna_length]
    p2_atoms  =  p_atoms[dna_length:dna_length*2]
    critia = cutoff**2
    protein_length = len(cb_atoms)
    site_domain = []
    for j in range(dna_length):
        for i in range(protein_length):
          dist1 = (cb_atoms[i][0]-p1_atoms[j][0])**2 + (cb_atoms[i][1]-p1_atoms[j][1])**2 + (cb_atoms[i][2]-p1_atoms[j][2])**2
          dist2 = (cb_atoms[i][0]-p2_atoms[dna_length-1-j][0])**2 + (cb_atoms[i][1]-p2_atoms[dna_length-1-j][1])**2 + (cb_atoms[i][2]-p2_atoms[dna_length-1-j][2])**2
          if dist1 <= critia or dist2 <= critia:
             #print j
             #print dist1
             #print dist2
             site_domain.append(j+2)
             break
    if len(site_domain) == 0:
           site = -1
    else:
           site = sum(site_domain)/len(site_domain)
    return site
def sigma_sq(sep):
        return pow((1+sep),0.15)*pow((1+sep), 0.15)

def caldist_twogroup(ca_atoms,p_atoms,group1,group2):
    ca_atoms1=[]
    ca_atoms2=[]
    for i in range(len(group1)):
        resi = int(group1[i])
        ca_atoms1.append(ca_atoms[resi])
    for i in range(len(group2)):
        resi = int(group2[i])
        ca_atoms2.append(ca_atoms[resi])
    dist1 = 99
    dist2 = 99
    ppdist = 99
    for i in range(len(ca_atoms1)):
        for j in range(len(ca_atoms2)):
            distpp = calc_dist(ca_atoms1[i],ca_atoms2[j])
            if distpp < ppdist:
               ppdist = distpp
    for i in range(len(p_atoms)):
        for j in range(len(ca_atoms1)):
            distpd1 = calc_dist(p_atoms[i],ca_atoms1[j])
            if distpd1 < dist1:
               dist1 = distpd1
        for j in range(len(ca_atoms2)):
            distpd2 = calc_dist(p_atoms[i],ca_atoms2[j])
            if distpd2 < dist2:
               dist2 = distpd2
    return ppdist,dist1,dist2

def cal_Q_PD_ref(ca_atoms,p_atoms,site,refdat):
    [m,n] = np.shape(refdat)
    Qsum = 0
    Q1 = 0
    Q2 = 0
    for i in range(m):
       resi = int(refdat[i][0])
       resj = int(refdat[i][1]+site)
       distij = refdat[i][2]
       Qsum += 1.0
       #print site,resj
       if resj > -1  and resj < len(p_atoms)/2:
        labelij = int(refdat[i][3])
        #if labelij == 0:
        distijs1 = calc_dist(ca_atoms[resi],p_atoms[resj])
        distijs2 = calc_dist(ca_atoms[resi],p_atoms[-resj-1])
        #elif labelij == -1:
        #   distijs1 = calc_dist(ca_atoms[resi],p_atoms[-resj-1])
        #   distijs2 = calc_dist(ca_atoms[resi],p_atoms[resj])
        if labelij == 0:
           dr1 = distij - distijs1
           dr2 = distij - distijs2
        else:
           dr1 = distij - distijs2
           dr2 = distij - distijs1
        #print labelij,distij,distijs1,distijs2,dr1,dr2
        #print dr1,dr2
        #print dr
        #Qsum += 1.0
        Q1 += exp(-dr1*dr1/(2*sigma_sq(abs(resi-resj))))
        Q2 += exp(-dr2*dr2/(2*sigma_sq(abs(resi-resj))))
    Q = np.max([Q1,Q2])
    if Qsum == 0:
       Qret = 0
    else:
       Qret = Q/Qsum
    return Qret

def compute_traj_openmm(dumpfile,group1,group2,name):
    with open(dumpfile,'r') as fopen:
         lines = fopen.readlines()
    file_len       = get_file_len(dumpfile)
    #nline_snapshot = get_nline_snapshot(dumpfile)
    nline_snapshot = get_natoms(dumpfile)-1
    print nline_snapshot
    n_snapshot     = int(file_len / nline_snapshot)
    file_bindsite = open(name,'w')
    for i in range(n_snapshot+1):
        i_dump  = get_dump_i(dumpfile, i)
        ca_atoms,p_atoms= get_atoms(i_dump)
        #site = compute_bind_site(ca_atoms,p_atoms,cutoff)
        #print site
        #if site < 0:
        #   Q = 0
        #else:
        Q = caldist_twogroup(ca_atoms,p_atoms,group1,group2)
        file_bindsite.write(str(Q)+'\n')
    file_bindsite.close()

def main():
    pdbfile = sys.argv[1]
    group1file = sys.argv[2]
    group2file = sys.argv[3]
    name = sys.argv[4]
    group1 = np.loadtxt(group1file)
    group2 = np.loadtxt(group2file)  
    #reffile = sys.argv[3]
    #groups = np.loadtxt(bfile,dtype='int')
    cutoff = 9.5
    #refdat = np.loadtxt(reffile)
    compute_traj_openmm(pdbfile,group1,group2,name)

if __name__ == '__main__':
    main()
