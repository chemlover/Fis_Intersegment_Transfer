import os
import numpy as np
import sys
datafile = sys.argv[1]
pdbfile = sys.argv[2]
data2file =sys.argv[3]
def get_atoms(pdbfile):
    with open(pdbfile,"r") as fopen:
         pdb_part = fopen.readlines()
    atoms = []
    for line in pdb_part:
        if line.split()[0] != 'END':
           if line.split()[0] == "ATOM":
           #print line
              x=float(line[30:38])
              y=float(line[38:46])
              z=float(line[46:54])
              atom = [x,y,z]
              atoms.append(atom)
   # print coord
    return atoms
i = -1
data = ""
atoms = get_atoms(pdbfile)
with open(datafile,"r") as fopen:
     for line in fopen.readlines():
         if len(line.split()) == 8:
            if int(line.split()[3]) < 15:
               i += 1
               #print line[0:25]
               data += line[0:25] + "\t" + str(atoms[i][0]) + "\t" + str(atoms[i][1]) + "\t"+ str(atoms[i][2]) + "\n"
            else:
               data += line
         else:
               data += line
with open(data2file,"w") as fwrite:
     fwrite.writelines(data)

