################################################
#   Calculate local bending angle of a single  #
#   DNA in a dump file			       #
#   Input: dump file		   	       #
#   Output: txt file		   	       #
#	    column: base pair index  	       #
#	    row: snapshot index      	       #
#	    last row: (optional): Average Y/N  #
#		      mean of each base pair   #
#		      local bending angle      #
################################################

import math
import sys
import numpy as np
from math import *

class Atom:
        def __init__(self, id):
                self.id = 0
                self.type = 0
                self.x = x
                self.y = y
                self.z = z

        def read_atom_(self, id, type, x, y, z):
		self.id = id
                self.type = type
                self.x = x
                self.y = y
                self.z = z

def convertx(a,up,low):
	return((up-low)*(a)+low)
def converty(a,up,low):
        return((up-low)*a+low)
def convertz(a,up,low):
        return((up-low)*a+low)
def dumpx(a,up,low):
	return((a-low)/(up-low))
def dumpy(a,up,low):
        return((a-low)/(up-low))
def dumpz(a,up,low):
        return((a-low)/(up-low))
	
def cal_ang(ba,bc):
	cosine_angle = np.dot(ba, bc) / (np.linalg.norm(ba) * np.linalg.norm(bc))
	angle = (np.arccos(cosine_angle)/3.14159265359*180)
	return angle

if len(sys.argv)<3 or len(sys.argv)>5:
        print "\n" + sys.argv[0] + " -Average Y/N <Input_file> <Output_file>"
        exit()
amean = 0
if sys.argv[1]=="-Average":
	if sys.argv[2]=='Y' or sys.argv[2]=='y':
		amean = 1; del sys.argv[1]; del sys.argv[1]
	elif sys.argv[2]=='N' or sys.argv[2]=='n':
		amean = 0; del sys.argv[1]; del sys.argv[1]
	else:
		print "\n" + sys.argv[0] + " -Average Y/N <Input_file> <Output_file_taolao>"
        	exit()
lammps_file = sys.argv[1]
step = []
latom = []
lbox = []
dem = -1
n = -1
lfile = open(lammps_file)
for l in lfile:
	dem = dem+1
	l = l.strip()
	if l[:14]=="ITEM: TIMESTEP":
        	n = n+1
		step.append(n)                
	elif l[:14]=="ITEM: NUMBER O" and dem<100:
		lNatom = dem+1
	elif l[:14]=="ITEM: BOX BOUN":
		Lbox = dem+1
		lbox.append(Lbox)
	elif l[:14]=="ITEM: ATOMS id":
		n = dem+1
		latom.append(n)
	else:
		continue

with open(lammps_file) as f:
	content = f.readlines()

Natom = int(content[lNatom].strip())

low = []
up = []
for k in range(len(step)):
    for i in range(3):
	line = content[lbox[k]+i].strip().split()
	l = float(line[0])
	u = float(line[1])
	low.append(l)
	up.append(u)
low = np.reshape(low,(len(step),3))
up = np.reshape(up,(len(step),3))
x = []
y = []
z = []
result = []
for s in range(len(step)):
	temp = latom[s]
	NP = 0
	for i in range(Natom):		
		line = content[temp+i].strip().split()
		if int(line[1]) == 1:
			NP = NP+1
			x.append(convertx(float(line[2]),up[s][0],low[s][0]))
			y.append(converty(float(line[3]),up[s][1],low[s][1]))
			z.append(convertz(float(line[4]),up[s][2],low[s][2]))
x = np.reshape(x,(len(step),NP))
y = np.reshape(y,(len(step),NP))
z = np.reshape(z,(len(step),NP))

a = []
b = []
c = []
for i in range(len(step)):
	for j in range (NP/2):
		a.append((x[i][j]+x[i][NP-j-1])/2)
		b.append((y[i][j]+y[i][NP-j-1])/2)
		c.append((z[i][j]+z[i][NP-j-1])/2)
a = np.reshape(a,(len(step),NP/2))
b = np.reshape(b,(len(step),NP/2))
c = np.reshape(c,(len(step),NP/2))

result = []
for i in range(len(step)):
	for j in range (0,int((NP/2)/10)):
                k=j*10
		x1 = np.array([a[i][k-2-5],b[i][k-2-5],c[i][k-2-5]])
		x2 = np.array([a[i][k-1],b[i][k-1],c[i][k-1]])
		y1 = np.array([a[i][k+1],b[i][k+1],c[i][k+1]])
		y2 = np.array([a[i][k+2+5],b[i][k+2+5],c[i][k+2+5]])
		ba = x1 - x2
		bc = y1 - y2
		result.append(cal_ang(ba,bc))
result = np.around(np.reshape(result,(len(step),int(NP/20))), decimals=2)
ave = np.around(np.mean(result, axis = 0), decimals=2)
#ti=[]
#for i in range(len(step)):
#         print i
#         print a
#         x1=np.array([a[i][44],b[i][44],c[i][44]])
#         x2=np.array([a[i][54],b[i][54],c[i][54]])
#         y1=np.array([a[i][55],b[i][55],c[i][55]])
#         y2=np.array([a[i][65],b[i][65],c[i][65]])
#         x=x1-x2
#         y=y1-y2
#         a=sqrt((x[0]*y[0] + x[1]*y[1] + y[2]*y[2])**2/((x[0]**2+x[1]**2+x[2]**2)*(y[0]**2+y[1]**2+y[2]**2)))
#         ti.append(a)
#np.savetxt("ti.txt",ti,fmt="%.3f",delimiter="\n")

tcol = []
for i in range(len(result[0])):
	temp = 'bp_' + str(i+3)
	tcol.append(temp)
tcol = np.reshape(tcol,(1,len(tcol)))
result = np.concatenate((tcol,result), axis = 0)
ave = np.reshape(ave,(1,len(ave)))
if amean == 1:
	result = np.concatenate((result, ave))
data = sys.argv[2] + '.dat'
dump = sys.argv[2] + '.lammpstrj'
with open(data,'w') as file:
	for i in range(len(result)):
		temp = ''
		for j in range(len(result[0])):
			temp = temp +str(result[i][j]) + '\t'
		temp = temp.expandtabs(4)
		file.writelines(temp + '\n')
a1=[]
b1=[]
c1=[]
for i in range(len(a)):
	for j in range(len(a[0])):
		a1.append(dumpx(a[i][j],up[i][0],low[i][0]))
		b1.append(dumpy(b[i][j],up[i][1],low[i][1]))
		c1.append(dumpz(c[i][j],up[i][2],low[i][2]))
a1 = np.reshape(a1,(len(step),NP/2))
b1 = np.reshape(b1,(len(step),NP/2))
c1 = np.reshape(c1,(len(step),NP/2))

output = open(dump,'w')
for i in range(len(step)):
	output.write('ITEM: TIMESTEP\n%d\nITEM: NUMBER OF ATOMS\n%d\n'%(i,NP/2))
	output.write('ITEM: BOX BOUNDS ss ss ss\n%4.5f %4.5f\n%4.5f %4.5f\n%4.5f %4.5f\n'%(low[i][0],up[i][0],low[i][1],up[i][1],low[i][2],up[i][2]))
	output.write('ITEM: ATOMS id type xs ys zs\n')
	for j in range(NP/2):
		output.write('%d 20 %s %s %s\n'%(j+1,a1[i][j],b1[i][j],c1[i][j]))

