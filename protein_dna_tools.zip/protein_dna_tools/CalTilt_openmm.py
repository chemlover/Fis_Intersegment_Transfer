import sys
import os
import numpy as np
import math
atom_desc = {'1' : 'P', '2' : 'O5', '3' : 'XXX', '4' : 'XXX', '5' : 'XXX', '6' : 'XXX','7' : 'P_start2','8' : 'XXX','9' : 'XXX','10' : 'P_start1','11' : 'XXX','12' : 'XXX','13' : 'P_end','14' : 'XXX','15' : 'C-Alpha', '16' : 'N', '17' : 'O', '18' : 'C-Beta', '19' : 'H-Beta', '20' : 'C-Prime'}

def vector(p1, p2):
    return [p2[0]-p1[0], p2[1]-p1[1], p2[2]-p1[2]]

def vadd(p1,p2):
    return [p2[0]/2+p1[0]/2, p2[1]/2+p1[1]/2, p2[2]/2+p1[2]/2]

def vmulti(p1,k):
    return [p1[0]*k,p1[1]*k,p1[2]*k]

def vabs(a):
    return math.sqrt(pow(a[0],2)+pow(a[1],2)+pow(a[2],2))

def v_product(p1,p2):
    return p1[0]*p2[0]+p1[1]*p2[1]+p1[2]*p2[2]

def vangle(p1,p2):
    return math.acos(v_product(p1,p2)/vabs(p1)/vabs(p2))*180/3.1415926535

def vproduct(a, b):
    if type(a)==type([]) and type(b)==type([]):
        return a[0]*b[0]+a[1]*b[1]+a[2]*b[2]
    elif type(b)==type([]):
        return [a*b[0], a*b[1], a*b[2]]
    elif type(a)==type([]):
        return [a[0]*b, a[1]*b, a[2]*b]
    return a*b

def vcross_product(a, b):
    cx = a[1]*b[2]-a[2]*b[1]
    cy = a[2]*b[0]-a[0]*b[2]
    cz = a[0]*b[1]-a[1]*b[0]
    return [cx, cy, cz];

def dihedral_angle(v1, v2, v3):
    n1 = vcross_product(v1, v2)
    n2 = vcross_product(v2, v3)
    y = vproduct( vproduct(vabs(v2), v1), n2 )
    x = vproduct( n1, n2 )
    return math.atan2(y, x)

def calc_dihedral_angle(p1, p2, p3, p4):
    v1 = vector(p1, p2)
    v2 = vector(p2, p3)
    v3 = vector(p3, p4)
    return 180*dihedral_angle(v1, v2, v3)/3.14159265358979

def get_file_len(filename):
    exeline="wc -l "+filename ;
    stdout=os.popen(exeline).readline();
    stdout=stdout.split()
    return int(stdout[0])

def getline_range(filename, line1, line2):
    assert(line1 <= line2)
    nline=line2-line1+1
    exeline="head -n"+str(line2)+" "+filename+" | tail -n"+str(nline) ;
    #print exeline
    stdout=os.popen(exeline).readlines()
    return stdout

def get_natoms(dump_file):
        n = 0
        with open(dump_file) as fopen:
             for line in fopen.readlines():
                 n+= 1
                 if line[0:3] == "END":
                    break
        return n

def get_dump_i(dump_file, i):
        nline=get_natoms(dump_file)
        line_start = 1 + nline*i +1; line_end = nline*(i+1) +1
        dump_part=getline_range(dump_file, line_start, line_end)
        return dump_part

def get_protein_len(filename):
    exeline="wc -l" + filename
    stdout=os.popen(exeline).readline()
    stdout=stdout.split()
    return int(stdout[2]-1)

def get_atoms(pdb_part):
    #with open(pdbfile,"r") as fopen:
    #     pdb_part = fopen.readlines()
    ca_atoms = []
    cb_atoms = []
    p_atoms = []
    CB_p = []
    P_d = []
    S_d = []
    for line in pdb_part:
        if line.split()[0] != 'END' or line.split()[0] != 'ENDMDL':
           #if line.split()[2] == 'CA' or line.split()[2] == 'S':
           #print linei
           if len(line.split()) > 5:
              x=float(line[30:38])
              y=float(line[38:46])
              z=float(line[46:54])
              resid = int(line[22:26])
              atom = [x,y,z]
              atoms = [atom,resid]
              atoms = atom
           if line[13:15] == "CB":
                 CB_p.append(atoms)
           elif line[13:15] == "CA" and line[17:20] == "GLY":
                 CB_p.append(atoms)
           if line[13:14] == "S":
                 S_d.append(atoms)
           if line[13:14] == "P":
                 P_d.append(atoms)
    #print (len(P_d),len(CB_p))
    #print ((CB_p))
    return CB_p,P_d,S_d

def Calu_Twist_on_DNA(b_atoms):
    dna_length = int(len(b_atoms)/2)
    b1_atoms  =  b_atoms[0:dna_length]
    b2_atoms  =  b_atoms[dna_length:dna_length*2]
    Twist = ""
    for i in range(dna_length-1):
        b_atom_1 = b_atoms[i]
        b_atom_2 = b_atoms[-1-i]
        b_atomn_1 = b_atoms[i+1]
        b_atomn_2 = b_atoms[-1-i-1]
        b_center = vadd(b_atom_1,b_atom_2)
        b_centern = vadd(b_atomn_1,b_atomn_2)
        zmst=vector(b_center,b_centern)
        ys = vector(b_atom_1,b_atom_2)
        ysn = vector(b_atomn_1,b_atomn_2)
        ys_zmst_z = vcross_product(ys,zmst)
        ysn_p = vector(ysn,vmulti(ys_zmst_z,v_product(ysn,ys_zmst_z)))
        #print v_product(yr,yrn)/(vabs(yr)*vabs(yrn))
        twist = math.acos(v_product(ys,ysn_p)/(vabs(ys)*vabs(ysn_p)))/3.15159*180
        if twist > 180:
           twist = twist - 180
        elif twist < -180:
           twist = twist + 180
        if twist > 0:
           twist = twist
        else:
           twist = 0 - twist
        Twist += str(twist) + " "
    return Twist

    return Twist

def compute_bind_site(cb_atoms,p_atoms,cutoff,groups):
    dna_length = int(len(p_atoms)/2)
    p1_atoms  =  p_atoms[0:dna_length] 
    p2_atoms  =  p_atoms[dna_length:dna_length*2]
    critia = cutoff**2 
    protein_length = len(cb_atoms)
    site_domain = []
    for j in range(dna_length):
        for k in range(len(groups)):
          i=groups[k]-1
          #print cb_atoms[i]
          #print p1_atoms[j]
          #print p2_atoms[dna_length-1-j]
          dist1 = (cb_atoms[i][0]-p1_atoms[j][0])**2 + (cb_atoms[i][1]-p1_atoms[j][1])**2 + (cb_atoms[i][2]-p1_atoms[j][2])**2 
          dist2 = (cb_atoms[i][0]-p2_atoms[dna_length-1-j][0])**2 + (cb_atoms[i][1]-p2_atoms[dna_length-1-j][1])**2 + (cb_atoms[i][2]-p2_atoms[dna_length-1-j][2])**2 
          if dist1 <= critia or dist2 <= critia:
             #print j
             #print dist1
             #print dist2
             site_domain.append(j+2)
             break
    if len(site_domain) == 0:
           site = -1
    else:
           site = sum(site_domain)/len(site_domain)
    #print site_domain
    return site

def compute_bind_site_dump(dumpfile,cutoff,name):
    with open(dumpfile,'r') as fopen:
         lines = fopen.readlines()
    file_len       = get_file_len(dumpfile)
    #nline_snapshot = get_nline_snapshot(dumpfile)
    nline_snapshot = get_natoms(dumpfile)-1
    #print nline_snapshot
    n_snapshot     = int(file_len / nline_snapshot)
    file_bindsite = open(name,'w')
    for i in range(n_snapshot+1):
        i_dump  = get_dump_i(dumpfile, i)
        cb_atoms,p_atoms,s_atoms = get_atoms(i_dump)
        site = Calu_Twist_on_DNA(p_atoms)
        file_bindsite.write(str(site)+'\n')
    file_bindsite.close()

def main():
    pdbfile = sys.argv[1]
    #bfile = sys.argv[2]
    name = sys.argv[2]
    #groups = np.loadtxt(bfile,dtype='int')
    cutoff = 9.5
    compute_bind_site_dump(pdbfile,cutoff,name)

if __name__ == '__main__':
    main()


        
