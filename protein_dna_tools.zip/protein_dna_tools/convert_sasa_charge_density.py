import os
import sys
import numpy as np
sasafile = sys.argv[1]
densityfile = sys.argv[2]
norm = 4/1
sasa = np.loadtxt(sasafile)
[m,n] = np.shape(sasa)
l = int((n+2)/6-1) 
density = np.zeros((m,l))
for i in range(m):
    for j in range(l):
        idstart = 3*j + 2
        density[i][j] =6/(sasa[i][idstart]+sasa[i][-idstart-1]+sasa[i][idstart+1]+sasa[i][-idstart-2]+sasa[i][idstart+2]+sasa[i][-idstart-3])
np.savetxt(densityfile,density,fmt="%.3f",delimiter=" ")
