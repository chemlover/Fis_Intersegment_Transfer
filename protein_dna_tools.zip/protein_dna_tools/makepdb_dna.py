import sys
import os

crdfile = sys.argv[1]
pdbfile = sys.argv[2]
def generate_pdb(crdfile,pdbfile): 
   fileout = open(pdbfile,'w')
   fileout.write("CRYST1\n")     
   with open(crdfile,'r') as fopen:
    for line in fopen.readlines():
     if len(line.split()) == 1:
        atom_num = int(line.split()[0])
     if len(line.split()) > 6:
       items = line.split()
       if float(items[1]) > atom_num/2:
          chainid = str(2)
          id_move = 0
       else:
          chainid = str(1)
          id_move = 0
       if items[0] == str(1):
          linexx  =  ('%s%7s%3s%6s%2s%4s%12.3f%8.3f%8.3f%6.2f%6.2f%10s%s%2s\n'%('ATOM', items[0], items[3], items[2], 'C', int(items[1]),float(items[4])+1.000, float(items[5])+1.000,float(items[6])+1.000, 0.0, 0.0, 'DNA',chainid,'P'))
          fileout.write('%s%7s%3s%6s%2s%4s%12.3f%8.3f%8.3f%6.2f%6.2f%10s%s%2s\n'%('ATOM', items[0], items[3], items[2], 'C', int(items[1]),float(items[4])+1.000, float(items[5])+1.000,float(items[6])+1.000, 0.0, 0.0, 'DNA',chainid,'P'))  
       if items[0] == str(int(atom_num/2)):
          linexx = ('%s%7s%3s%6s%2s%4s%12.3f%8.3f%8.3f%6.2f%6.2f%10s%s%2s\n'%('ATOM', items[0], items[3], items[2], 'C', int(items[1]),float(items[4])+1.000, float(items[5])+1.000,float(items[6])+1.000, 0.0, 0.0, 'DNA',chainid,'P'))
          fileout.write('%s%7s%3s%6s%2s%4s%12.3f%8.3f%8.3f%6.2f%6.2f%10s%s%2s\n'%('ATOM', items[0], items[3], items[2], 'C', int(items[1])+1,float(items[4])+1.000, float(items[5])+1.000,float(items[6])+1.000, 0.0, 0.0, 'DNA',chainid,'P'))   
       if items[3] == 'S' or items[3] == 'P': 
          linexx = ('%s%7s%3s%6s%2s%4s%12.3f%8.3f%8.3f%6.2f%6.2f%10s%s%2s\n'%('ATOM', items[0], items[3], items[2], 'C', int(items[1])+id_move,float(items[4]), float(items[5]),float(items[6]), 0.0, 0.0, 'DNA',chainid,items[3]))
          fileout.write('%s%7s%3s%6s%2s%4s%12.3f%8.3f%8.3f%6.2f%6.2f%10s%s%2s\n'%('ATOM', items[0], items[3], items[2], 'C', int(items[1])+id_move,float(items[4]), float(items[5]),float(items[6]), 0.0, 0.0, 'DNA',chainid,items[3]))
       else:
          linexx = ('%s%7s%3s%6s%2s%4s%12.3f%8.3f%8.3f%6.2f%6.2f%10s%s\n'%('ATOM', items[0], items[3], items[2], 'C', int(items[1])+id_move,float(items[4]), float(items[5]),float(items[6]), 0.0, 0.0, 'DNA',chainid))
          fileout.write('%s%7s%3s%6s%2s%4s%12.3f%8.3f%8.3f%6.2f%6.2f%10s%s\n'%('ATOM', items[0], items[3], items[2], 'C', int(items[1])+id_move,float(items[4]), float(items[5]),float(items[6]), 0.0, 0.0, 'DNA',chainid))         
       print linexx
       print line  
   fileout.write('END\n')
   fileout.close()

if __name__ == '__main__':
    generate_pdb(crdfile,pdbfile)

