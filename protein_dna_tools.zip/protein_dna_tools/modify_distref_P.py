import os
import sys
import numpy as np
inputfile = sys.argv[1]
outputfile = sys.argv[2]
startid = int(sys.argv[3])
endid = int(sys.argv[4])
delta_change = int(sys.argv[5])
data = ""
with open(inputfile,"r") as fopen:
     for line in fopen.readlines():
         stdenv = line.split()
         if len(stdenv) > 2:
            if int(stdenv[0]) > startid -1 and int(stdenv[0]) < endid +1:
               newstdenv1 = str(int(stdenv[0])+delta_change)
            else:
               newstdenv1 = stdenv[0]
            if int(stdenv[1]) > startid -1 and int(stdenv[1]) < endid +1:
               newstdenv2 = str(int(stdenv[1])+delta_change)
            else:
               newstdenv2 = stdenv[0]
         data += newstdenv1 + " " + newstdenv2 + " "
         for i in range(2,len(stdenv)):
             data += stdenv[i] + " "
         data += "\n"
with open(outputfile,"w") as fwrite:
     fwrite.writelines(data)

