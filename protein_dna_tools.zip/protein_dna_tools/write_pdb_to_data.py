import os
import numpy as np
import sys
datafile = sys.argv[1]
pdbfile = sys.argv[2]
datafile2 = sys.argv[3]
data = ""
chains=["A","B","C","D","E","F"]
with open(datafile,"r") as fopen:
     datalines = fopen.readlines()
with open(pdbfile,"r") as fopen:
     pdblines = fopen.readlines()
for dataline in datalines:
    datastdenv = dataline.split()
    #dataatomid = int(datastdenv[1])
    if len(datastdenv) == 8:
       #datastdenv = dataline.split()
       dataatomid = int(datastdenv[0])
       #print datastdenv[0]
       for pdbline in pdblines:
           pdbstdenv = pdbline.split()
           pdbatomid = int(pdbstdenv[1])   
       #    print pdbatomid
           if dataatomid == pdbatomid: 
              print pdbatomid,dataatomid
              #x = (pdbstdenv[6])
              #y = (pdbstdenv[7])
              #z = (pdbstdenv[8])
              x=float(pdbline[30:38])
              y=float(pdbline[38:46])
              z=float(pdbline[46:54])
              print x,y,z
              print "        " + datastdenv[0] + "      "+ datastdenv[1] + "      "+ datastdenv[2] + "      "+ datastdenv[3] + "      "+ datastdenv[4]
              data += "        " + datastdenv[0] + "      "+ datastdenv[1] + "      "+ datastdenv[2] + "      "+ datastdenv[3] + "      "+ datastdenv[4] + "      " + str(x) + "      " + str(y) + "      " + str(z) + "\n"
              break
            #print chains[chainid]11
            #print chainid1
            #data += "ATOM" + str(atomid).rjust(7," ") + "  CA  FIS " + chains[chainid] + str(resid).rjust(4," ") + "    " + str(round(x,3)).rjust(8," ") + str(round(y,3)).rjust(8," ") + str(round(z,3)).rjust(8," ") + "\n"
    else:
              data += dataline
with open(datafile2,"w") as fwrite:
     fwrite.writelines(data)          

