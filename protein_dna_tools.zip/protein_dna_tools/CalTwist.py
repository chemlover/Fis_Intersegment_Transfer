import sys
import os
import numpy as np
import math
atom_desc = {'1' : 'P', '2' : 'O5', '3' : 'XXX', '4' : 'XXX', '5' : 'XXX', '6' : 'XXX','7' : 'XXX','8' : 'XXX','9' : 'XXX','10' : 'XXX','11' : 'XXX','12' : 'XXX','13' : 'XXX','14' : 'XXX','15' : 'C-Alpha', '16' : 'N', '17' : 'O', '18' : 'C-Beta', '19' : 'H-Beta', '20' : 'C-Prime'}


def get_file_len(filename):
    exeline="wc -l "+filename ;
    stdout=os.popen(exeline).readline();
    stdout=stdout.split()
    return int(stdout[0])

def getline_range(filename, line1, line2):
    assert(line1 <= line2)
    nline=line2-line1+1
    exeline="head -n"+str(line2)+" "+filename+" | tail -n"+str(nline) ;
    #print exeline
    stdout=os.popen(exeline).readlines()
    return stdout

def get_natoms(dump_file):
        line=getline_range(dump_file, 4,4); line=line[0].split()
        natoms=int(line[0])
        return natoms

def get_nline_snapshot(dump_file):
        natoms=get_natoms(dump_file)
        nline=natoms + 9
        return nline

def get_dump_i(dump_file, i):
        nline=get_nline_snapshot(dump_file)
        line_start = 1 + nline*i ; line_end = nline*(i+1)
        dump_part=getline_range(dump_file, line_start, line_end)
        return dump_part

def get_protein_len(filename):
    exeline="wc -l" + filename
    stdout=os.popen(exeline).readline()
    stdout=stdout.split()
    return int(stdout[2]-1)

def get_atoms_dump(dump_lines):
        ca_atoms_dump = []; box = []; A = []
        cb_atoms_dump = []
        o_atoms_dump = []
        p_atoms_dump = []
        o5_atoms_dump=[]
        flag = 'off'
        b_atoms_dump = []
        #print dump_lines
        for l in dump_lines:
                l = l.strip()
                #print l
                if l[:5]=="ITEM:": item = l[6:]
                elif item[:10] == "BOX BOUNDS":
                    box.append(l)
                    l = l.split()
                    A.append([float(l[0]), float(l[1])])
                elif item[:5] == "ATOMS":
                        l = l.split()  ; i_atom = l[0]
                        x = float(l[2]); y = float(l[3]); z = float(l[4])
                        x = (A[0][1] - A[0][0])*x + A[0][0]
                        y = (A[1][1] - A[1][0])*y + A[1][0]
                        z = (A[2][1] - A[2][0])*z + A[2][0]
                        #print atom_desc
                        #print l[1]
                        desc = atom_desc[l[1]]
                        if desc=='C-Alpha':
                                atom_CA = [x,y,z]
                                ca_atoms_dump.append(atom_CA)
                        if desc=='C-Beta':
                                atom = [x,y,z]
                                #print atom
                                cb_atoms_dump.append(atom)
                        if desc=='H-Beta' :
                                cb_atoms_dump.append(atom_CA)
                        if desc=='O' :
                                atom = [x,y,z]
                                o_atoms_dump.append(atom)
                        if desc=='O5' :
                                o5_atom = [x,y,z]
                                o5_atoms_dump.append(o5_atom)
                        #        if flag == "off":
                        #           p_atoms_dump.append(atom)
                        #           flag = "on"
                        if desc=='P' :
                                atom = [x,y,z]
                                p_atoms_dump.append(atom)
                        if desc=='P_start1' or desc== 'P_start2':
                                p_atoms_dump.append(o5_atom)
                        if desc=='XXX': 
                                atom = [x,y,z]
                                b_atoms_dump.append(atom)
        return ca_atoms_dump, cb_atoms_dump, o_atoms_dump,p_atoms_dump,o5_atoms_dump,b_atoms_dump

def vector(p1, p2):
    return [p2[0]-p1[0], p2[1]-p1[1], p2[2]-p1[2]]

def vadd(p1,p2):
    return [p2[0]/2+p1[0]/2, p2[1]/2+p1[1]/2, p2[2]/2+p1[2]/2]

def vmulti(p1,k):
    return [p1[0]*k,p1[1]*k,p1[2]*k]

def vabs(a):
    return math.sqrt(pow(a[0],2)+pow(a[1],2)+pow(a[2],2))

def v_product(p1,p2):
    return p1[0]*p2[0]+p1[1]*p2[1]+p1[2]*p2[2]

def vangle(p1,p2):
    return math.acos(v_product(p1,p2)/vabs(p1)/vabs(p2))*180/3.1415926535

def vproduct(a, b):
    if type(a)==type([]) and type(b)==type([]):
        return a[0]*b[0]+a[1]*b[1]+a[2]*b[2]
    elif type(b)==type([]):
        return [a*b[0], a*b[1], a*b[2]]
    elif type(a)==type([]):
        return [a[0]*b, a[1]*b, a[2]*b]
    return a*b

def vcross_product(a, b):
    cx = a[1]*b[2]-a[2]*b[1]
    cy = a[2]*b[0]-a[0]*b[2]
    cz = a[0]*b[1]-a[1]*b[0]
    return [cx, cy, cz];


def dihedral_angle(v1, v2, v3):
    n1 = vcross_product(v1, v2)
    n2 = vcross_product(v2, v3)
    y = vproduct( vproduct(vabs(v2), v1), n2 )
    x = vproduct( n1, n2 )
    return math.atan2(y, x)

def calc_dihedral_angle(p1, p2, p3, p4):
    v1 = vector(p1, p2)
    v2 = vector(p2, p3)
    v3 = vector(p3, p4)
    return 180*dihedral_angle(v1, v2, v3)/3.14159265358979

def read_charge_datafile(datafile):
    charge = []
    resi_charge = []
    Flag = 'off'
    with open (datafile,'r') as fopen:
       for line in fopen.readlines():
         if len(line.split()) > 0:
            if Flag == 'on':
               #print line
              if len(line.split()) > 3: 
               if line.split()[3] == '18':
                  if float(line.split()[4]) != 0.0 :
                     charge.append(float(line.split()[4]))
                     resi_charge.append(int(line.split()[2]))
            if line.split()[0] == 'Atoms':
               Flag = 'on'
            elif line.split()[0] == 'Bonds':
               Flag = 'off'
               break 
    return resi_charge,charge

def Calu_Twist_on_DNA(b_atoms):
    dna_length = int(len(b_atoms)/2)
    b1_atoms  =  b_atoms[0:dna_length]
    b2_atoms  =  b_atoms[dna_length:dna_length*2]
    Twist = ""
    for i in range(dna_length-1):
        b_atom_1 = b_atoms[i]
        b_atom_2 = b_atoms[-1-i]
        b_atomn_1 = b_atoms[i+1]
        b_atomn_2 = b_atoms[-1-i-1]
        b_center = vadd(b_atom_1,b_atom_2)
        b_centern = vadd(b_atomn_1,b_atomn_2)
        zmst=vector(b_center,b_centern)
        ys = vector(b_atom_1,b_atom_2)
        ysn = vector(b_atomn_1,b_atomn_2)
        yr = vector(ys,vmulti(zmst,v_product(ys,zmst)))
        yrn = vector(ysn,vmulti(zmst,v_product(ysn,zmst)))
        zmsto = vcross_product(yr,yrn)
        ozmst = v_product(zmst,zmsto)
        #print v_product(yr,yrn)/(vabs(yr)*vabs(yrn))
        twist = math.acos(v_product(yr,yrn)/(vabs(yr)*vabs(yrn)))/3.15159*180
        if twist > 180:
           twist = twist - 180
        elif twist < -180:
           twist = twist + 180 
        if ozmst > 0:
           twist = twist
        else:
           twist = 0 - twist
        Twist += str(twist) + " "
    return Twist

def calculate_traj(dumpfile):
    file_len       = get_file_len(dumpfile)
    nline_snapshot = get_nline_snapshot(dumpfile)
    n_snapshot     = int(file_len / nline_snapshot)
    out_bd = open("Twist","w")
    for i in range(n_snapshot):
        dump_part = get_dump_i(dumpfile, i)
        ca_atoms, cb_atoms, o_atoms,p_atoms,o5_atoms,b_atoms = get_atoms_dump(dump_part)
        Twist = Calu_Twist_on_DNA(b_atoms)
        out_bd.write(Twist+"\n")
    out_bd.close()
def main():
    dumpfile = sys.argv[1]
    cutoff = 9.5
    #datafile = sys.argv[2]
    calculate_traj(dumpfile)
    #compute_bind_site_dump(dumpfile,cutoff)

if __name__ == '__main__':
    main()


        
