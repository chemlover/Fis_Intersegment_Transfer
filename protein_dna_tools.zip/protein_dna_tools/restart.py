#!/usr/bin/env python

import os
import sys
from subprocess import *
import fileinput
from numpy import *

commonDir = '/home/mt42/work/awsemmd_proteinDNA/fisDNA_3IV5_Go_1/commons'
sys.path.append(commonDir)
from read_lammpsDataFile import *

globalDir = "/scratch/mt42/workestartFile(restartFolder, outFolder)"

tempList = [300]
restartFolder = './'
commonDir = './'
outFolder = './'
def genRestartFile(restartFolder, outFolder):

    #   ---     restart data file   
    lammps_data_file = commonDir + "/data.merge"
    # Need to be more careful about this in the future !!
    lammps_dump_file = restartFolder + "DUMP_FILE_temp300.lammpstrj"

    for temp in tempList:
        lammps_out_file  = "%s/data_temp%d.restart"%(outFolder, temp)

        readDataFile(lammps_data_file)
        updatexyzFromDumpFile(lammps_dump_file)
        writeDataFile(lammps_out_file)

genRestartFile(restartFolder, outFolder)
