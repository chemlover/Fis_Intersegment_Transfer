import os
import sys

inputfile =sys.argv[1]
outputfile = sys.argv[2]
with open(inputfile,'r') as fopen:
    lines = fopen.readlines()
Flag = 'off'
data = ''
for line in lines:
  if line != '\n':
   if line.split()[0] == 'Atoms':
      Flag = 'on'
   elif line.split()[0] == 'Bonds':
      Flag = 'off'
   if Flag == 'on' and line.split()[0] != 'Atoms': 
     data += line
with open(outputfile,'w') as fwrite:
     fwrite.writelines(data)
