import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import sys
datafile1 = sys.argv[1]
datafile2 = sys.argv[2]
num = int(sys.argv[3])
np.set_printoptions(threshold=sys.maxsize)
#Figure settings
sns.set(font_scale=1.65)
#fig = plt.figure(figsize=(10,6))
#fig.subplots_adjust(hspace=.5)    

data1 = pd.read_csv(datafile1,header=None)
data2 = pd.read_csv(datafile2,header=None)
#data1max = 
#Plot top histogram
#ax = fig.add_subplot(2, 1, 1)
#ax = data1.hist(bins=50)
#ax.set_xlim(0,800)
#plt.xlabel('Part1')
#plt.ylabel('Frequency')
#plt.savefig('part1_frequency.png')
#Plot bottom histogram
#ax2 = fig.add_subplot(2, 1, 2)
#ax2 = data2.hist(bins=50)
#ax2.set_xlim(0,800)
#plt.xlabel('Part2')
#plt.ylabel('Frequency')
#plt.savefig('part2_frequency.png')
from sklearn.utils import resample 
#boot_strap_picture
part1_bootstrap = []
#df =  pd.DataFrame(resample(data1))
#print df
#res = df.to_records()[:][1]

for i in range(num):
    np.random.seed(i)
    #print (resample(data1))
    df = pd.DataFrame(resample(data1))
    length = len(data1)
    res1 = df.to_records()
    res2 = []
    #print res1[1][1]
    for j in range(length):
        res2.append(res1[j][1])
    part1_bootstrap.append(res2)
#print(len(part1_bootstrap))
part2_bootstrap = []
for i in range(num):
    np.random.seed(i)
    df = pd.DataFrame(resample(data2))
    length = len(data1)
    res1 = df.to_records()
    res2 = []
    #print res1[1][1]
    for j in range(length):
        res2.append(res1[j][1])
    part2_bootstrap.append((res2))
#print(len(part2_bootstrap))
#print np.shape(part1_bootstrap) 
#part1_bootstrap=np.reshape(part1_bootstrap,(10,len(data1)))
#print part1_bootstrap[1]
bootstrap_means_part1 = np.mean(part1_bootstrap,axis=1)
bootstrap_means_part2 = np.mean(part2_bootstrap,axis=1)
print bootstrap_means_part1 
print bootstrap_means_part2
lower_bound = np.percentile(bootstrap_means_part1, 2.5)
upper_bound = np.percentile(bootstrap_means_part1, 97.5)

#fig = plt.figure(figsize=(10,3))
#ax = plt.hist(bootstrap_means_part1, bins=30)
#plt.xlabel('part1')
#plt.ylabel('Frequency')
#plt.axvline(lower_bound, color='r')
#plt.axvline(upper_bound, color='r')
#plt.savefig("part1_bootstrap.png")
#differences = part1_bootstrap - part2_bootstrap
#lower_bound = np.percentile(differences, 2.5)
#upper_bound = np.percentile(differences, 97.5)
obs_difs = bootstrap_means_part1 - bootstrap_means_part2


combined = np.concatenate((data1, data2), axis=0)

perms_part1 = []
perms_part2 = []

for i in range(num):
    np.random.seed(i)
    df = pd.DataFrame(resample(combined, n_samples = len(data1)))
    length = len(data1)
    res1 = df.to_records()
    res2 = []
    #print res1[1][1]
    for j in range(length):
        res2.append(res1[j][1])
    perms_part1.append(res2)
    df = pd.DataFrame(resample(combined, n_samples = len(data2)))
    length = len(data2)
    res1 = df.to_records()
    res2 = []
    #print res1[1][1]
    for j in range(length):
        res2.append(res1[j][1])
    perms_part2.append(res2)
dif_bootstrap_means = (np.mean(perms_part1, axis=1)-np.mean(perms_part2, axis=1))
p_value = dif_bootstrap_means[dif_bootstrap_means >= obs_difs].shape[0]/num
print p_value
