import os
import sys
import numpy as np
import math
from math import * 
pdbfile = sys.argv[1]
def vector(p1, p2):
    return [p2[0]-p1[0], p2[1]-p1[1], p2[2]-p1[2]]
def vadd(p1, p2):
    return [p2[0]+p1[0], p2[1]+p1[1], p2[2]+p1[2]]

def vnorm(a):
    norm = sqrt(a[0]*a[0]+a[1]*a[1]+a[2]*a[2])
    return [a[0]/norm,a[1]/norm,a[2]/norm]

def vaverage(p1,p2):
    return [(p2[0]+p1[0])/2, (p2[1]+p1[1])/2, (p2[2]+p1[2])/2]

def vabs(a):
    return math.sqrt(pow(a[0],2)+pow(a[1],2)+pow(a[2],2))

def v_product(p1,p2):
    return p1[0]*p2[0]+p1[1]*p2[1]+p1[2]*p2[2]

def vangle(p1,p2):
    #print p2
    #print p1
    return math.acos(v_product(p1,p2)/vabs(p1)/vabs(p2))*180/3.1415926535

def vproduct(a, b):
    if type(a)==type([]) and type(b)==type([]):
        return a[0]*b[0]+a[1]*b[1]+a[2]*b[2]
    elif type(b)==type([]):
        return [a*b[0], a*b[1], a*b[2]]
    elif type(a)==type([]):
        return [a[0]*b, a[1]*b, a[2]*b]
    return a*b

def vcross_product(a, b):
    cx = a[1]*b[2]-a[2]*b[1]
    cy = a[2]*b[0]-a[0]*b[2]
    cz = a[0]*b[1]-a[1]*b[0]
    return [cx, cy, cz];

def get_atoms(pdbfile):
    with open(pdbfile,"r") as fopen:
         pdb_part = fopen.readlines()
    atoms = []
    for line in pdb_part:
        if line.split()[0] != 'END':
           if line.split()[0] == "ATOM":
           #print line
              x=float(line[30:38])
              y=float(line[38:46])
              z=float(line[46:54])
              atom = [x,y,z]
              atoms.append(atom)
   # print coord
    return atoms

def get_DNA_axis_center(atoms):
    length = len(atoms)/2
    c1atoms = atoms[0:length]
    c2atoms = atoms[length:2*length]
    axis = [0,0,0]
    center = [0,0,0]
    for i in range(length):
        for j in range(3):
            center[j] += (c1atoms[i][j] + c2atoms[i][j])/length/2.0
    #center = vnorm(vector)
    startc = [0,0,0]
    endc = [0,0,0]
    for i in range(8):
        for j in range(3):
           startc[j] +=  (c1atoms[i][j] + c2atoms[-i-1][j]) /16.0
           endc[j] +=  (c2atoms[i][j] + c1atoms[-i-1][j]) /16.0
    axis = vector(startc,endc) 
    #axis = vnorm(axis)
    return axis,center

def move_DNA_rotation(atoms,dist,angle):
    theta = angle/180.0*3.14159
    axis,center = get_DNA_axis_center(atoms)         
    axisv = vnorm([axis[1],-axis[0],0])
    axisvd = vproduct(dist, axisv)
    new_center = vadd(center,axisvd)
    new_atoms = []
    for i in range(len(atoms)):
        p1 = vector(atoms[i],center)
        p2 = vadd(p1,axisvd)
        p3 = vadd(p2,center)
        p4 = vector(p3,new_center)
        p5 = [0,0,0]
        p5[0] = p4[0]*(axisv[0]*axisv[0]*(1-cos(theta))+cos(theta)) + p4[1]*(axisv[0]*axisv[1]*(1-cos(theta))+axisv[2]*sin(theta)) + p4[2]*(axisv[0]*axisv[2]*(1-cos(theta))-axisv[1]*sin(theta))
        p5[1] = p4[0]*(axisv[0]*axisv[1]*(1-cos(theta))-axisv[2]*sin(theta)) + p4[1]*(axisv[1]*axisv[1]*(1-cos(theta))+cos(theta)) + p4[2]*(axisv[1]*axisv[2]*(1-cos(theta))+axisv[0]*sin(theta))
        p5[2] = p4[0]*(axisv[0]*axisv[2]*(1-cos(theta))+axisv[1]*cos(theta)) + p4[1]*(axisv[1]*axisv[2]*(1-cos(theta))-axisv[0]*sin(theta)) + p4[2]*(axisv[2]*axisv[2]*(1-cos(theta))+cos(theta))
        p6 = vadd(new_center,p5)
        #print p3
        #print p6
        new_atoms.append(p6)
    return new_atoms

def rewrite_DNA_pdb(pdbfile,dist,angle,newpdbfile):
    atoms = get_atoms(pdbfile)
    natom = len(atoms)
    nres = (len(atoms) + 2)/3
    new_atoms = move_DNA_rotation(atoms,dist,angle)
    with open(pdbfile,"r") as fopen:
         lines = fopen.readlines()
    data = lines
    i = - 1
    for line in lines:
         if len(line) > 50:
            i += 1
            data += line[0:6] + str(int(line[6:11]) + natom).rjust(5," ") + line[11:22] + str(int(line[22:26]) + nres).rjust(4," ") + line[26:30] + str(round(new_atoms[i][0],3)).rjust(8," ") + str(round(new_atoms[i][1],3)).rjust(8," ") + str(round(new_atoms[i][2],3)).rjust(8," ") + line[54:83]
    with open(newpdbfile,"w") as fwrite:
         fwrite.writelines(data)
#print cos(3.14159)
pdbfile = sys.argv[1]
dist = float(sys.argv[2])
angle = float(sys.argv[3])
newpdbfile = sys.argv[4]
rewrite_DNA_pdb(pdbfile,dist,angle,newpdbfile)
