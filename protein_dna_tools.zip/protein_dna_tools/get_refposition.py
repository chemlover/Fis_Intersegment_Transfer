import os
import sys
inputfile = sys.argv[1]
outputfile = sys.argv[2]
begin = sys.argv[3]
end = sys.argv[4]

data = '        refPositions '
flag = 'off'
with open(inputfile,'r') as fopen:
     lines = fopen.readlines()
for line in lines:
    if len(line.split()) == 8 :
       if line.split()[0] == begin:
          flag = 'on' 
       if flag == 'on':
          data += "(" + line.split()[5] + ", " + line.split()[6] + ", " + line.split()[7]+ ") "
       if line.split()[0] == end:
          flag = "off"
          break
with open(outputfile,'w') as fwrite:
     fwrite.writelines(data)
