import os
import numpy as np
import sys
datafile = sys.argv[1]
atomid =0 
resid  =0 
data = ""
with open(datafile,"r") as fopen:
     for line in fopen.readlines():
         if len(line.split()) == 8:
            stdenv = line.split()
            resid += 1
            atomid += 1
            data += "ATOM  " + str(atomid).rjust(5," ") + "  CA  FIS A" + str(resid).rjust(4," ") + "    "+ str(round(float(stdenv[5]),3)).rjust(8," ") + str(round(float(stdenv[6]),3)).rjust(8," ") + str(round(float(stdenv[7]),3)).rjust(8," ") + "\n"
pdbfile = sys.argv[2]
with open(pdbfile,"w") as fwrite:
     fwrite.writelines(data)
