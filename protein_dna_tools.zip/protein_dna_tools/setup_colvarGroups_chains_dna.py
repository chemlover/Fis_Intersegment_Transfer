#!/usr/bin/env python

from numpy import *
from numpy import linalg as LA
import sys
dir = './'
name_p = 'chainB'
#name_dna = 'DNA2'
datafile = sys.argv[1]
name_dna = sys.argv[2]
number_p = int(sys.argv[3])
# get phosphate backbone
dna     = loadtxt(dir+datafile)
#mask_ph    = dna[:, 3]==1
mask_ph    = logical_and(dna[:, 3]==1, dna[:, 1]==number_p)
xyz_PH   = squeeze( dna[where(mask_ph), 5::] )
atomInd_PH = squeeze( dna[where(mask_ph), 0] )
charge_PH  = squeeze( dna[where(mask_ph), 4] )

fh = open('group_phosphate_%s_colvar.txt' %(name_dna), 'w')
fh.write('group     phosphate_%s  id  ' %(name_dna))
for id in range(len(atomInd_PH)):
    fh.write('%d '%atomInd_PH[id])
fh.close()

fh = open('group_phosphate_%s_charge.txt' %(name_dna), 'w')
for id in range(len(charge_PH)):
    fh.write('%f\n'%charge_PH[id])
fh.close()
