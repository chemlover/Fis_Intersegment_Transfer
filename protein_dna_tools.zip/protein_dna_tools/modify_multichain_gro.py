import sys
import os
inputfile = sys.argv[1]
outputfile = sys.argv[2]
data = ''
Flag = 0
index = 0
with open(inputfile,'r') as fopen:
   for line in fopen.readlines():
    if line != '\n':
        if len(line.split()) == 7:
           if float(line.split()[3]) == 1.0 : 
              Flag = index
              print index
         #     if Flag == 1:
         #        Flag = 0
              data += str(int(Flag + float(line.split()[0]))).rjust(5,' ') + line[5:45]
           else:
              data += str(int(Flag + float(line.split()[0]))).rjust(5,' ') + line[5:45]
              index = Flag + float(line.split()[0])
        else:
          data += line
    else:
          data += line
with open(outputfile,'w') as fopen:
    fopen.writelines(data)
          
           
