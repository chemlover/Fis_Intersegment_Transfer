#!/usr/bin/env python

from numpy import *
from numpy import linalg as LA
import sys
dir = './'
name_p = 'chainB'
#name_dna = 'DNA2'
datafile = sys.argv[1]
# get phosphate backbone
dna     = loadtxt(dir+datafile)
#mask_ph    = dna[:, 3]==1
mask_ph    = dna[:, 3]==1
xyz_PH   = squeeze( dna[where(mask_ph), 5::] )
atomInd_PH = squeeze( dna[where(mask_ph), 0] )
charge_PH  = squeeze( dna[where(mask_ph), 4] )

fh = open('group_phosphate_colvar.txt', 'w')
fh.write('group     phosphate  id  ')
for id in range(len(atomInd_PH)):
    fh.write('%d '%atomInd_PH[id])
fh.close()

fh = open('group_phosphate_charge.txt', 'w')
for id in range(len(charge_PH)):
    fh.write('%f\n'%charge_PH[id])
fh.close()
