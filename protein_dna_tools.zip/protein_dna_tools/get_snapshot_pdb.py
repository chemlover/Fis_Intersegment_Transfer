import os 
import sys
Pdbfile = sys.argv[1] # trajctory pdb file
outputfile = sys.argv[2] #outptfile
num = int(sys.argv[3])  # Order
Num = 1
with open(Pdbfile,'r') as fopen:
   data = ''
   for line in fopen.readlines():
    data += line
    if line.split()[0] == 'END':
       if Num == num:
          break
       Num += 1
       data = ''
with open(outputfile,'w') as fwrite:
     fwrite.writelines(data)
