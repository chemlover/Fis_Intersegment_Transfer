import os
import sys
import numpy as np
from math import *
pfile = sys.argv[1]
valuefile = sys.argv[2]
pmffile = sys.argv[3]
valuesumfile = sys.argv[4]
T=300

p=np.loadtxt(pfile)
value=np.loadtxt(valuefile)
pmf=np.loadtxt(pmffile)
[m1,n1] = np.shape(pmf)
[m2,n2] = np.shape(value)

prob = np.zeros(m2)



for i in range(m2):
    Flag = m1 - 1
    for j in range(m1):
        if p[i] <= pmf[j][0]:
           Flag = j
           break
    prob[i] = exp(-pmf[Flag][1]/0.001987/T)

valuesum = np.zeros(n2)
probsum = np.zeros(n2)

for i in range(m2):
    for j in range(n2):
           valuesum[j] += prob[i] * value[i][j]
           probsum[j] += prob[i]

for i in range(n2):
    valuesum[i] = valuesum[i]/prob[i]
    #else:
    #   energypre[i] = energypre[i]

np.savetxt(valuesumfile,pmf,fmt="%.3f",delimiter="\n")
