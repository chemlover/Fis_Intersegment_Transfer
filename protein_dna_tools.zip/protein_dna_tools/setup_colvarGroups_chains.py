#!/usr/bin/env python

from numpy import *
from numpy import linalg as LA

dir = './'
name_p = 'chainB'
#name_dna = 'DNA2'

# get beta carbon coordinates
protein = loadtxt(dir+'atom.dat')
#mask    = protein[:, 3]==18
mask    = logical_and(protein[:, 3]==18, protein[:, 1]==2)
#mask    = logical_and(protein[:, 3]==18, logical_or(protein[:, 1]==9, protein[:, 1]==10))
xyz_CB  = squeeze( protein[where(mask), 5::] )
atomInd_CB = squeeze( protein[where(mask), 0] )
charge_CB  = squeeze( protein[where(mask), 4] )


fh = open('group_CBeta_%s_colvar.txt' %(name_p), 'w')
fh.write('group     CBeta_%s   id  ' %(name_p))
for id in range(len(atomInd_CB)):
    fh.write('%d '%atomInd_CB[id])
fh.close()

fh = open('group_CBeta_%s_charge.txt' %(name_p), 'w')
for id in range(len(charge_CB)):
    fh.write('%f\n'%charge_CB[id])
fh.close()

#------------------------------------------------#
'''
# get phosphate backbone
dna     = loadtxt(dir+'/dnaAtoms.data')
#mask_ph    = dna[:, 3]==1
mask_ph    = logical_and(dna[:, 3]==1, logical_or(dna[:, 1]==4, dna[:, 1]==4))
xyz_PH   = squeeze( dna[where(mask_ph), 5::] )
atomInd_PH = squeeze( dna[where(mask_ph), 0] )
charge_PH  = squeeze( dna[where(mask_ph), 4] )

fh = open('group_phosphate_%s_colvar.txt' %(name_dna), 'w')
fh.write('group     phosphate_%s  id  ' %(name_dna))
for id in range(len(atomInd_PH)):
    fh.write('%d '%atomInd_PH[id])
fh.close()

fh = open('group_phosphate_%s_charge.txt' %(name_dna), 'w')
for id in range(len(charge_PH)):
    fh.write('%f\n'%charge_PH[id])
fh.close()
'''
