#!/usr/bin/env python

import re
import os
from numpy import *
from subprocess import *

header_block  =     [] 
mass_block    =     [] 
bondc_block   =     []
anglec_block  =     []
dihedc_block  =     []
atoms_block   =     []
bonds_block   =     []
angles_block  =     []
diheds_block  =     []

#   ------------------------------------------------------  #
def readDataFile(lammps_data_file):

    global header_block, mass_block, bondc_block, anglec_block, dihedc_block, \
           atoms_block,  bonds_block, angles_block, diheds_block

    dfile = open(lammps_data_file)
    topdata = ''.join( dfile.readlines() )
    dfile.close()

    # lammps header
    header_block  = re.findall('LAMMPS.+Masses\n', topdata, re.DOTALL)
    mass_block    = re.findall('Masses.+Bond Coeffs\n', topdata, re.DOTALL)
    bondc_block   = re.findall('Bond Coeffs.+Angle Coeffs\n', topdata, re.DOTALL)
    anglec_block  = re.findall('Angle Coeffs.+Dihedral Coeffs\n', topdata, re.DOTALL)
    dihedc_block  = re.findall('Dihedral Coeffs.+Atoms\n', topdata, re.DOTALL)
    atoms_block   = re.findall('Atoms.+Bonds\n', topdata, re.DOTALL)
    bonds_block   = re.findall('Bonds.+Angles\n', topdata, re.DOTALL)
    angles_block  = re.findall('Angles.+Dihedrals\n', topdata, re.DOTALL)
    diheds_block  = re.findall('Dihedrals.+', topdata, re.DOTALL)

#   ------------------------------------------------------  #
def writeDataFile(out_file):

    fout = open(out_file, "w")

    for item in header_block[0].split("\n")[0:-2]:
        fout.write(item+"\n")

    for item in mass_block[0].split("\n")[0:-2]:
        fout.write(item+"\n")

    for item in bondc_block[0].split("\n")[0:-2]:
        fout.write(item+"\n")

    for item in anglec_block[0].split("\n")[0:-2]:
        fout.write(item+"\n")

    for item in dihedc_block[0].split("\n")[0:-2]:
        fout.write(item+"\n")

    for item in atoms_block[0].split("\n")[0:-2]:
        fout.write(item+"\n")

    for item in bonds_block[0].split("\n")[0:-2]:
        fout.write(item+"\n")

    for item in angles_block[0].split("\n")[0:-2]:
        fout.write(item+"\n")

    for item in diheds_block[0].split("\n"):
        fout.write(item+"\n")

    fout.close()

#   ------------------------------------------------------  #
#   using the last frame for now
def updatexyzFromDumpFile(lammps_dump_file):

    global atoms_block

    #   ---     Read lammps trajectory
    lfile    = open(lammps_dump_file, "r")
    dumpdata = ''.join( lfile.readlines() )
    lfile.close()
    #xyz      = re.findall('\n\d+\s\d+\s.+', dumpdata)
    #xyz      = re.findall('ITEM: ATOMS.*ITEM: TIMESTEP', dumpdata, re.DOTALL)
    #coords = []
    #for item in xyz:
        #coords.append( fromstring(item, dtype=float, sep=" ")[2::] )
    #coords   = array(coords)
    
    n_atoms  = 727
    cmd = 'tail -%d %s > TMP'%(n_atoms, lammps_dump_file)
    q   = Popen(cmd, shell=True, stdout=PIPE, stderr=PIPE)
    q.communicate()
    coords   = loadtxt('TMP', usecols=range(2,5))
    
    # find the box
    cmd = 'tail -%d %s | head -3 > TMP'%(n_atoms+4, lammps_dump_file)
    q   = Popen(cmd, shell=True, stdout=PIPE, stderr=PIPE)
    q.communicate()
    box = loadtxt('TMP')
    
    atoms = zeros((n_atoms, 3), dtype=float)
    identity = ones((n_atoms,), dtype=float)
    atoms[:, 0] = (box[0, 1] - box[0, 0])*coords[:, 0] + box[0,0]*identity
    atoms[:, 1] = (box[1, 1] - box[1, 0])*coords[:, 1] + box[1,0]*identity
    atoms[:, 2] = (box[2, 1] - box[2, 0])*coords[:, 2] + box[2,0]*identity

    # replace the atoms block
    atomsList = atoms_block[0].split("\n")[2:-3]
    new_atoms_block = 'Atoms\n\n' 
    for ia, line in enumerate(atomsList):

        new_atoms_block += "\t"
        itemList = line.split()[0:-3]
        for item in itemList:
            new_atoms_block += item+"\t"

        new_atoms_block += "%15.8f %15.8f %15.8f\n"%(atoms[ia,0], atoms[ia,1], atoms[ia,2])

    new_atoms_block += "\nBonds\n"

    atoms_block[0] = new_atoms_block

if __name__ == "__main__":
    dir = "./"
    lammps_data_file = dir + "data.merge"

    trajdir = "./"
    lammps_dump_file = trajdir + "DUMP_FILE_temp300.lammpstrj"
    out_file = "data.fisDna.equiled"

    readDataFile(lammps_data_file)
    updatexyzFromDumpFile(lammps_dump_file)
    writeDataFile(out_file)

