import os
import sys
import numpy as np
from math import *
def vector(p1, p2):
    return [p2[0]-p1[0], p2[1]-p1[1], p2[2]-p1[2]]

def vabs(a):
    return sqrt(pow(a[0],2)+pow(a[1],2)+pow(a[2],2))

def sigma_sq(sep):
        return pow((1+sep),0.15)*pow((1+sep), 0.15)

def calc_dist(p1, p2):
        v=vector(p1,p2)
        return vabs(v)

def find_residue_binding_DNA(cb_atoms,p_atoms,cutoff):
    pgroup = []
    for j in range(len(cb_atoms)):
        for i in range(len(p_atoms)):
            dist = calc_dist(p_atoms[i],cb_atoms[j])
            if dist <= cutoff:
               pgroup.append(j)
               break
    return pgroup
    
def find_basepair_binding_DNA(cb_atoms,p_atoms,cutoff):
    dgroup = []
    for i in range(len(p_atoms)/2):
        for j in range(len(cb_atoms)):
            dist1 = calc_dist(p_atoms[i],cb_atoms[j])
            dist2 = calc_dist(p_atoms[-i-1],cb_atoms[j]) 
            if dist1 <= cutoff or dist2 <= cutoff:
               dgroup.append(i)
               break
    return dgroup

def generate_protein_pocket(cb_atoms,pgroup):
    data = ""
    for i in range(len(pgroup)):
        for j in range(i+1,len(pgroup)):
            sitei = pgroup[i]
            sitej = pgroup[j]
            dist = calc_dist(cb_atoms[sitei],cb_atoms[sitej])
            data += str(sitei) + " " + str(sitej) + " " + str(dist) + "\n"
    return data

def generate_pocket_dna(cb_atoms,p_atoms,pgroup,dgroup,site):
    data1 = ""
    data2 = ""
    for i in range(len(dgroup)):
        for j in range(len(pgroup)):
            sitei = pgroup[j]
            sitej = dgroup[i]
            dist1 = calc_dist(cb_atoms[sitei],p_atoms[sitej])
            dist2 = calc_dist(cb_atoms[sitei],p_atoms[-sitej-1])
            data1 += str(sitei) + " " + str(sitej-site) + " " + str(dist1) + " 0 \n"
            data2 += str(sitei) + " " + str(sitej-site) + " " + str(dist2) + " 1 \n"
    data1 += data2
    return data1

def compute_bind_site(cb_atoms,p_atoms,cutoff):
    dna_length = int(len(p_atoms)/2)
    p1_atoms  =  p_atoms[0:dna_length]
    p2_atoms  =  p_atoms[dna_length:dna_length*2]
    critia = cutoff**2
    protein_length = len(cb_atoms)
    site_domain = []
    for j in range(dna_length):
        for i in range(protein_length):
          dist1 = (cb_atoms[i][0]-p1_atoms[j][0])**2 + (cb_atoms[i][1]-p1_atoms[j][1])**2 + (cb_atoms[i][2]-p1_atoms[j][2])**2
          dist2 = (cb_atoms[i][0]-p2_atoms[dna_length-1-j][0])**2 + (cb_atoms[i][1]-p2_atoms[dna_length-1-j][1])**2 + (cb_atoms[i][2]-p2_atoms[dna_length-1-j][2])**2
          if dist1 <= critia or dist2 <= critia:
             #print j
             #print dist1
             #print dist2
             site_domain.append(j+2)
             break
    if len(site_domain) == 0:
           site = -1
    else:
           site = sum(site_domain)/len(site_domain)
    #print site_domain
    return site

def get_atoms(pdb_part):
    #print pdb_part
    ca_atoms = []
    cb_atoms = []
    p_atoms = []
    CB_p = []
    P_d = []
    S_d = []
    for line in pdb_part:
        #if line.split()[0] != 'END' or line.split()[0] != 'ENDMDL':
           #if line.split()[2] == 'CA' or line.split()[2] == 'S':
           #print linei
           if len(line.split()) > 5:
              x=float(line[30:38])
              y=float(line[38:46])
              z=float(line[46:54])
              resid = int(line[22:26])
              atom = [x,y,z]
              #atoms = [atom,resid]
              #atoms = atom
              #print line
              if line[13:15] == "CA":
                 ca_atoms.append(atom)
              elif line[13:15].split()[0] == "P":
                 p_atoms.append(atom)
           #if line[13:14] == "S":
           #      S_d.append(atoms)
           #if line[13:14] == "P":
            #     P_d.append(atoms)
    print (len(ca_atoms),len(p_atoms))
    return ca_atoms,p_atoms

def main():
    pdbfile = sys.argv[1]
    cutoff = 9.5
    with open(pdbfile,"r") as fopen:
         pdbpart = fopen.readlines() 
    #for line in pdbpart:
        #print line
    ca_atoms,p_atoms = get_atoms(pdbpart)
    site = int(compute_bind_site(ca_atoms,p_atoms,cutoff))
    print site
    pgroup =  find_residue_binding_DNA(ca_atoms,p_atoms,cutoff)
    dgroup =  find_basepair_binding_DNA(ca_atoms,p_atoms,cutoff)
    print (len(pgroup),len(dgroup))
    np.savetxt("ResBindingP.txt",pgroup,fmt="%d",delimiter="\n")
    data = generate_protein_pocket(ca_atoms,pgroup)
    with open("QdistrefPP.txt","w") as fwrite:
         fwrite.writelines(data)
    data = generate_pocket_dna(ca_atoms,p_atoms,pgroup,dgroup,site)
    with open("QdistrefPPD.txt","w") as fwrite:
         fwrite.writelines(data)

if __name__ == '__main__':
    main()
