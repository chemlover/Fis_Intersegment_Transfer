#!/usr/bin/env python

from numpy import *
from numpy import linalg as LA

# get alpha carbon coordinates

# get protein c beta, where the charge is assigned
protein = loadtxt('../protein+Dna/proteinAtoms.data')
mask    = protein[:, 3]==18
xyz_CB  = squeeze( protein[where(mask), 5::] )
atomInd_CB = squeeze( protein[where(mask), 0] )

# get phosphate backbone
dna     = loadtxt('../protein+Dna/dnaAtoms.data')
mask    = dna[:, 3]==1
xyz_P   = squeeze( dna[where(mask), 5::] )
atomInd_P = squeeze( dna[where(mask), 0] )

fh = open('group_CBeta_plumed.txt', 'w')
fh.write('CBeta: GROUP ATOMS=')

for id in range(len(atomInd_CB)-1):
    fh.write('%d,'%atomInd_CB[id])

fh.write('%d'%atomInd_CB[-1])
fh.close()

fh = open('group_phosphate_plumed.txt', 'w')
fh.write('phosphate: GROUP ATOMS=')

for id in range(len(atomInd_P)-1):
    fh.write('%d,'%atomInd_P[id])

fh.write('%d'%atomInd_P[-1])
fh.close()


