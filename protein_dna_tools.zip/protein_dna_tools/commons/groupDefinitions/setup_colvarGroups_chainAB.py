#!/usr/bin/env python

from numpy import *
from numpy import linalg as LA

dir = '../protein+Dna/'
# get alpha carbon coordinates
protein = loadtxt(dir+'protein_chainCD_Atoms.data')
mask    = protein[:, 3]==18
xyz_CB  = squeeze( protein[where(mask), 5::] )
atomInd_CB = squeeze( protein[where(mask), 0] )
charge_CB  = squeeze( protein[where(mask), 4] )


fh = open('group_CBeta_chainCD_colvar.txt', 'w')
fh.write('group     CBeta_chainCD   id  ')

for id in range(len(atomInd_CB)):
    fh.write('%d '%atomInd_CB[id])
fh.close()

fh = open('group_CBeta_chainCD_charge.txt', 'w')

for id in range(len(charge_CB)):
    fh.write('%f\n'%charge_CB[id])
fh.close()

