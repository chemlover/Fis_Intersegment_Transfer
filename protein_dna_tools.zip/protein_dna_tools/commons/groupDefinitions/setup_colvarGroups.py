#!/usr/bin/env python

from numpy import *
from numpy import linalg as LA

dir = '../protein+Dna/'
# get alpha carbon coordinates
#protein = loadtxt(dir+'proteinAtoms.data')
#mask    = logical_and(protein[:, 3]==18, protein[:, 1]==4)
#xyz_CB  = squeeze( protein[where(mask), 5::] )
#atomInd_CB = squeeze( protein[where(mask), 0] )
#charge_CB  = squeeze( protein[where(mask), 4] )

# get phosphate backbone
dna     = loadtxt(dir+'/dnaAtoms_DNA2.data')
mask    = dna[:, 3]==1
xyz_P   = squeeze( dna[where(mask), 5::] )
atomInd_P = squeeze( dna[where(mask), 0] )
charge_P  = squeeze( dna[where(mask), 4] )

#fh = open('group_CBeta_chainD_colvar.txt', 'w')
#fh.write('group     CBeta_chainD   id  ')

#for id in range(len(atomInd_CB)):
#    fh.write('%d '%atomInd_CB[id])
#fh.close()

#fh = open('group_CBeta_chainD_charge.txt', 'w')

#for id in range(len(charge_CB)):
#    fh.write('%f\n'%charge_CB[id])
#fh.close()

fh = open('group_phosphate_DNA2_colvar.txt', 'w')
fh.write('group     phosphate   id  ')

for id in range(len(atomInd_P)):
    fh.write('%d '%atomInd_P[id])
fh.close()

fh = open('group_phosphate_DNA2_charge.txt', 'w')

for id in range(len(charge_P)):
    fh.write('%f\n'%charge_P[id])
fh.close()

