#!/usr/bin/env python

from numpy import *
import fileinput

# read coordinates
# xyz = loadtxt('xyz_dna.txt', usecols=range(6,9)) # Atoms
#print xyz
fileout = open('cg_xtalDna.new', 'w')
ia = -1 # trick index
for line in fileinput.input('cg_xtalDna.temp'):
    items = line.split()
    ia += 1 # ia = 0 in the first round
    #print ia
    #fileout.write('\t%s\t%s\t%s\t%s\t%8s\t%12.6f\t%12.6f\t%12.6f\n'%(int(items[0])+160, int(items[1])+2, int(items[2])+54, items[3], items[4], \
    #                                                                   xyz[ia,0], xyz[ia,1], xyz[ia,2])) # Atoms:  loadtxt object, (x,y): x = record, y = col
    #fileout.write('%s\t%s\t%s\t%s\t%s\t%s\n'%(int(items[0])+160, int(items[1])+160, items[2], items[3], items[4], items[5])) # dna list (bond) 
    #fileout.write('%s\t%s\t%s\t%s\t%s\n'%(int(items[0])+160, int(items[1])+160, int(items[2])+160, items[3], items[4])) # dna list (angle)
    fileout.write('%s%7s%3s%6s%2s%4s%12.3f%8s%8s%6s%6s%10s\n'%(items[0], int(items[1])+160, items[2], items[3], 'F', int(items[5])+160, \
                  float(items[6])+30, items[7], items[8], items[9], items[10], items[11])) # pdb 
fileout.close()
