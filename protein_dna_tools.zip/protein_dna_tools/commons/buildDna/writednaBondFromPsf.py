#!/usr/bin/env python

from numpy import *
import fileinput

# read coordinates
# xyz = loadtxt('xyz_dna.txt', usecols=range(6,9)) # Atoms
#print xyz
fileout = open('dnaBondFromPsf.new', 'w')
ia = -1 # trick index
for line in fileinput.input('dnaBondFromPsf.old'):
    items = line.split()
    ia += 1 # ia = 0 in the first round
    #print ia
    #fileout.write('\t%s\t%s\t%s\t%s\t%8s\t%12.6f\t%12.6f\t%12.6f\n'%(int(items[0])+160, int(items[1])+2, int(items[2])+54, items[3], items[4], \
    #                                                                   xyz[ia,0], xyz[ia,1], xyz[ia,2])) # Atoms:  loadtxt object, (x,y): x = record, y = col
    #fileout.write('%s\t%s\t%s\t%s\t%s\t%s\n'%(int(items[0])+160, int(items[1])+160, items[2], items[3], items[4], items[5])) # dna list (bond) 
    #fileout.write('%s\t%s\t%s\t%s\t%s\n'%(int(items[0])+160, int(items[1])+160, int(items[2])+160, items[3], items[4])) # dna list (angle)
    fileout.write('%8s%8s%8s%8s%8s%8s%8s%8s\n'%(int(items[0])+160, int(items[1])+160, int(items[2])+160, int(items[3])+160, int(items[4])+160, \
                  int(items[5])+160, int(items[6])+160, int(items[7])+160)) # pdb 
fileout.close()
