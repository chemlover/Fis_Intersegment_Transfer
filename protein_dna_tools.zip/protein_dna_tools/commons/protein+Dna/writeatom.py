#!/usr/bin/env python

from numpy import *
import fileinput

# read coordinates
# xyz = loadtxt('xyz_dna.txt', usecols=range(6,9)) # Atoms
#print xyz
fileout = open('Angles_dna_new', 'w')
ia = -1 # trick index
for line in fileinput.input('Angles_dna_temp'):
    items = line.split()
    ia += 1 # ia = 0 in the first round
    #print ia
    #fileout.write('\t%s\t%s\t%s\t%s\t%8s\t%12.6f\t%12.6f\t%12.6f\n'%(int(items[0])+160, int(items[1])+2, int(items[2])+54, items[3], items[4], \
    #                                                                   xyz[ia,0], xyz[ia,1], xyz[ia,2])) # Atoms:  loadtxt object, (x,y): x = record, y = col
    #print xyz[1,0],xyz[1,1],xyz[1,2]
    #fileout.write('\t%s\t%s\t%s\t%s\n'%(int(items[0])+158, int(items[1]), int(items[2])+160, int(items[3])+160)) # Bonds (DNA)
    #fileout.write('\t%s\t%s\t%s\t%s\n'%(int(items[0])+158, int(items[1]), int(items[2]), int(items[3]))) # Bonds (DNA)
    fileout.write('\t%s\t%s\t%s\t%s\t%s\n'%(int(items[0])+258, int(items[1]), int(items[2])+160, int(items[3])+160, int(items[4])+160)) # Angles (DNA)
    #fileout.write('\t%s\t%s\t%s\t%s\t%s\t%s\n'%(int(items[0])+204, int(items[1]), int(items[2])+160, int(items[3])+160, int(items[4])+160, int(items[5])+160)) # Dihedrals (DNA)
fileout.close()

