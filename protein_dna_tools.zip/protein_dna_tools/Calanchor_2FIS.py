import sys
import os
import numpy as np
import math
atom_desc = {'1' : 'P', '2' : 'O5', '3' : 'XXX', '4' : 'XXX', '5' : 'XXX', '6' : 'XXX','7' : 'P_start2','8' : 'XXX','9' : 'XXX','10' : 'P_start1','11' : 'XXX','12' : 'XXX','13' : 'P_end','14' : 'XXX','15' : 'C-Alpha', '16' : 'N', '17' : 'O', '18' : 'C-Beta', '19' : 'H-Beta', '20' : 'C-Prime'}


def get_file_len(filename):
    exeline="wc -l "+filename ;
    stdout=os.popen(exeline).readline();
    stdout=stdout.split()
    return int(stdout[0])

def getline_range(filename, line1, line2):
    assert(line1 <= line2)
    nline=line2-line1+1
    exeline="head -n"+str(line2)+" "+filename+" | tail -n"+str(nline) ;
    #print exeline
    stdout=os.popen(exeline).readlines()
    return stdout

def get_natoms(dump_file):
        line=getline_range(dump_file, 4,4); line=line[0].split()
        natoms=int(line[0])
        return natoms

def get_nline_snapshot(dump_file):
        natoms=get_natoms(dump_file)
        nline=natoms + 9
        return nline

def get_dump_i(dump_file, i):
        nline=get_nline_snapshot(dump_file)
        line_start = 1 + nline*i ; line_end = nline*(i+1)
        dump_part=getline_range(dump_file, line_start, line_end)
        return dump_part

def get_protein_len(filename):
    exeline="wc -l" + filename
    stdout=os.popen(exeline).readline()
    stdout=stdout.split()
    return int(stdout[2]-1)

def get_atoms_dump(dump_lines):
        ca_atoms_dump = []; box = []; A = []
        cb_atoms_dump = []
        o_atoms_dump = []
        p_atoms_dump = []
        o5_atoms_dump=[]
        flag = 'off'
        #print dump_lines
        for l in dump_lines:
                l = l.strip()
                #print l
                if l[:5]=="ITEM:": item = l[6:]
                elif item[:10] == "BOX BOUNDS":
                    box.append(l)
                    l = l.split()
                    A.append([float(l[0]), float(l[1])])
                elif item[:5] == "ATOMS":
                        l = l.split()  ; i_atom = l[0]
                        x = float(l[2]); y = float(l[3]); z = float(l[4])
                        x = (A[0][1] - A[0][0])*x + A[0][0]
                        y = (A[1][1] - A[1][0])*y + A[1][0]
                        z = (A[2][1] - A[2][0])*z + A[2][0]
                        #print atom_desc
                        #print l[1]
                        desc = atom_desc[l[1]]
                        if desc=='C-Alpha':
                                atom_CA = [x,y,z]
                                ca_atoms_dump.append(atom_CA)
                        if desc=='C-Beta':
                                atom = [x,y,z]
                                #print atom
                                cb_atoms_dump.append(atom)
                        if desc=='H-Beta' :
                                cb_atoms_dump.append(atom_CA)
                        if desc=='O' :
                                atom = [x,y,z]
                                o_atoms_dump.append(atom)
                        if desc=='O5' :
                                o5_atom = [x,y,z]
                                o5_atoms_dump.append(o5_atom)
                        #        if flag == "off":
                        #           p_atoms_dump.append(atom)
                        #           flag = "on"
                        if desc=='P' :
                                atom = [x,y,z]
                                p_atoms_dump.append(atom)
                        if desc=='P_start1' or desc== 'P_start2':
                                p_atoms_dump.append(o5_atom)
        return ca_atoms_dump, cb_atoms_dump, o_atoms_dump,p_atoms_dump,o5_atoms_dump

def compute_bind_site(cb_atoms,p_atoms,cutoff):
    dna_length = len(p_atoms)/2
    p1_atoms  =  p_atoms[0:dna_length] 
    p2_atoms  =  p_atoms[dna_length:dna_length*2]
    critia = cutoff**2 
    protein_length = len(cb_atoms)
    site_domain = []
    for j in range(dna_length):
        for i in range(protein_length):
          dist1 = (cb_atoms[i][0]-p1_atoms[j][0])**2 + (cb_atoms[i][1]-p1_atoms[j][1])**2 + (cb_atoms[i][2]-p1_atoms[j][2])**2 
          dist2 = (cb_atoms[i][0]-p2_atoms[dna_length-1-j][0])**2 + (cb_atoms[i][1]-p2_atoms[dna_length-1-j][1])**2 + (cb_atoms[i][2]-p2_atoms[dna_length-1-j][2])**2 
          if dist1 <= critia or dist2 <= critia:
             #print j
             #print dist1
             #print dist2
             site_domain.append(j+1)
             break
    if len(site_domain) == 0:
           site = 0
    else:
           site = sum(site_domain)/len(site_domain)
    #print site_domain
    return site

def compute_bind_site_dump(dumpfile,cutoff):
    with open(dumpfile,'r') as fopen:
         lines = fopen.readlines()
    file_len       = get_file_len(dumpfile)
    nline_snapshot = get_nline_snapshot(dumpfile)
    n_snapshot     = file_len / nline_snapshot
    file_bindsite = open("Bindc",'w')
    for i in range(n_snapshot):
        i_dump  = get_dump_i(dumpfile, i)
        ca_atoms, cb_atoms, o_atoms,p_atoms,o5_atoms = get_atoms_dump(i_dump)
        site = compute_bind_site(cb_atoms,p_atoms,cutoff)
        file_bindsite.write(str(site)+'\n')
    file_bindsite.close()


def vector(p1, p2):
    return [p2[0]-p1[0], p2[1]-p1[1], p2[2]-p1[2]]

def vaverage(p1,p2):
    return [(p2[0]+p1[0])/2, (p2[1]+p1[1])/2, (p2[2]+p1[2])/2]

def vabs(a):
    return math.sqrt(pow(a[0],2)+pow(a[1],2)+pow(a[2],2))

def v_product(p1,p2):
    return p1[0]*p2[0]+p1[1]*p2[1]+p1[2]*p2[2]

def vangle(p1,p2):
    #print p2
    #print p1
    return math.acos(v_product(p1,p2)/vabs(p1)/vabs(p2))*180/3.1415926535

def vproduct(a, b):
    if type(a)==type([]) and type(b)==type([]):
        return a[0]*b[0]+a[1]*b[1]+a[2]*b[2]
    elif type(b)==type([]):
        return [a*b[0], a*b[1], a*b[2]]
    elif type(a)==type([]):
        return [a[0]*b, a[1]*b, a[2]*b]
    return a*b

def vcross_product(a, b):
    cx = a[1]*b[2]-a[2]*b[1]
    cy = a[2]*b[0]-a[0]*b[2]
    cz = a[0]*b[1]-a[1]*b[0]
    return [cx, cy, cz];


def dihedral_angle(v1, v2, v3):
    n1 = vcross_product(v1, v2)
    n2 = vcross_product(v2, v3)
    y = vproduct( vproduct(vabs(v2), v1), n2 )
    x = vproduct( n1, n2 )
    return math.atan2(y, x)

def calc_dihedral_angle(p1, p2, p3, p4):
    v1 = vector(p1, p2)
    v2 = vector(p2, p3)
    v3 = vector(p3, p4)
    return 180*dihedral_angle(v1, v2, v3)/3.14159265358979

def calulate_atoms(cb_atoms,p_atoms,cutoff):
    contacts = []
    for i in range(len(cb_atoms)):
        contact = []
        for j in range(len(p_atoms)):
            p_atom = p_atoms[j]
            cb_atom = cb_atoms[i]
            new_distance = vabs(vector(p_atom,cb_atom))
            if new_distance  < cutoff:
               contact.append([i,j])
        if len(contact) > 0:
           contacts.append(contact)   
    return contacts           

def calulate_bind_site_helix(cb_atoms,p_atoms,cutoff):
    ankle1 = []
    ankle2 = []
    dna_length = 37
    dna_length = int(len(p_atoms)/4)
    print dna_length
    for i in range(73-1,91):
        ankle1.append(i)
    helix2 = []
    for i in range(73-1+91,189):
        ankle2.append(i)
    a1c = 0
    a2c = 0
    b1c = 0
    b2c = 0
    a1ic = 0
    a2ic = 0
    b1ic = 0
    b2ic = 0
    contacts = calulate_atoms(cb_atoms,p_atoms,cutoff)
    #Flag = "None"
    for i in range(len(contacts)):
        contact = contacts[i]
        p_id = contact[0][0]
        if p_id < 73:
           Flag1 = "aic"
        elif p_id < 91:
           Flag1 = "ac"
        elif p_id < 163:
           Flag1 = "bic"
        else:
           Flag1 = "bc"
        for j in range(len(contact)):
            if contact[j][1] < dna_length*2:
               if Flag1 == "aic":
                  a1ic += 1
               elif Flag1 == "ac":
                  a1c += 1
               elif Flag1 == "bic":
                  b1ic += 1
               elif Flag1 == "bc":
                  b1c += 1
               break
            else:
               continue
        for j in range(len(contact)):
            if contact[j][1] >= dna_length*2:
               if Flag1 == "aic":
                  a2ic += 1
               elif Flag1 == "ac":
                  a2c += 1
               elif Flag1 == "bic":
                  b2ic += 1
               elif Flag1 == "bc":
                  b2c += 1
               break
            else:
               continue           
    return a1c,a1ic,a2c,a2ic,b1c,b1ic,b2c,b2ic


def compute_angle_dump(dumpfile,cutoff):
    with open(dumpfile,'r') as fopen:
         lines = fopen.readlines()
    file_len       = get_file_len(dumpfile)
    nline_snapshot = get_nline_snapshot(dumpfile)
    n_snapshot     = file_len / nline_snapshot
    file_ncontacts1 = open("n_contacts_FIS1",'w')
    file_ncontacts2 = open("n_contacts_FIS2",'w')
    for i in range(n_snapshot):
        i_dump  = get_dump_i(dumpfile, i)
        ca_atoms, cb_atoms, o_atoms,p_atoms,o5_atoms = get_atoms_dump(i_dump)
        protein_length = len(cb_atoms)/2
        cb_atoms1 = []
        cb_atoms2 = []
        for i in range(protein_length):
            cb_atoms1.append(cb_atoms[i])
            cb_atoms2.append(cb_atoms[protein_length+i])
        print protein_length
        a1c,a1ic,a2c,a2ic,b1c,b1ic,b2c,b2ic = calulate_bind_site_helix(cb_atoms1,p_atoms,cutoff)
        file_ncontacts1.write(str(a1c)+" "+str(a1ic)+" "+str(a2c)+" "+str(a2ic)+" "+str(b1c)+" "+str(b1ic)+" "+str(b2c)+" "+str(b2ic)+"\n") 
        a1c,a1ic,a2c,a2ic,b1c,b1ic,b2c,b2ic = calulate_bind_site_helix(cb_atoms2,p_atoms,cutoff)
        file_ncontacts2.write(str(a1c)+" "+str(a1ic)+" "+str(a2c)+" "+str(a2ic)+" "+str(b1c)+" "+str(b1ic)+" "+str(b2c)+" "+str(b2ic)+"\n")
    file_ncontacts1.close()
    file_ncontacts2.close()

def main():
    dumpfile = sys.argv[1]
    cutoff = 12.0
    compute_angle_dump(dumpfile,cutoff)

if __name__ == '__main__':
    main()


        
