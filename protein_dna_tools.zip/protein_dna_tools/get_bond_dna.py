import os
import sys
psffile = sys.argv[1]
bondfile = sys.argv[2]
def get_bond_dna(psffile,bondfile):
    fileout = open(bondfile,'w')
    flag = 'off'
    with open(psffile,'r') as fopen:
     for line in fopen.readlines():
        #print line
        if flag == 'on':
    #        print line
            fileout.write(line)
        #print line
        if line != '\n' and line != '\t' and line != ' ': 
           # print line
           if line.split()[1] == "!NBOND":
                    flag = 'on' 
           elif line.split()[1] == "!NTHETA:":
                    flag = 'off'
        else:
                    flag = 'off'
    fileout.close()  

if __name__ == '__main__':
    get_bond_dna(psffile,bondfile) 
