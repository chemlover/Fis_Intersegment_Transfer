import os
import sys
inputfile = sys.argv[1]
outputfile = sys.argv[2]
snapshot = int(sys.argv[3])
with open(inputfile,'r') as fopen:
     lines = fopen.readlines()
flag = 0
data = ''
for line in lines:
    if line.split()[0] == 'END':
       flag += 1
    if flag == snapshot :
       data += line
    if flag == snapshot + 1:
       break
data += 'END\n'
with open(outputfile,'w') as fwrite:
     fwrite.writelines(data)
