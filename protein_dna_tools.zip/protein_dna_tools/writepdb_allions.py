import os
import sys
import numpy as np
from math import *
def get_ions_pdb(inputfile,ion):
    coord = []
    with open(inputfile,"r") as fopen:
         pdbpart = fopen.readlines()
    for line in pdbpart:
        if line.split()[0] == 'HETATM':
           if line.split()[2] == ion :
              x=float(line[30:38])
              y=float(line[38:46])
              z=float(line[46:54])
              coord = [x,y,z]
              
    print (ion,coord)
    return coord

def get_pesua_atoms(coord_ion,ion):
    coord=[]
    coord.append(coord_ion)
    dMN  = 2.082
    dCA  = 0.900
    dCO  = 2.196
    dFE2 = 2.173
    dCU1 = 2.147
    dCU  = 2.117
    dFE  = 2.121
    dK   = 1.099
    dMG  = 0.947
    dNA  = 1.010
    dNI  = 2.223
    dZN  = 2.109
    if ion == "FE" or ion == "CO" or ion == "CA" or ion == "MG" or ion == "MN":
       if ion == "FE":
            dist = dFE/sqrt(2)
       elif ion == "CO":
            dist = dCO/sqrt(2)
       elif ion == "CA":
            dist = dCA/sqrt(2)
       elif ion == "MG":
            dist = dMG/sqrt(2)
       elif ion == "MN":
            dist = dMN/sqrt(2)
       for i in range(2):
           for j in range(2):
                   x=coord_ion[0] + (-1)**i*dist
                   y=coord_ion[1] + (-1)**j*dist
                   z=coord_ion[2] 
                   atom=[x,y,z]
                   coord.append(atom)
       for k in range(2):
                   x=coord_ion[0]
                   y=coord_ion[1] 
                   z=coord_ion[2] + (-1)**k*dCA
                   atom=[x,y,z]
                   coord.append(atom)
    elif ion == "FE2" or ion == "NI":
       if ion == "FE2":
            dist = dFE2/sqrt(2)
       elif ion == "NI":
            dist = dNI/sqrt(2)
       for i in range(2):
           for j in range(2):
                   x=coord_ion[0] + (-1)**i*dist
                   y=coord_ion[1] + (-1)**j*dist
                   z=coord_ion[2]
                   atom=[x,y,z]
                   coord.append(atom)
       for k in range(1):
                   x=coord_ion[0]
                   y=coord_ion[1]
                   z=coord_ion[2] + (-1)**k*dCA
                   atom=[x,y,z]
                   coord.append(atom)
    elif ion == "CU":
       dist = dCU/sqrt(2)
       for i in range(2):
           for j in range(2):
                   x=coord_ion[0] + (-1)**i*dist
                   y=coord_ion[1] + (-1)**j*dist
                   z=coord_ion[2]
                   atom=[x,y,z]
                   coord.append(atom)
    elif ion == "K" or ion == "NA":
       if ion == "K":
            dist = dK/sqrt(3)
       elif ion == "NA":
            dist = dNA/sqrt(3)
       for i in range(2):
           for j in range(2):
               for k in range(2):
                   x=coord_ion[0] + (-1)**i*dist
                   y=coord_ion[1] + (-1)**j*dist
                   z=coord_ion[2] + (-1)**k*dist
                   atom=[x,y,z]
                   coord.append(atom)
    elif ion == "ZN" or ion == "CU1":
         if ion == "ZN":
            dist = dZN/4.0*6/5*2.2
         elif ion == "CU1":
            dist = dCU1/4.0*6/5*2.2
         x=coord_ion[0] - dist/sqrt(2)
         y=coord_ion[1] - sqrt(6)*dist/2.0
         z=coord_ion[2] - 0.5*dist
         atom=[x,y,z]
         coord.append(atom)
         x=coord_ion[0] - dist/sqrt(2)
         y=coord_ion[1] + sqrt(6)*dist/2.0
         z=coord_ion[2] - 0.5*dist
         atom=[x,y,z]
         coord.append(atom)
         x=coord_ion[0] - dist/sqrt(2) + 3* dist/sqrt(2)
         y=coord_ion[1] 
         z=coord_ion[2] - 0.5*dist
         atom=[x,y,z]
         coord.append(atom)
         x=coord_ion[0] 
         y=coord_ion[1] 
         z=coord_ion[2] - 0.5*dist + 2*dist
         atom=[x,y,z]
         coord.append(atom)
    return coord
         

def reload_pdb(outputfile,ion,coord):
    Flag = 0
    data = ""
    resname = " "
    for i in range(len(coord)):
        if Flag == 0:
           if ion == "CA":  
              resname = " CA"
              data += "HETATM" + str(1+i).rjust(5," ")+" CA    CA B   1    "+ str(round(coord[i][0],3)).rjust(8," ") + str(round(coord[i][1],3)).rjust(8," ") + str(round(coord[i][2],3)).rjust(8," ") + "  1.00  1.00            \n"
           elif ion == "FE2":
              resname = "FE2" 
              data += "HETATM" + str(1+i).rjust(5," ")+" FE   FE2 B   1    "+ str(round(coord[i][0],3)).rjust(8," ") + str(round(coord[i][1],3)).rjust(8," ") + str(round(coord[i][2],3)).rjust(8," ") + "  1.00  1.00            \n"      
           elif ion == "CU1":
              resname = "CU1"
              data += "HETATM" + str(1+i).rjust(5," ")+" CU   CU1 B   1    "+ str(round(coord[i][0],3)).rjust(8," ") + str(round(coord[i][1],3)).rjust(8," ") + str(round(coord[i][2],3)).rjust(8," ") + "  1.00  1.00            \n"
           elif ion == "CU":
              resname = "CU"
              data += "HETATM" + str(1+i).rjust(5," ")+" CU    CU B   1    "+ str(round(coord[i][0],3)).rjust(8," ") + str(round(coord[i][1],3)).rjust(8," ") + str(round(coord[i][2],3)).rjust(8," ") + "  1.00  1.00            \n"
           elif ion == "FE":
              resname = "FE"
              data += "HETATM" + str(1+i).rjust(5," ")+" FE    FE B   1    "+ str(round(coord[i][0],3)).rjust(8," ") + str(round(coord[i][1],3)).rjust(8," ") + str(round(coord[i][2],3)).rjust(8," ") + "  1.00  1.00            \n"
           elif ion == "NA":
              resname = "NA"
              data += "HETATM" + str(1+i).rjust(5," ")+" NA    NA B   1    "+ str(round(coord[i][0],3)).rjust(8," ") + str(round(coord[i][1],3)).rjust(8," ") + str(round(coord[i][2],3)).rjust(8," ") + "  1.00  1.00            \n"
           elif ion == "K":
              resname = "K"
              data += "HETATM" + str(1+i).rjust(5," ")+" K      K B   1    "+ str(round(coord[i][0],3)).rjust(8," ") + str(round(coord[i][1],3)).rjust(8," ") + str(round(coord[i][2],3)).rjust(8," ") + "  1.00  1.00            \n"
           elif ion == "MG":
              resname = "MG"
              data += "HETATM" + str(1+i).rjust(5," ")+" MG    MG B   1    "+ str(round(coord[i][0],3)).rjust(8," ") + str(round(coord[i][1],3)).rjust(8," ") + str(round(coord[i][2],3)).rjust(8," ") + "  1.00  1.00            \n"
           elif ion == "CO":
              resname = "CO"
              data += "HETATM" + str(1+i).rjust(5," ")+" CO    CO B   1    "+ str(round(coord[i][0],3)).rjust(8," ") + str(round(coord[i][1],3)).rjust(8," ") + str(round(coord[i][2],3)).rjust(8," ") + "  1.00  1.00            \n"
           elif ion == "NI":
              resname = "NI"
              data += "HETATM" + str(1+i).rjust(5," ")+" NI    NI B   1    "+ str(round(coord[i][0],3)).rjust(8," ") + str(round(coord[i][1],3)).rjust(8," ") + str(round(coord[i][2],3)).rjust(8," ") + "  1.00  1.00            \n"
           elif ion == "ZN":
              resname = "ZN"
              data += "HETATM" + str(1+i).rjust(5," ")+" ZN    ZN B   1    "+ str(round(coord[i][0],3)).rjust(8," ") + str(round(coord[i][1],3)).rjust(8," ") + str(round(coord[i][2],3)).rjust(8," ") + "  1.00  1.00            \n"
           elif ion == "MN":
              resname = "MN"
              data += "HETATM" + str(1+i).rjust(5," ")+" MN    MN B   1    "+ str(round(coord[i][0],3)).rjust(8," ") + str(round(coord[i][1],3)).rjust(8," ") + str(round(coord[i][2],3)).rjust(8," ") + "  1.00  1.00            \n"
        else:
              data += "HETATM" + str(1+i).rjust(5," ")+" KK   "+resname.rjust(3," ")+" B   1    "+ str(round(coord[i][0],3)).rjust(8," ") + str(round(coord[i][1],3)).rjust(8," ") + str(round(coord[i][2],3)).rjust(8," ") + "  1.00  1.00            \n"
        Flag += 1
    with open(outputfile,"w") as fwrite:
         fwrite.writelines(data)
inputfile = sys.argv[1]
outputfile = sys.argv[2]
ion = sys.argv[3]
coord_ion = get_ions_pdb(inputfile,ion)
coord = get_pesua_atoms(coord_ion,ion)
reload_pdb(outputfile,ion,coord)
