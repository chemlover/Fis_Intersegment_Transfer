import os
import sys
import numpy as np

def mergy_matrix_aspart(matrix1,matrix2):
    [m,m] = np.shape(matrix1)
    [n,n] = np.shape(matrix2)
    length = m+n
    matrix = np.zeros((length,length))
    for i in range(m):
        for j in range(m):
            matrix[i][j] = matrix1[i][j]
    for i in range(n):
        for j in range(n):
            matrix[m+i][m+j] = matrix2[i][j]
    return matrix

def main():
    inputfile1 = sys.argv[1]
    matrix1 = np.loadtxt(inputfile1)
    inputfile2 = sys.argv[2]
    matrix2 = np.loadtxt(inputfile2)
    outputfile = sys.argv[3]
    matrix = mergy_matrix_aspart(matrix1,matrix2)
    np.savetxt(outputfile,matrix,fmt="%.3f",delimiter= " ")

if __name__ == '__main__':
    main()


    
