################################################
#   Calculate local bending angle of a single  #
#   DNA in a dump file			       #
#   Input: dump file		   	       #
#   Output: txt file		   	       #
#	    column: base pair index  	       #
#	    row: snapshot index      	       #
#	    last row: (optional): Average Y/N  #
#		      mean of each base pair   #
#		      local bending angle      #
################################################

import math
import sys
import numpy as np
from math import *

class Atom:
        def __init__(self, id):
                self.id = 0
                self.type = 0
                self.x = x
                self.y = y
                self.z = z

        def read_atom_(self, id, type, x, y, z):
		self.id = id
                self.type = type
                self.x = x
                self.y = y
                self.z = z

def convertx(a,up,low):
	return((up-low)*(a)+low)
def converty(a,up,low):
        return((up-low)*a+low)
def convertz(a,up,low):
        return((up-low)*a+low)
def dumpx(a,up,low):
	return((a-low)/(up-low))
def dumpy(a,up,low):
        return((a-low)/(up-low))
def dumpz(a,up,low):
        return((a-low)/(up-low))
	
def cal_ang(ba,bc):
	cosine_angle = np.dot(ba, bc) / (np.linalg.norm(ba) * np.linalg.norm(bc))
	angle = (np.arccos(cosine_angle)/3.14159265359*180)
	return angle

if len(sys.argv)<3 or len(sys.argv)>5:
        print "\n" + sys.argv[0] + " -Average Y/N <Input_file> <Output_file>"
        exit()
amean = 0
if sys.argv[1]=="-Average":
	if sys.argv[2]=='Y' or sys.argv[2]=='y':
		amean = 1; del sys.argv[1]; del sys.argv[1]
	elif sys.argv[2]=='N' or sys.argv[2]=='n':
		amean = 0; del sys.argv[1]; del sys.argv[1]
	else:
		print "\n" + sys.argv[0] + " -Average Y/N <Input_file> <Output_file_taolao>"
        	exit()
lammps_file = sys.argv[1]
step = []
latom = []
lbox = []
dem = -1
n = -1
lfile = open(lammps_file)
for l in lfile:
	dem = dem+1
	l = l.strip()
	if l[:14]=="ITEM: TIMESTEP":
        	n = n+1
		step.append(n)                
	elif l[:14]=="ITEM: NUMBER O" and dem<100:
		lNatom = dem+1
	elif l[:14]=="ITEM: BOX BOUN":
		Lbox = dem+1
		lbox.append(Lbox)
	elif l[:14]=="ITEM: ATOMS id":
		n = dem+1
		latom.append(n)
	else:
		continue

with open(lammps_file) as f:
	content = f.readlines()

Natom = int(content[lNatom].strip())

low = []
up = []
for k in range(len(step)):
    for i in range(3):
	line = content[lbox[k]+i].strip().split()
	l = float(line[0])
	u = float(line[1])
	low.append(l)
	up.append(u)
low = np.reshape(low,(len(step),3))
up = np.reshape(up,(len(step),3))
x = []
y = []
z = []
result = []
for s in range(len(step)):
	temp = latom[s]
	NP = 0
	for i in range(Natom):		
		line = content[temp+i].strip().split()
		if int(line[1]) == 1:
			NP = NP+1
			x.append(convertx(float(line[2]),up[s][0],low[s][0]))
			y.append(converty(float(line[3]),up[s][1],low[s][1]))
			z.append(convertz(float(line[4]),up[s][2],low[s][2]))
x = np.reshape(x,(len(step),NP))
y = np.reshape(y,(len(step),NP))
z = np.reshape(z,(len(step),NP))

a = np.zeros((len(step),NP/2))
b = np.zeros((len(step),NP/2))
c = np.zeros((len(step),NP/2))
for i in range(len(step)):
	for j in range (NP/2):
		a[i][j]=((x[i][j]+x[i][NP-j-1])/2)
		b[i][j]=((y[i][j]+y[i][NP-j-1])/2)
		c[i][j]=((z[i][j]+z[i][NP-j-1])/2)
#a = np.reshape(a,(len(step),NP/2))
#b = np.reshape(b,(len(step),NP/2))
#c = np.reshape(c,(len(step),NP/2))
ti = []
from math import *
#print np.shape(a[1,:])
np.savetxt("ti.txt",a[1],fmt="%.3f",delimiter=" ")
for i in range(len(step)):
	#for j in range (0,int((NP/2)/10)):
                j=50
                k=j
                #print np.shape(a[i,:])
                # print a[i]
		x1 = [a[i][k-10],b[i][k-10],c[i][k-10]]
		x2 = [a[i][k-1],b[i][k-1],c[i][k-1]]
		y1 = [a[i][k],b[i][k],c[i][k]]
		y2 = [a[i][k+9],b[i][k+9],c[i][k+9]]
		x = [x1[0] - x2[0],x1[1] - x2[1],x1[2] - x2[2]]
		y = [y1[0] - y2[0],y1[1] - y2[1],y1[2] - y2[2]]
                l=sqrt((x[0]*y[0] + x[1]*y[1] + y[2]*y[2])**2/((x[0]**2+x[1]**2+x[2]**2)*(y[0]**2+y[1]**2+y[2]**2)))
                ti.append(l)
np.savetxt("ti.txt",ti,fmt="%.3f",delimiter="\n")

