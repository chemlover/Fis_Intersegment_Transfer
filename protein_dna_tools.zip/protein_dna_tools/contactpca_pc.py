import os
import sys
import numpy as np 
import math 
referencefile = sys.argv[1]
pcfile = sys.argv[2]
pcnumber = int(sys.argv[3])-1

def pc_contacts_matrix(reference,pc,pcnumber):
    pc_get = pc[pcnumber,:]
    print len(pc_get)
    contactsm = []
    contactsp = []
    cutoffp = []
    cutoffm = []
    stone = np.min(np.array(reference)) - 1
    for i in range(len(pc_get)):
        cutoff = (reference[i] - stone)/ pc_get[i]
        if cutoff >= 0:
           cutoffp.append(cutoff)  
        else:
           cutoffm.append(cutoff)
    cutoff1 = np.min(np.array(cutoffp))
    cutoff2 = abs(np.max(np.array(cutoffm)))
    #print cutoff1 
    #print cutoff2
    for i in range(len(pc_get)):
        contactp = reference[i]-cutoff1*pc_get[i] 
        contactsp.append(contactp)
        contactm = reference[i]-cutoff2*pc_get[i]
        contactsm.append(contactm)
    #print contactsp
    #print contactsm
    #print len(contactsp),len(contactsm)
    return contactsp,contactsm

def reshape_contacts(contacts):
    length = int(math.sqrt(len(contacts)*2)//1+1)
    distmap = np.zeros((length,length))
    contactmap = np.zeros((length,length))
    k=0
    for i in range(length):
        for j in range(i+1,length):
    #        print contacts[k]
            distmap[i][j] = contacts[k]
            distmap[j][i] = distmap[i][j]
            k = k + 1 
    return distmap

def get_contactmap_from_distmap(distmap,cutoff):
    [m,n] = np.shape(distmap)
    contactmap = np.zeros((m,m))
    for i in range(m):
        for j in range(i+1,m):
           if  distmap[i][j] <= cutoff:
               contactmap[i][j] = 1
               contactmap[j][i] = contactmap[i][j]
    return contactmap


def main():
    referencefile = sys.argv[1]
    pcfile = sys.argv[2]
    pcnumber = int(sys.argv[3])-1
    reference = np.loadtxt(referencefile)
    pc = np.loadtxt(pcfile)
    contactsp,contactsm = pc_contacts_matrix(reference,pc,pcnumber)
    distmapp = reshape_contacts(contactsp)
    filename =  "distmapp-pc"+str(pcnumber) + ".txt"
    np.savetxt(filename,distmapp,fmt="%.3f",delimiter=" ")
    distmapm = reshape_contacts(contactsm)
    filename =  "distmapm-pc"+str(pcnumber) + ".txt"
    np.savetxt(filename,distmapm,fmt="%.3f",delimiter=" ")
    cutoff = 12
    filename =  "contactmapp-pc"+str(pcnumber) + ".txt"
    contactmapp = get_contactmap_from_distmap(distmapp,cutoff)
    np.savetxt(filename,contactmapp,fmt="%.3f",delimiter=" ")
    filename =  "contactmapm-pc"+str(pcnumber) + ".txt"
    contactmapm = get_contactmap_from_distmap(distmapm,cutoff)
    np.savetxt(filename,contactmapm,fmt="%.3f",delimiter=" ")

if __name__ == '__main__':
    main()

