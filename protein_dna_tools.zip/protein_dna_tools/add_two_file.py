import sys
import os
import numpy as np
file1=sys.argv[1]
file2=sys.argv[2]
outputfile=sys.argv[3]
data1=np.loadtxt(file1)
data2=np.loadtxt(file2)
outdata=np.zeros(len(data1))
for i in range(len(data1)):
      outdata[i] = data1[i]+data2[i]
np.savetxt(outputfile,outdata,fmt="%.3f",delimiter=" ")
