import numpy as np
import mdtraj as md
import sys

def get_atom_sasa(pdbfile):
    trajectory = md.load(pdbfile)
    sasa_atoms = md.shrake_rupley(trajectory,mode='atom')
    return sasa_atoms

def get_res_sasa(pdbfile):
    trajectory = md.load(pdbfile)
    sasa_res = md.shrake_rupley(trajectory,mode='residue')
    #print sasa_res[0][1]
    return sasa_res

def get_sasa_combo(sasa):
    length = len(sasa[0])
    index = np.arange(1,length+1,1) 
    combo = []
    for i in range(length):
        combo_single = [index[i],sasa[0][i]*100]
        combo.append(combo_single)
    return combo


def main():
    pdbfile = sys.argv[1]
    outputfile = sys.argv[2]
    #sasa_res = get_res_sasa(pdbfile)
    trajectory = md.load(pdbfile)
    sasa = md.shrake_rupley(trajectory)
    #print sasa
    #combo_res = get_sasa_combo(sasa_res)
    np.savetxt(outputfile,sasa,fmt="%.3f",delimiter= " ")


if __name__ == '__main__':
    main()

