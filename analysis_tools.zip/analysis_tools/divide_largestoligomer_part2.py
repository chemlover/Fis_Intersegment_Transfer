import os
import sys
import numpy as np
pdbfile = sys.argv[1]
recordfile = sys.argv[2]
order=int(sys.argv[3])
startpdbfile = sys.argv[4]
data=np.loadtxt(recordfile)
NUM1 = int(data[order-1][0])
NUM2 = int(data[order-1][1])
exeline="head -n"+str(NUM1)+" "+pdbfile+" | tail -n"+str(NUM2) + ">" + startpdbfile;
print exeline
stdout=os.popen(exeline).readlines()

