# ----------------------------------------------------------------------
# Copyright (2013) Weihua Zheng@Wolynes group, Rice University
# Last Update: 03/16/2013
# ----------------------------------------------------------------------
#from Bio.PDB.PDBParser import PDBParser
#from Bio.SVDSuperimposer import SVDSuperimposer
from math import *
import numpy as np ## array_2d =  zeros([10 10], float)
import os
import sys

atom_desc = {'1' : 'C-Alpha', '2' : 'N', '3' : 'O', '4' : 'C-Beta', '5' : 'H-Beta', '6' : 'C-Prime'}
PDB_type = {'1' : 'CA', '2' : 'N', '3' : 'O', '4' : 'CB', '5' : 'HB', '6' : 'C' }

def vector(p1, p2):
    return [p2[0]-p1[0], p2[1]-p1[1], p2[2]-p1[2]]

def vabs(a):
    return sqrt(pow(a[0],2)+pow(a[1],2)+pow(a[2],2))

def sigma_sq(sep):
        return pow((1+sep),0.15)*pow((1+sep), 0.15)

def calc_dist(p1, p2):
        v=vector(p1,p2)
        return vabs(v)
def get_atoms(pdb_part):
    ca_atoms = []
    cb_atoms = []
    n_atoms = []
    o_atoms = []
    c_atoms = []
    h_atoms = []
    p_atoms = []
    s_atoms = []
    base_atoms = []
    cap_atoms = []
    for line in pdb_part:
        if line.split()[0] != 'END' or line.split()[0] != 'ENDMDL':
           #if line.split()[2] == 'CA' or line.split()[2] == 'S':
           #print linei
         if len(line.split()) > 5:
           x=float(line[30:38])
           y=float(line[38:46])
           z=float(line[46:54])
           atom = [x,y,z]
           if line.split()[2] == "CA":
                 ca_atoms.append(atom)
                 cap_atoms.append(atom)
                 if line.split()[3] == "GLY":
                    cb_atoms.append(atom)
           elif line.split()[2] == "C":
                 c_atoms.append(atom)
           elif line.split()[2] == "N":
                 n_atoms.append(atom)
           elif line.split()[2] == "O":
                 o_atoms.append(atom)
           elif line.split()[2] == "H":
                 h_atoms.append(atom)
           elif line.split()[2] == "CB":
                 cb_atoms.append(atom)
           elif line.split()[2] == "P":
                 p_atoms.append(atom)
                 cap_atoms.append(atom)
           elif line.split()[2] == "S":
                 s_atoms.append(atom)
           elif line.split()[2] == "A" or line.split()[2] == "T" or line.split()[2] == "G" or line.split()[2] == "C" :
                 base_atoms.append(atom)

    return ca_atoms,cb_atoms,n_atoms,o_atoms,c_atoms,h_atoms,p_atoms,s_atoms,base_atoms,cap_atoms

def  CalQ(ca_atoms1,ca_atoms2):
        Qsum = 0
        norm = 0
        N = len(ca_atoms1)
        #print N
        min_sep = 3
        nres = np.min([len(ca_atoms1),len(ca_atoms2)])
        #print nres  #if qo_flag == 1 : min_sep = 4
        #min_sep =3
        for ia in range(0, nres):
                for ja in range(ia+min_sep, nres):
                        #if (splitq and pdb_chain_id[ia]==pdb_chain_id[ja]) or not splitq:

                                rn = vabs(vector(ca_atoms1[ia], ca_atoms1[ja]))
                                #if qo_flag == 1 and rn >= cutoff : continue

                                r = vabs(vector(ca_atoms2[ia], ca_atoms2[ja]))
                                dr = r - rn
                                #if splitq: index = pdb_chain_id[ia]
                                #else: index = 1
                                #if not Q.has_key(index):
                                 #       Q[index] = 0.0
                                  #      norm[index] = 0
                                #change
                                #if ( not splitq ) and ( pdb_chain_id[ia] != pdb_chain_id[ja] ) :
                                #print dr
                                #print sigma_sq[abs(ia-ja)]
                                Qsum = Qsum + exp(-dr*dr/(2*sigma_sq(abs(ia-ja))))
                                #else: #change
                                norm += 1#= Q[index] + exp(-dr*dr/(2*sigma_sq[ja-ia]))
                                #change

                                #norm[index] = norm[index] + 1
        #for key in Q:
                Q=Qsum/norm
        return Q

def main():
     pdbfile1 = sys.argv[1]
     pdbfile2 = sys.argv[2]
     with open(pdbfile1,"r") as fopen:
          pdb1 = fopen.readlines()
     with open(pdbfile2,"r") as fopen:
          pdb2 = fopen.readlines()
     ca_atoms1,cb_atoms,n_atoms,o_atoms,c_atoms,h_atoms,p_atoms1,s_atoms,base_atoms,cap_atoms1 = get_atoms(pdb1)
     ca_atoms2,cb_atoms,n_atoms,o_atoms,c_atoms,h_atoms,p_atoms2,s_atoms,base_atoms,cap_atoms2 = get_atoms(pdb2)
     #print ca_atoms1
     Q = CalQ(cap_atoms1,cap_atoms2)
     print Q
if __name__ == '__main__':
    main()


