import sys
import os
# this scipt is one of pre-script of compute_Q which will use lots of time, in this scipt, it divide it in several part to run which will run on the cluster
# this script is to compute the part Q of generated index file
inputfile = './index_compute_Q.txt'
order_part = int(sys.argv[1])
part_num = int(sys.argv[2])
Nmer = sys.argv[3]
Chainlength = sys.argv[4]
qo_flag = sys.argv[5]
outputfile  = str(order_part) + '_part_Q.txt'
inputfile = sys.argv[6]
with open(inputfile,'r') as fopen:
    lines=fopen.readlines()
length = len(lines) 
space = int (length / part_num) + 1 
N_begin = order_part * space - space 
print order_part
if order_part == part_num:
   N_final = length 
else:
   N_final = order_part * space 
if length / part_num <= 1:
#   print order_part
   N_begin = order_part - 1
   N_final = order_part 
for i in range(N_begin,N_final):
 #   print i
 #   print N_final
    pdbid1 = lines[i].split()[0]
    pdbid2 = lines[i].split()[1] 
    os.system("python /home/xc25/analysis_tools/Calcu_premutation.py %s.pdb %s.pdb %s %s %s >> %s"%(pdbid1,pdbid2,Nmer,Chainlength,qo_flag,outputfile))
