import numpy as np 
import sys
# this scipt is one of pre-script of compute_Q which will use lots of time, in this scipt, it divide it in several part to run which will run on the cluster
# this scipt is to generate the i j file to compute Q, which can divide in serveal part
outputfile = './index_compute_Q.txt'
num = int(sys.argv[1])
data = ''
for i in range(num-1):
   for j in range(i+1,num-1):
       data += str(i+1) + ' ' + str(j+1) + '\n'
with open(outputfile,'w') as fwrite:
   fwrite.writelines(data)
  
