#!/usr/bin/python
# ----------------------------------------------------------------------
# Copyright (2010) Aram Davtyan and Garegin Papoian
#
# Mod by Zheng 09/2014####
# Function:
# Designed for Abeta oligomers
# Count the number of intra & inter-monomer beta hydrogen bonds
# Output: Intra_count, Inter_count
# ----------------------------------------------------------------------

from Bio.PDB.PDBParser import PDBParser
from Bio.SVDSuperimposer import SVDSuperimposer
from math import *
import numpy ## array_2d =  zeros([10 10], float)
import os
import sys

def vector(p1, p2):
    return [p2[0]-p1[0], p2[1]-p1[1], p2[2]-p1[2]]

def vabs(a):
    return sqrt(pow(a[0],2)+pow(a[1],2)+pow(a[2],2))

def get_lines_pdbfile(pdbfile):
    nlines = 0
    with open(pdbfile,"r") as fopen:
         for line in fopen.readlines():
             nlines += 1
             if line.split()[0] == "END":
                return nlines

def getline_range(filename, line1, line2):
    assert(line1 <= line2)
    nline=line2-line1+1
    exeline="head -n"+str(line2)+" "+filename+" | tail -n"+str(nline) ;
    #print exeline
    stdout=os.popen(exeline).readlines()
    return stdout

def get_pdbfile_i(pdbfile,i,n_lines):
     #   nline=get_nline_snapshot(pdbfile)
        line_start = 1 + n_lines*i ; line_end = n_lines*(i+1)
        print n_lines
        pdb_part=getline_range(pdbfile, line_start, line_end)
        return pdb_part

def get_ca(pdbfile):
        p=PDBParser(PERMISSIVE=1)
        ca_atoms = []
        s = p.get_structure(pdbfile,pdbfile)
        chains = s[0].get_list()
        for chain in chains:
                for res in chain:
                        is_regular_res = res.has_id('CA') and res.has_id('O')
                        res_id = res.get_id()[0]
                        if (res_id==' ' or res_id=='H_MSE' or res_id=='H_M3L' or res_id=='H_CAS' ) and is_regular_res:
                                resname = res.get_resname();
                                ca_atoms.append(res['CA'].get_coord())
                        else :
                                print "Pdb file contains irregular residue names or missing CA / O atoms! Fix it and run again! Exit with error."
                                print "res_id :", res_id
                                sys.exit()
        return ca_atoms

def get_n_chains(pdbfile):
        p=PDBParser(PERMISSIVE=1)
        s = p.get_structure(pdbfile,pdbfile)
        chains = s[0].get_list()
        return len(chains)


def count_beta_contact(ca_atoms_pdb, ca_atoms, Nmer, len_linker, cutoff):
        Ntotal     = len(ca_atoms);
        N_mono = len(ca_atoms_pdb);
        N_A = (Ntotal - (Nmer-1)*len_linker)/Nmer
        #print Ntotal, N_mono, Nmer, len_linker
        if N_mono != N_A :
                print "N_mono=", N_mono, "N_A=", N_A
                print "Homogenous peptides are required!"
                print "Only apply this code to domains with the same length! Exit with error!"
                sys.exit()
        print Ntotal, N_mono, Nmer, len_linker

        l_intra=[0]*2  #intra-antipara, intra-para 
        l_inter=[0]*2  #inter-antipara, inter-para 
        min_sep = 5
        count=0
        for i in range(Nmer):
                #start_shift=max(0, res_start-1); end_shift=min(N_mono, res_end)
                i_start = i*(N_mono+len_linker); i_end = i_start + N_mono
                #i_start = i*(N_mono+len_linker)+start_shift ; i_end = i_start + end_shift
                for j in range(i,Nmer):
                        j_start = j*(N_mono+len_linker); j_end = j_start + N_mono
                        for ia in range(i_start, i_end):
                                for ja in range(j_start,j_end):
                                        if i==j : #intra
                                                if ja-ia < min_sep : continue
                                                else :
                                                        ia_mono = ia - i_start ; ja_mono = ja - j_start
                                                        if ia_mono == 0 or ja_mono == N_mono -1 : continue
                                                        r1=  vabs(vector(ca_atoms[ia],     ca_atoms[ja]))
                                                        r2=  vabs(vector(ca_atoms[ia-1],   ca_atoms[ja+1]))
                                                        r3=  vabs(vector(ca_atoms[ia+1],   ca_atoms[ja+1]))
                                                        if r1 <= cutoff and r2 <= cutoff : #anti-para
                                                                l_intra[0]+=1
                                                        if r1 <= cutoff and r3 <= cutoff : #para
                                                                l_intra[1]+=1
                                        else :   #inter
                                                ia_mono = ia - i_start ; ja_mono = ja - j_start
                                                if ia_mono == 0 or ja_mono == N_mono -1 : continue
                                                r1=  vabs(vector(ca_atoms[ia],     ca_atoms[ja]))
                                                r2=  vabs(vector(ca_atoms[ia-1],   ca_atoms[ja+1]))
                                                r3=  vabs(vector(ca_atoms[ia+1],   ca_atoms[ja+1]))
                                                if r1 <= cutoff and r2 <= cutoff : #anti-para
                                                        l_inter[0]+=1
                                                if r1 <= cutoff and r3 <= cutoff : #para
                                                        l_inter[1]+=1
        return l_intra, l_inter
def Calu_hydrogen_bond(mono_ca_atoms,targetpdb,Nmer,len_linker,cutoff):
    ca_atoms=get_ca(targetpdb)
    intra_count, inter_count = count_beta_contact(mono_ca_atoms, ca_atoms, Nmer, len_linker, cutoff) #recommend cutoff=5.36 A
    return intra_count, inter_count
def main():
  if len(sys.argv)!=8:
	print "\n.py mono.pdb pdb_start pdb_end Output_file Nmer len_linker HB_CA_cutoff(recommend:5.36)\n"
	print
	sys.exit()

  pdb_file=sys.argv[1]
  pdb_start_id = int(sys.argv[2])
  pdb_end_id = int(sys.argv[3])
  #out_file = sys.argv[3]
  Nmer=     int(sys.argv[4])
  len_linker =int(sys.argv[5]) 
  cutoff=float(sys.argv[6])
  out_file = sys.argv[7]

  n_chains=get_n_chains(pdb_file)
  if n_chains > 1 :
	print "mono.pdb should have only one chain!"
	print " Exit with Error."
	sys.exit()
  out = open(out_file,"w")
  ca_atoms=get_ca(pdb_file)
  for i in range(pdb_start_id,pdb_end_id+1):
        targetpdb=str(i)+".pdb"
   	#assert(len(ca_atoms) == n_atoms/3)
	#native_count, nonnative_count = Zheng_func.fused_count_contact(ca_atoms_pdb, ca_atoms, Nmer, len_linker, cutoff)
	#OUTPUB [intra_count, inter_count] = [(anti-para HB, para HB), (anti-para HB, para HB)]
	intra_count, inter_count = Calu_hydrogen_bond(ca_atoms,targetpdb,Nmer,len_linker,cutoff)
	str1=' '.join(map(str,intra_count))
	str2=' '.join(map(str,inter_count))
	#for item in inter_count :
	#	str0=' '.join(map(str,item))
	#	str2+=' '+str0
        #print intra_count
        #print inter_count
	#print str1+str2
	out.write(str1+' '+str2)
	out.write('\n')
  out.close()
if __name__ == '__main__':
    main()

