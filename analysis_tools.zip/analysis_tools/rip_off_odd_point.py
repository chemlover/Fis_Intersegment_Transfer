import os
import sys
import numpy as np
import math 


def rip_off_odd_point(results,windows_num,outputfile):
 num = len(results)
 window_num = int(num/windows_num)
 data_refined = np.zeros(num)
 data_window = np.zeros(windows_num)

#get the average of window

 for i in range(windows_num):
    for j in range(i*window_num,i*window_num+window_num-1):
        data_window[i] += results[j]/window_num
 print data_window
# refine the data

 for i in range(num):
    compare_order = i // window_num
    crit = data_window[compare_order]
    if abs(results[i]-crit) > abs(crit/6.0):
       if i > 0:
        data_refined[i] = data_refined[i-1]
       else:
        data_refined[i] = crit
       print crit
       print results[i]
       print results[i]-crit
    else:
       data_refined[i] = results[i]
    #print compare_order
    #print data_window[compare_order]
    #print data_refined[i]
    #print results[i]
 np.savetxt(outputfile,data_refined,fmt="%.3f",delimiter=' ')

def main():
   inputfile = sys.argv[1]
   results = np.loadtxt(inputfile)
   windows_num = int(sys.argv[2])
   outputfile = inputfile + '-refined'
   rip_off_odd_point(results,windows_num,outputfile)

if __name__ == '__main__':
    main()

