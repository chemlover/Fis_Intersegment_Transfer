#!/usr/bin/python
# ----------------------------------------------------------------------
# Copyright (2010) Aram Davtyan and Garegin Papoian
#
# Mod by Zheng 09/2014####
# Function:
# Designed for Abeta oligomers
# Count the number of intra & inter-monomer beta hydrogen bonds
# Output: Intra_count, Inter_count
# ----------------------------------------------------------------------

import sys
import Zheng_func
import os
from math import *
pdb_file=Zheng_func.pdbname(sys.argv[1])
traj_file = sys.argv[2]
out_file = sys.argv[3]
#Nmer=     int(sys.argv[4])
#len_linker =int(sys.argv[5]) 
#cutoff=float(sys.argv[6])

#n_chains=Zheng_func.get_n_chains(pdb_file)
#if n_chains > 1 :
#	print "mono.pdb should have only one chain!"
#	print " Exit with Error."
#	sys.exit()

ca_atoms_pdb=Zheng_func.get_ca(pdb_file)
#file_len=Zheng_func.get_file_len(dump_file)
#print file_len
#line = Zheng_func.getline_range(dump_file, 4, 4); line=line[0].split() ; #get number of atoms
#n_atoms=int(line[0]) ; nline=n_atoms + 9
#print n_atoms

#n_snapshot=file_len / nline

def get_file_len(filename):
    exeline="wc -l "+filename ;
    stdout=os.popen(exeline).readline();
    stdout=stdout.split()
    return int(stdout[0])


def get_pdbfile_line_atoms(filename):
    file_len = get_file_len(filename)
    with open(filename,'r') as fopen:
         lines = fopen.readlines()
    n_atoms = 0
    n_lines = 0
    for line in lines:
        n_lines += 1
        if line.split()[0] == "END" or line.split()[0] == "ENDMDL":
           break
        elif len(line.split()) > 5:
           if line.split()[2] == "CA" or line.split()[2] == "S":
              n_atoms += 1

    n_snapshot = file_len/n_lines
    return n_snapshot,n_lines,n_atoms

def getline_range(filename, line1, line2):
    assert(line1 <= line2)
    nline=line2-line1+1
    exeline="head -n"+str(line2)+" "+filename+" | tail -n"+str(nline) ;
    #print exeline
    stdout=os.popen(exeline).readlines()
    return stdout

def get_pdbfile_i(pdbfile, i,n_lines):
     #   nline=get_nline_snapshot(pdbfile)
        line_start = 1 + n_lines*i ; line_end = n_lines*(i+1)
        pdb_part=getline_range(pdbfile, line_start, line_end)
        return pdb_part

def get_atoms(pdb_part):
    ca_atoms = []
    cb_atoms = []
    n_atoms = []
    o_atoms = []
    c_atoms = []
    h_atoms = []
    for line in pdb_part:
        if line.split()[0] != 'END' or line.split()[0] != 'ENDMDL':
           #if line.split()[2] == 'CA' or line.split()[2] == 'S':
           #print linei
         if len(line.split()) > 5:
           x=float(line[30:38])
           y=float(line[38:46])
           z=float(line[46:54])
           atom = [x,y,z]
           if line.split()[2] == "CA":
                 ca_atoms.append(atom)
                 if line.split()[3] == "IGL" or "GLY":
                    cb_atoms.append(atom)
           elif line.split()[2] == "C":
                 c_atoms.append(atom)
           elif line.split()[2] == "N":
                 n_atoms.append(atom)
           elif line.split()[2] == "O":
                 o_atoms.append(atom)
           elif line.split()[2] == "H":
                 h_atoms.append(atom)
           elif line.split()[2] == "CB":
                 cb_atoms.append(atom)
    return ca_atoms,cb_atoms,n_atoms,o_atoms,c_atoms,h_atoms

def vector(p1, p2):
    return [p2[0]-p1[0], p2[1]-p1[1], p2[2]-p1[2]]

def vabs(a):
    return sqrt(pow(a[0],2)+pow(a[1],2)+pow(a[2],2))

def sigma_sq(sep):
        return pow((1+sep),0.15)*pow((1+sep), 0.15)

def calc_dist(p1, p2):
        v=vector(p1,p2)
        return vabs(v)

def CalQwQo(ca_atoms1,ca_atoms2):
    length = len(ca_atoms1)
    qwsum =0
    qw = 0 
    qosum = 0
    qo = 0 
    for i in range(length):
        for j in range(i+3,length):
            r1 = calc_dist(ca_atoms1[i],ca_atoms1[j])
            r2 = calc_dist(ca_atoms2[i],ca_atoms2[j])
            dr = r1 - r2
            if r1 < 12.0:
               qosum += 1
               qo += exp(-dr*dr/(2*sigma_sq(abs(i-j))))
            qwsum += 1
            qw += exp(-dr*dr/(2*sigma_sq(abs(i-j))))
    return qw/qwsum,qo/qosum
            
n_snapshot,n_lines,n_atoms = get_pdbfile_line_atoms(traj_file)
out = open(out_file, 'w')
for i in range(n_snapshot):
	#line_start = 1 + nline*i ; line_end = nline*(i+1)
	#dump_part=Zheng_func.getline_range(dump_file, line_start, line_end)
	#ca_atoms=Zheng_func.get_ca_dump(dump_part)
   	#assert(len(ca_atoms) == n_atoms/3)
        pdb_part =  get_pdbfile_i(traj_file, i,n_lines)
        ca_atoms,cb_atoms,n_atoms,o_atoms,c_atoms,h_atoms = get_atoms(pdb_part)
	#native_count, nonnative_count = Zheng_func.fused_count_contact(ca_atoms_pdb, ca_atoms, Nmer, len_linker, cutoff)
	#OUTPUB [intra_count, inter_count] = [(anti-para HB, para HB), (anti-para HB, para HB)]
	#intra_count, inter_count = Zheng_func.count_beta_contact(ca_atoms_pdb, ca_atoms, Nmer, len_linker, cutoff) #recommend cutoff=5.36 A
        qw,qo = CalQwQo(ca_atoms_pdb,ca_atoms)
	#str1=' '.join(map(str,intra_count))
	#str2=' '.join(map(str,inter_count))
	#for item in inter_count :
	#	str0=' '.join(map(str,item))
	#	str2+=' '+str0
        #print intra_count
        #print inter_count
	#print str1+str2
	out.write(str(qw)+' '+str(qo))
	out.write('\n')

out.close()
