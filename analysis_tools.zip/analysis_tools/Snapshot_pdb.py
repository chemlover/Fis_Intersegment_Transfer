import os 
import sys
Pdbfile = sys.argv[1] # trajctory pdb file
folder = sys.argv[2]  # stored folder under current folder
Num = 1
with open(Pdbfile,'r') as fopen:
   data = ''
   for line in fopen.readlines():
    if line.split()[0] == 'END':
       pdbfile = folder + '/' + str(Num) + '.pdb' 
       Num += 1
       with open(pdbfile,'w') as fwrite:
           fwrite.writelines(data)
           data = ''
    else :
           data += line
