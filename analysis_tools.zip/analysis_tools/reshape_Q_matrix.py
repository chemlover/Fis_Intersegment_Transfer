import numpy as np
import sys
# this scipt is one of pre-script of compute_Q which will use lots of time, in this scipt, it divide it in several part to run which will run on the cluster
# this script is to convert the Q_file to matrix, which Q file is unrepeated compute index
N = int(sys.argv[1])
inputfile = sys.argv[2]
outputfile = sys.argv[3]
Q_matrix = np.zeros((N,N))
Q_get = np.loadtxt(inputfile)
for i in range(N):
  Q_matrix[i-1][i-1] = 1
flag = 0
for i in range(N):
    for j in range(i+1,N):
        Q_matrix[i][j] = Q_get[flag] 
        Q_matrix[j][i] = Q_get[flag]
        flag += 1
np.savetxt(outputfile,Q_matrix,fmt = "%.3f", delimiter = ' ')
