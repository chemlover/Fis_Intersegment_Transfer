import itertools 
import sys
#G=nx.Graph();
#G.add_nodes_from([1,2,3,4,5,6,7,8])
#G.add_edges_from([(1,2),(1,3)])
#print (list(nx.connected_components(G)))
#for e in list(nx.connected_components(G))[0]:
N =4
n_res = 2
residue_reshape_list = [range(N)[i:i+n_res] for i in range(0,N,n_res)]
for i in range(0,N,n_res) :
    print i


print residue_reshape_list
