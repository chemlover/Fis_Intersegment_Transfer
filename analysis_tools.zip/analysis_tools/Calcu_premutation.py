import sys
import numpy as np
from itertools import permutations
from math import *
#  the script is to compute the permutation Q of aggregation project
#  the chain number is not always as same order in the prepared file, so under permutation, the largest Q is what we want 

def vector(p1, p2):
    return [p2[0]-p1[0], p2[1]-p1[1], p2[2]-p1[2]]

def vabs(a):
    return sqrt(pow(a[0],2)+pow(a[1],2)+pow(a[2],2))


def get_ca_atoms_from_disorder_label(pdbfile,Nmer,Chainlength):
# the script is get the C-Alpha of the pdbfile
# this is regardless of the resi_id in the pdbfile, it reset the resi_id one by one which need the pdb doesn't has missing residue
# this purpos for aggregation, so Nmer is the molecule number in box, Chainlength is whole length of one molecule
    ca_atoms = np.zeros((Chainlength*Nmer,3))
    length = 0
    with open(pdbfile,'r') as fopen:
       for line in fopen.readlines( ):
   #     print line
        if len(line.split()) >= 6:
  #       print line
         if line.split()[2] == "CA":
           x = float(line[30:38])
           y = float(line[38:46])
           z = float(line[46:54])
 #          print x,y,z
           ca_atoms[length][0] = x
           ca_atoms[length][1] = y
           ca_atoms[length][2] = z
    #       print resi_coord
           length += 1
    #       np.append(ca_atoms,resi_coord)
    # ca_atoms = np.reshape(ca,())
    #print ca_atoms
    return ca_atoms

def compute_Q(ca_atoms_1,ca_atoms_2,qo_flag,cutoff):
# this script is compute the Q 
    sigma_exp = 0.15
    sigma = []
    sigma_sq = []
    for i in range(0, len(ca_atoms_1)+1):
#    for i in range(0, 10):
        sigma.append( (1+i)**sigma_exp )
        sigma_sq.append(sigma[-1]*sigma[-1])
    if len(ca_atoms_1) != len(ca_atoms_2):
        print "Error. Length mismatch!"
        print "Pdb1: ", len(ca_atoms_1), "Pdb2: ", len(ca_atoms_2)
        sys.exit()
    Q = 0
    norm = 0
    N = len(ca_atoms_1)
    min_step =  3
    if qo_flag == 1 :
       min_step = 4
#    print ca_atoms_1
    #print ca_atoms_2[0]
    for ia in range(0,N):
        for ja in range(ia+min_step,N): 
           
            r1 = vabs(vector(ca_atoms_1[ia],ca_atoms_1[ja])) 
            r2 = vabs(vector(ca_atoms_2[ia],ca_atoms_2[ja]))
            
            if qo_flag == 1  and r2 >= cutoff:
               continue
            dr = r1 -r2
            #print dr 
            Q += exp(-dr*dr/(2.0*(sigma_sq[ja-ia])))
            norm += 1
            #print Q,norm
    Q = Q/norm
    return Q
    #print sigma 
#compute_Q(1,1,1,1)
   

def compute_premutation(ca_atoms_1,ca_atoms_2,Nmer,qo_flag, cutoff):
# this scipt is compute the premutation Q 
    if Nmer == 1:
       Q = compute_Q(ca_atoms_1,ca_atoms_2,qo_flag,cutoff)
 #      print Q
       return Q 
    N1 = len(ca_atoms_1)
    N2 = len(ca_atoms_2)
    if N1 != N2:
        print "Error, cb_atoms length mismatch."
        print "Length of cb_atoms_1 is ", N, "Length of cb_atoms_2 is ", N2
        print "Check the number of residues in the pdb files."  
        sys.exit()
    n_resi = N1/Nmer
    if n_resi != int(N1/Nmer):
        print "Each chain should have the same # of residues."
        sys.exit()
    Q_perm= []
#    print N1
    residue_list = range(N1)
    chains_list = range(Nmer)
    residue_reshape_list = [range(N1)[i:i+n_resi] for i in range(0,N1,n_resi)]
    n_chains_perm = list(permutations(chains_list))
    for chain_perm_id in n_chains_perm:
        residue_list_perm = []
        for id_chain in chain_perm_id:        
            residue_list_perm.extend(residue_reshape_list[id_chain])
#        for id_re in residue_list:
#         print id_re
#         print residue_list_perm[id_re]
#         print ca_atoms_2[residue_list_perm[id_re]]
        ca_atoms_2_perm = [ca_atoms_2[residue_list_perm[id_re]] for id_re in residue_list]
        Q = compute_Q(ca_atoms_1,ca_atoms_2_perm,qo_flag,cutoff)
        Q_perm.append(Q) 
    #print Q_perm        
    Q_rel = max(Q_perm)
    return Q_rel

def main():
    pdbfile1 = sys.argv[1]
    pdbfile2 = sys.argv[2]
    cutoff = 10
    Nmer = int(sys.argv[3])
    Chainlength = int(sys.argv[4])
    qo_flag = int(sys.argv[5])
    ca_atoms_1 = get_ca_atoms_from_disorder_label(pdbfile1,Nmer,Chainlength)
    ca_atoms_2 = get_ca_atoms_from_disorder_label(pdbfile2,Nmer,Chainlength)
  #  print ca_atoms_1
    Q = compute_premutation(ca_atoms_1,ca_atoms_2,Nmer,qo_flag, cutoff)
    print  Q

if __name__ == '__main__':
    main()


