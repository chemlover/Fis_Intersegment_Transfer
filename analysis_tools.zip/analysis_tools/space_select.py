import os
import sys
# this scipt is one of pre-script of compute_Q which will use lots of time, in this scipt, it divide it in several part to run which will run on the cluster
# rearrange  the pdb name from lots of pdb and begin with order
num_total = int(sys.argv[1])
num_select = int(sys.argv[2])
folder = sys.argv[3]
space = int(num_total/num_select)
os.system("mkdir -p %s"%(folder))
for i in range(num_select):
    numT = i*space + 1
    numR = i + 1
    os.system("cp %d.pdb %s/%d.pdb"%(numT,folder,numR))

