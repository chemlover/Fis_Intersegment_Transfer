file=$1
energy_term=("Step" "Chain" "Shake" "Chi" "Rama" "Excluded" "DSSP" "P_AP"  "Water" "Burial" "Helix" "AMH-Go" "Frag_Mem" "Vec_FM" "Membrane" "SSB" "Electro" "QGO" "VTotal")
length=${#energy_term[@]}
let "l=$length - 1"
for i in $(seq 0 $l);do
    let "j=$i+1"
    awk -v var="$j" '{print $var}' $file | tail -n +3 > ../${energy_term[$i]}
done
