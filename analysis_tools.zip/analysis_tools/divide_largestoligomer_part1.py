import os
import sys
pdbfile = sys.argv[1]
recordfile = sys.argv[2]
data=""
ENDFLAG = "on"
NUM1=0
NUM2=0
with open(pdbfile,"r") as fopen:
     for line in fopen.readlines():
         if line.split()[0] == "END":
            data += str(NUM1) + " " + str(NUM2) + "\n" 
            NUM2 =0
            NUM1 += 1
         else:
            NUM2 += 1
            NUM1 += 1
with open(recordfile,"w")  as fwrite:
     fwrite.writelines(data)
         
    
