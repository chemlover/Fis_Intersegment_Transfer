import os
import sys
import numpy as np
folder = sys.argv[1]
repeat = int(sys.argv[2])
space = float(sys.argv[3])
k=int(sys.argv[4])
pathT= sys.argv[5]
start = float(sys.argv[6])
for i in range(repeat):
   os.chdir("%s/%s%d"%(pathT,folder,i+1))
   with open("fix_qbias_coeff.data",'w') as fwrite:
        data = "[QBias_Exp]\n"+str(k) + "\n" + str(i*space+start) + "\n2\n0.15"
        fwrite.writelines(data)

