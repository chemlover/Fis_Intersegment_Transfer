import os
import sys
from VectorAlgebra import *
import numpy as np
import networkx as nx
# thi script is try  to divide the pdbfile basd on its oligomer
# the inputfile will be pdbfile generate by awsem older script
# the output will be named folder under current folder
# the output pdb name will origin_pdb_name-oliomer_size-squeue_number.pdb

def get_C_Alhpa_coord(pdbfile,length,Nmer):
# get the ca_atoms coordinate of pdbfile
# length will be monomer length
# Nmer will be molecule in the box
# return N*3 matrix
    pdb_Calpha_coord = np.zeros((length*Nmer,3))

    with open(pdbfile,'r') as fopen:
       for line in fopen.readlines( ):
   #     print line
        if len(line.split()) >= 6:
  #       print line
         if line.split()[2] == "CA":
           resi = int(line[22:26])         
           x = float(line[30:38])
           y = float(line[38:46])
           z = float(line[46:54])
 #          print x,y,z
           pdb_Calpha_coord[resi-1][0] = x   
           pdb_Calpha_coord[resi-1][1] = y
           pdb_Calpha_coord[resi-1][2] = z
#    print pdb_Calpha_coord
    return pdb_Calpha_coord

def IsConnected(a,b,length,ca_atom,cutoff):
# determine whether two monomer is connected
# a b is the order of monomer must > 0
# cutoff :determine the contact
# length : monomer residue number
        contact=0;
        for i in range(length*a-length,length*a):
               for j in range(length*b-length,length*b):
                        xi=ca_atom[i][0];yi=ca_atom[i][1];zi=ca_atom[i][2];
                        xj=ca_atom[j][0];yj=ca_atom[j][1];zj=ca_atom[j][2];
                        #print xi;
                        distij=(xi-xj)*(xi-xj)+(yi-yj)*(yi-yj)+(zi-zj)*(zi-zj);
                        #print math.sqrt(distij)
                        if distij <= (cutoff)*(cutoff):
                                contact=contact+1;
                        distij=0;
        if contact >= 10:
   #             print contact
                return 1;
        else:
                return 0;
def oligomer_connectedmap(ca_atom,cutoff,Nmer,length):
# return the sets which cluster the order of oligomer in series
   G=nx.Graph();
   squeue = []
   for i in range(Nmer-1):
      squeue.append(Nmer)
   #G.add_nodes_from(squeue) 
   for i in range(Nmer):
       for j in range(i,Nmer):
          a = i + 1
          b = j + 1 
          if IsConnected(a,b,length,ca_atom,cutoff) == 1 :
             G.add_edge(i,j)
    #         print i,j
   sets=list(nx.connected_components(G))
   #print sets
   return(sets)
   print sets
def divide_oligmer(pdbfile,sets,length,folder,Nmer):
# divide oligomer based on sets 
# doesn't change resi id order !!
    with open(pdbfile,'r') as fopen:
        lines = fopen.readlines()
    Nmer_squeue = np.zeros(Nmer)
    for i in range(Nmer):
        Nmer_squeue[i] = 1
    for i in range(len(sets)):
        squeue = []
        data = ''
        for j in sets[i]:
            squeue.append(j)
    #    print squeue
        flag_Nmer = 0 
        flag_squeue = 0
        flag_resi = 0
        for line in lines:
          if flag_squeue <= len(squeue) - 1: 
           if flag_Nmer == squeue[flag_squeue]:
              data += line
           if (line.split()[2] == "CB" or line.split()[2] == "HB"):
              flag_resi += 1
           if flag_resi == length:
              if flag_Nmer == squeue[flag_squeue]:
                 flag_squeue += 1
              flag_Nmer += 1
              flag_resi = 0
        #      print flag_Nmer
              
        outputfile = folder + '/' + pdbfile.split('.')[0] + '-' + str(len(squeue)) + '-' + str(int(Nmer_squeue[int(len(squeue)-1)]))  + '.pdb'
        Nmer_squeue[int(len(squeue)-1)] += 1
        with open(outputfile,'w') as fwrite:
               fwrite.writelines(data)
if len(sys.argv) != 5:
    print "*py pdbfile Nmer Chainlength folder"
    exit()             
pdbfile = sys.argv[1] 
Nmer = int(sys.argv[2])
Chainlength = int (sys.argv[3]) 
folder = sys.argv[4] 
cutoff = 10         
def  main():
   ca_atom = get_C_Alhpa_coord(pdbfile,Chainlength,Nmer)
   sets = oligomer_connectedmap(ca_atom,cutoff,Nmer,Chainlength)
   divide_oligmer(pdbfile,sets,Chainlength,folder,Nmer)
if __name__ == '__main__':
    main()
