import os
import sys
folder = sys.argv[1]
patht = sys.argv[2]
pathR = sys.argv[3]
oligomer_size = sys.argv[4]
repeat = int(sys.argv[5])
pathT = sys.argv[6]
order  = 1
os.system("mkdir -p %s"%(pathR))
for i in range(repeat):
    j = i + 1
   # print j 
    os.chdir("%s/%s%d/%s"%(pathT,folder,j,patht))
    inputfile = './' + oligomer_size + '.txt'
    os.system("rm %s"%(inputfile))
#    os.system("")
    os.system("ls * | grep \"\-%s\-\" >> %s"%(oligomer_size,inputfile))
    with open(inputfile,'r') as fopen:
      lines = fopen.readlines()
    #print line
    for line in lines:
     if line != '\n' and line != '\t' and line != ' ':
       os.system("cp ./%s %s/%d.pdb"%(line.split()[0],pathR,order))
   #    print line.split()[0]
       order += 1

