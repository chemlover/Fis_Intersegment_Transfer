import os
import numpy as np
import sys
data = np.loadtxt(sys.argv[1])
nmer = int(sys.argv[2])
[m,n] = np.shape(data)
reslen = m/nmer
#for i in range(nmer):
#    for j in range(i*reslen,i*reslen+reslen):
#        for  k in range(i*reslen,i*reslen+reslen):
#             data[k][j] = 0.0
#for i in range(m):
#    for j in range(n):
#        if data[i][j] > 25.0:
#           data[i][j] = 0.0
for i in range(m):
    for j in range(n):
        if abs(i-j) < reslen or abs(i-j) > 2*reslen:
           data[i][j] = 0.0 
np.savetxt(sys.argv[3],data,fmt="%.3f",delimiter=" ")
