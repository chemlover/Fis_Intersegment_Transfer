import numpy as np
import pandas
import prody
#import matplotlib.pyplot as plt
#from matplotlib.pyplot import cm as cm
import sys
import math
import os
np.set_printoptions(threshold=np.nan)
def vector(p1, p2):
    return [p2[0]-p1[0], p2[1]-p1[1], p2[2]-p1[2]]

def vabs(a):
    return math.sqrt(pow(a[0],2)+pow(a[1],2)+pow(a[2],2))

def checkIfNative(xyz_CAi, xyz_CAj):
    v = vector(xyz_CAi, xyz_CAj)
    r = vabs(v)
    if r<12.0: return True
    else: return False

def isNative(r):
        if r<12.0: return True
        else: return False

def get_file_len(filename):
    exeline="wc -l "+filename ;
    stdout=os.popen(exeline).readline();
    stdout=stdout.split()
    return int(stdout[0])


def get_pdbfile_line_atoms(filename):
    file_len = get_file_len(filename)
    with open(filename,'r') as fopen:
         lines = fopen.readlines()
    n_atoms = 0
    n_lines = 0
    for line in lines:
        n_lines += 1
        if line.split()[0] == "END":
           break
        elif line.split()[2] == "CA" or line.split()[2] == "S":
           n_atoms += 1
        
    n_snapshot = file_len/n_lines
    return n_snapshot,n_lines,n_atoms

def getline_range(filename, line1, line2):
    assert(line1 <= line2)
    nline=line2-line1+1
    exeline="head -n"+str(line2)+" "+filename+" | tail -n"+str(nline) ;
    #print exeline
    stdout=os.popen(exeline).readlines()
    return stdout

def get_pdbfile_i(pdbfile, i,n_lines):
     #   nline=get_nline_snapshot(pdbfile)
        line_start = 1 + n_lines*i ; line_end = n_lines*(i+1)
        pdb_part=getline_range(pdbfile, line_start, line_end)
        return pdb_part

def get_ca_s_atoms(pdb_part):
    ca_atoms = []
    for line in pdb_part:
        if len(line.split()) > 6:  
        #if line.split()[0] != 'END' or line.split()[0] != 'ENDMDL':
           if line.split()[2] == 'CA' or line.split()[2] == 'S':
           #print line
              x=float(line[30:38])
              y=float(line[38:46])
              z=float(line[46:54])
              atom = [x,y,z]
              ca_atoms.append(atom)
   # print coord
    return ca_atoms

def part(ca_atoms):
    contacts = 0
    length = len(ca_atoms)
    for i in range(length):
        for j in range(i+3,length): 
           if checkIfNative(ca_atoms[i], ca_atoms[j]):
              contacts += 1
    return contacts

def traj(pdbfile,start,end,n_atoms,n_lines):
    n_frames = end - start + 1.0
    tcfile = open("tc.txt",'w')
    for i in range(start,end):
        pdb_part = get_pdbfile_i(pdbfile, i,n_lines)
        ca_atoms = get_ca_s_atoms(pdb_part)
        contacts = part(ca_atoms)
        tcfile.write(str(contacts)+"\n")
    tcfile.close()

def main():
    inputfile = sys.argv[1]
    n_snapshot,n_lines,n_atoms =  get_pdbfile_line_atoms(inputfile)
    start = 1
    end = n_snapshot
    traj(inputfile,start,end,n_atoms,n_lines)

if __name__ == '__main__':
    main()

