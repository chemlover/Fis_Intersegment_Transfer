import os
import sys
#import pandas as pd
import numpy as np
from sklearn.cluster import AgglomerativeClustering
from sklearn.cluster import KMeans
from sklearn.cluster import DBSCAN
from sklearn import metrics
from sklearn.metrics import pairwise_distances
from scipy.cluster.hierarchy import linkage
from scipy.cluster.hierarchy import dendrogram
#import matplotlib.pyplot as plt
from sklearn import datasets
def select_symbol_cluster(matrix,pure_cluster,cluster_order):
    Q = np.zeros(len(pure_cluster))
    for i in range(len(pure_cluster)):
      for j in pure_cluster:
        index1 = int(pure_cluster[i])
        index2 = int(j)
        Q[i] += matrix[index1][index2]
#  print ("PdbID: %d  Cluster_size: %d)"%(int(pure_cluster[np.argmax(Q)]),len(pure_cluster))
    print  pure_cluster[np.argmax(Q)],len(pure_cluster)
    core_order = int(pure_cluster[np.argmax(Q)])
    cluster_num = int(len(pure_cluster))
    os.system("cp %d.pdb cluster_%d-pdbid_%d-total_num_%d.pdb"%(core_order,cluster_order,core_order,cluster_num))

def get_one_kmeans_pred(matrix,n):
    kmeans = KMeans(n)
    kmeans.fit(matrix)
    kmeans_pred=kmeans.fit_predict(matrix)
    return kmeans_pred

def get_cluster_information(matrix,kmeans_pred,n_cluster):
    flag = np.zeros(n_cluster)
    clusters =np.zeros((n_cluster,(len(kmeans_pred))))
    for i in range(len(kmeans_pred)):
        index1 = int(kmeans_pred[i])
        index2 = int(flag[index1])
        clusters[index1][index2] = i+1
    #   print i
    flag[kmeans_pred[i]] += 1
    for i in range(n_cluster):
     #  print clusters[i]    
        pure_cluster = []
        for j in range(len(kmeans_pred)):
            if clusters[i][j] != 0:
               pure_cluster.append(clusters[i][j]-1)
        select_symbol_cluster(matrix,pure_cluster,i+1)

def get_enough_good_kmeans(matrix,n_cluster):
    num = 0
    iteration = 2
    cutoff = 0.5
    score = 0
 #   print num
    while num < iteration and score < cutoff:
         kmeans_pred = get_one_kmeans_pred(matrix,n_cluster)
         num += 1
         score1 = metrics.silhouette_score(matrix, kmeans_pred, metric='euclidean')    
  #       print score1
         if score1 > score:
            score = score1
            kmeans_ready = kmeans_pred 
#    print kmeans_ready
    print score
    return  kmeans_pred

def main():
    inputfile = sys.argv[1]
    n_cluster = int(sys.argv[2])
    matrix = np.loadtxt(inputfile)
    kmeans_pred = get_enough_good_kmeans(matrix,n_cluster)
    print kmeans_pred
    get_cluster_information(matrix,kmeans_pred,n_cluster)

if __name__ == '__main__':
   main()
