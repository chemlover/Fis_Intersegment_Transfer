import os
import sys
PdbID = sys.argv[1]
#spdbid = sys.argv[2]
os.system("sh /home/xc25/AWSEM/awsemmd-amylometer/create_project_tools/PdbCoords2Lammps.sh %s %s"%(PdbID,PdbID))
#seq = PdbID + '.seq'
#print seq
#with open(seq,'r') as fopen:
#   for line in fopen.readlines(): 
#       break
#Num = len(line.split()[0])
#os.system("cp /scratch/xc25/native_structure/%s_native.pdb ./%s-standard.pdb"%(spdbid,PdbID))
#os.system("python /home/xc25/GetCACADistancesFile_multiChain_part.py %s-standard native.dat %s"%(PdbID,Num))
#os.system("python /home/xc25/AWSEM/awsemmd-amylometer/create_project_tools/GetCACoordinatesFromPDB.py %s nativecoords.dat"%(PdbID))
