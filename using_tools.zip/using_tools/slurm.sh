#!/bin/bash
if [ $# -ne 1 ];  then
   echo "Usage: exe PdbID Kvalue"
   exit
fi
Num=$1
for ((i=1;i<=40;i++)); do
   x="PHF_pentamer-restartm"
   #sed "s/NAME/$x/g" ./restarts.slurm > slurm1
   j=$(i+1)
   echo $j
   x="tau_oct-restartm"$i".slurm" 
   sed "s/NUMBER/$i/g" ./restartm.slurm > slurm1
   mv slurm1 $x
done
