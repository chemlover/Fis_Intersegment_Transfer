import os
import sys
import numpy as np
# get the charge of pdb file by time:
chargeTable = {'ALA':0.0,'ARG':1.0,'ASN':0.0,'ASP':-1.0,'CYS':0.0,'GLU':-1.0,'GLN':0.0,'GLY':0.0,'HIS':0.0,
           'ILE':0.0,'LEU':0.0,'LYS':1.0,'MET':0.0,'PHE':0.0,'PRO':0.0,'SER':0.0,'THR':0.0,'TRP':0.0,
           'TYR':0.0,'VAL':0.0}
def getcharge_pdb(pdbfile):
    with open(pdbfile) as fopen:
      lines = fopen.readlines()
    N = 0
    for line in lines:
       print line
       if line.split()[0] == 'ATOM':
           print line
           if line.split()[2] == 'CA':
               N = N+1
    charge = np.zeros(N)
    M = 0 
    for line in lines:
       if line.split()[0] == 'ATOM':
           if line.split()[2] == 'CA':
              charge[M] = chargeTable[line.split()[3]] 
              M = M+1
    return charge
def addcharge(datafile,charge,outputfile):
    with open(datafile) as fopen:
      lines = fopen.readlines()
    data = ''
    Flag = 'off'
    L = 0
    for line in lines:
       if line != '\n':
         if line.split()[0] == 'Atoms':
            Flag = 'on'
            data += line
            continue
         if line.split()[0] == 'Bonds' or line.split()[0] == 'Bond':
            Flag = 'off'
         if Flag == 'on':
            #print line
            if line.split()[3] == str(4):
               #print charge
               x = line[0:21]+ str(charge[L]) + line[23:93]
               #print line  
               #print line[0:12]
               #print line[17:93] 
               #print line[0:21] 
               #print str(charge[L])
               #print line[23:93] 
           #    print x
               #data += x
               data += "\t" + line.split()[0].rjust(4," ") + '\t' + line.split()[1] + '\t' + line.split()[2] + '\t' +line.split()[3] + '\t' + str(charge[L]) + '\t' + line.split()[5] + '\t' +line.split()[6] + '\t' +line.split()[7] + '\n'
               L += 1
            else:
               data += line
         else:
               data += line
       else:
               data += line
    with open(outputfile,'w') as fwrite:
        fwrite.writelines(data)
pdbfile = sys.argv[1]
datafile = sys.argv[2]
outputfile =sys.argv[3]
charge = getcharge_pdb(pdbfile)
addcharge(datafile,charge,outputfile)
