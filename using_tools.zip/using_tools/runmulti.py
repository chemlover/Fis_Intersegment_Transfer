# /usr/bin/env python3
import os

import random

for x in range(20):
    os.system("cd /scratch/xc25/")
    os.system("mkdir %s" % ('T0829' + str(x)))
    os.system("cd /scratch/xc25/T0829")
    os.system("cp -R /scratch/xc25/T0829/. /scractch/xc25/%s" % ('T0829' + str(x)))
    os.system("cd /scratch/xc25/%s" % ('T0829' + str(x)))
    os.system("mv /scratch/xc25/%s/T0829.in /scratch/xc25/%s/%s" % (
    'T0829' + str(x), 'T0829' + str(x), 'T0829' + str(x) + '.in'))
    os.system("mv /scratch/xc25/%s/T0829.slurm /scratch/xc25/%s/%s" % (
    'T0829' + str(x), 'T0829' + str(x), 'T0829' + str(x) + '.slurm'))
    inputfile = '/scratch/xc25/T0829' + str(x) + '/T0829' + str(x) + '.in'
    slurm = '/scratch/xc25/T0829' + str(x) + '/T0829' + str(x) + '.slurm'
    y = random.randint(20000, 200000)
    data = ''
    with open('inputfile', 'r+') as fopen:
        for line in fopen.readlines():
            if (line.find('velocity' == 0)):
                line = 'velocity    all create 500.0 %s' % (str(y)) + '\n'
            data += line
    with open('inputfile', 'r+') as fopen:
        fopen.writelines(data)
    data = ''
    with open('slurm', 'r+') as fopen:
        for line in fopen.readlines():
            if (line.find('/scratch/xc25/T0829/lmp_serial < T0829.in' == 0)):
                line = '/scratch/xc25/%s/lmp_serial < %s' % ('T0829' + str(x), inputfile) + '\n'
            data += line
    with open('slurm', 'r+') as fopen:
        fopen.writelines(data)

    os.system("cd /scratch/xc25/%s" % ('T089' + str(x)))
    os.system("sbatch %s" % ('slurm'))
