import os
import numpy as np
import sys
from math import *
ifile=sys.argv[1]
ofile=sys.argv[2]
datai = np.loadtxt(ifile)
nlen = int(sqrt(len(datai)))
print (nlen)
datao=np.zeros((nlen,nlen))
num = -1
for i in range(nlen):
    datao[i][i] = 1
    for j in range(nlen):
        num = i*nlen+j
        datao[i][j] = datai[num]
        #datao[j][i] = datao[i][j]
np.savetxt(ofile,datao,fmt="%.6f",delimiter=" ")
