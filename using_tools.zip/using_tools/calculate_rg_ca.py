import numpy as np
import pandas
import prody
#import matplotlib.pyplot as plt
#from matplotlib.pyplot import cm as cm
import sys
from math import * 
import os
from Bio.SVDSuperimposer import SVDSuperimposer
np.set_printoptions(threshold=np.nan)
def vector(p1, p2):
    return [p2[0]-p1[0], p2[1]-p1[1], p2[2]-p1[2]]

def vabs(a):
    return sqrt(pow(a[0],2)+pow(a[1],2)+pow(a[2],2))

def sigma_sq(sep):
        return pow((1+sep),0.15)*pow((1+sep), 0.15)

def calu_dist(p1, p2):
        v=vector(p1,p2)
        return vabs(v)


def checkIfNative(xyz_CAi, xyz_CAj):
    v = vector(xyz_CAi, xyz_CAj)
    r = vabs(v)
    if r<12.0: return True
    else: return False

def isNative(r):
        if r<12.0: return True
        else: return False

def get_file_len(filename):
    exeline="wc -l "+filename ;
    stdout=os.popen(exeline).readline();
    stdout=stdout.split()
    return int(stdout[0])


def get_pdbfile_line_atoms(filename):
    file_len = get_file_len(filename)
    with open(filename,'r') as fopen:
         lines = fopen.readlines()
    n_atoms = 0
    n_lines = 0
    for line in lines:
        n_lines += 1
        if line.split()[0] == "END" or line.split()[0] == "ENDMDL":
           break
        if line[0:4] != "ATOM":
           continue
        elif line.split()[2] == "CA":
           n_atoms += 1
        
    n_snapshot = file_len/n_lines
    return n_snapshot,n_lines,n_atoms

def getline_range(filename, line1, line2):
    assert(line1 <= line2)
    nline=line2-line1+1
    exeline="head -n"+str(line2)+" "+filename+" | tail -n"+str(nline) ;
    #print exeline
    stdout=os.popen(exeline).readlines()
    return stdout

def get_pdbfile_i(pdbfile, i,n_lines):
     #   nline=get_nline_snapshot(pdbfile)
        line_start = 1 + n_lines*i ; line_end = n_lines*(i+1)
        pdb_part=getline_range(pdbfile, line_start, line_end)
        return pdb_part

def get_ca_s_atoms(pdb_part):
    ca_atoms = []
    res_id_old = 0
    for line in pdb_part:
        if line.split()[0] == 'ATOM' or line.split()[0] == 'HETATM':
           if line.split()[2] == 'CA':
              res_id_new = int(line[22:26])
              if res_id_new - res_id_old != 1:
                 for i in range(res_id_new - res_id_old - 1):
                     ca_atoms.append([0,0,0])
                     res_id_old += 1
           #print line 
              res_id_old += 1
              x=float(line[30:38])
              y=float(line[38:46])
              z=float(line[46:54])
              atom = [x,y,z]
              ca_atoms.append(atom)
   # print coord
    return ca_atoms

def get_ca_s_atoms_regular(pdb_part):
    ca_atoms = []
    res_id_old = 0
    for line in pdb_part:
        if line.split()[0] == 'ATOM' or line.split()[0] == 'HETATM':
           if line.split()[2] == 'CA':
              #res_id_new = int(line[22:26])
              #f res_id_new - res_id_old != 1:
               #  for i in range(res_id_new - res_id_old - 1):
               #      ca_atoms.append([0,0,0])
               #      res_id_old += 1
           #print line 
              #res_id_old += 1
              x=float(line[30:38])
              y=float(line[38:46])
              z=float(line[46:54])
              atom = [x,y,z]
              ca_atoms.append(atom)
   # print coord
    return ca_atoms

def compute_q(ca_atoms1,ca_atoms2):
    length = np.min([len(ca_atoms1),len(ca_atoms2)])
    q = 0
    q_sum = 0
    for i in range(length):
        for j in range(i+3,length):
            if ca_atoms1[i] != [0,0,0] and ca_atoms1[j] != [0,0,0] and ca_atoms2[i] != [0,0,0] and ca_atoms2[j] != [0,0,0]:
               rij_N = calu_dist(ca_atoms1[i],ca_atoms1[j])
               rij = calu_dist(ca_atoms2[i],ca_atoms2[j])
               dr = rij - rij_N
               #print rij,rij_N,dr,i,j
               q += exp(-dr*dr/sigma_sq(j-i)/2)
               q_sum += 1
    return q/q_sum 
    

def compute_rmsd(ca_atoms1,ca_atoms2):
        #if len(ca_atoms)!=len(ca_atoms_pdb):
               # print "Error. Length mismatch!"
               # exit()
        #l = len(ca_atoms)
        l = 0
        for i in range(len(ca_atoms1)):
            if ca_atoms1[i] != [0,0,0] and ca_atoms2[i] != [0,0,0]:
               l += 1
        fixed_coord  = np.zeros((l, 3))
        moving_coord = np.zeros((l, 3))
        for i in range(0, len(ca_atoms1)):
            if ca_atoms1[i] != [0,0,0] and ca_atoms2[i] != [0,0,0]:
                fixed_coord[i]  = np.array ([ca_atoms1[i][0], ca_atoms1[i][1], ca_atoms1[i][2]])
                moving_coord[i] = np.array ([ca_atoms2[i][0], ca_atoms2[i][1], ca_atoms2[i][2]])
        sup = SVDSuperimposer()
        sup.set(fixed_coord, moving_coord)
        sup.run()
        rms = sup.get_rms()
        return rms

def computeRg(ca_atoms):
        if len(ca_atoms)==0:
                print "Error. Empty snapshot"
                exit()
        N = len(ca_atoms)
        Rg = 0.0
        for ia in range(0, N):
                for ja in range(ia+1, N):
                        rv = vector(ca_atoms[ia], ca_atoms[ja])
                        rsq = pow(rv[0],2)+pow(rv[1],2)+pow(rv[2],2)
                        Rg = Rg + rsq
        Rg = sqrt(Rg/N/N)
        return Rg

def compute_traj(pdbfile):
    n_snapshot,n_lines,n_atoms =  get_pdbfile_line_atoms(pdbfile)
    print n_snapshot,n_lines,n_atoms 
    file_q = open("Rg",'w')
 #   file_rmsd = open("rmsd",'w')
   # with open(crystalfile,"r") as fopen:
   #      lines = fopen.readlines()
   # ca_atoms_crystal = get_ca_s_atoms(lines)
    for i in range(n_snapshot):
        pdb_part = get_pdbfile_i(pdbfile, i,n_lines)
        ca_atoms_run = get_ca_s_atoms(pdb_part)
  #      q = compute_q(ca_atoms_crystal,ca_atoms_run)
  #      rmsd = compute_rmsd(ca_atoms_crystal,ca_atoms_run)
        Rg = computeRg(ca_atoms_run)
        file_q.write(str(Rg)+'\n')
        #print q
  #      file_rmsd.write(str(rmsd)+'\n')
    file_q.close()
  #  file_rmsd.close()

def main():
   # crystalfile = sys.argv[1]
    runfile = sys.argv[1]
    compute_traj(runfile)
if __name__ == '__main__':
    main()

