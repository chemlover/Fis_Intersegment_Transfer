# /usr/bin/env python3

import os
import re
import string
import sys
chain_id_list = ['A','B','C','D','E','F','G','H','I','J','K','L']
PdbID  = sys.argv[1]
fasta = PdbID + '.fasta'
seq = PdbID + '.seq'
data = ''
N =0
#data += '>'+ PdbID +':A|PDBID|CHAIN|SEQUENCE\n'
with open(seq,'r') as seqopen:
 for line in seqopen.readlines():
     data += '>'+ PdbID +':'+chain_id_list[N]+'|PDBID|CHAIN|SEQUENCE\n'
     data += line.split()[0] + '\n'
     N += 1
with open(fasta,'w') as fastawrite:
 fastawrite.writelines(data)

