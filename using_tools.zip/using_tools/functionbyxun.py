import os
import sys
import re
import random
import numpy as np
def caculate_mean(DirT,Folder,file,Term,num_total,num):
      filename = DirT + '/' + Folder + str(1) + '/' + file
      with open(filename,'r') as fopen:
         lines = fopen.readlines()
         print Term
         for i in range(19):
           if lines[0].split()[i] == Term:
             print Term
             Key = i
             print  '%d'%(i)
         num_whole = int(lines[-1].split()[0])/1000
         num_start = num_whole - num_total
      sum = 0.0
      for i in range(num):
       inputfile = DirT + '/' + Folder + str(i+1) + '/' + file
       with open(filename,'r') as fopen:
         lines = fopen.readlines()
       for line in lines:
        if line.split()[0] != 'Step':
         if int(line.split()[0]) > num_start*1000:
           sum = sum + float(line.split()[Key])
      mean = sum/num_total/num
      print '%.3f'%(mean)
      return(mean)
def caculate_stardard_deviation(DirT,Folder,file,Term,num_total,num,mean):
      filename = DirT + '/' + Folder + str(1) + '/' + file
      with open(filename,'r') as fopen:
         lines = fopen.readlines()
         for i in range(19):
           if lines[0].split()[i] == Term:
             print(Term)
             Key = i
         num_whole = int(lines[-1].split()[0])/1000
         num_start = num_whole - num_total
      sum = 0.0
      for i in range(num):
       inputfile = DirT + '/' + Folder + str(i+1) + '/' + file
       with open(filename,'r') as fopen:
         lines = fopen.readlines()
       for line in lines:
        if line.split()[0] != 'Step':
         if int(line.split()[0]) > num_start*1000:
           sum = sum + (float(line.split()[Key])-mean)**2
      std = (sum/num_total/num)**(0.5)
      return(std)
def mkdir_download(DirT,Dir1,Dir2,Dir3):
    os.chdir("%s"%(DirT))
    os.system("mkdir %s"%(Dir1))
    os.chdir("%s/%s"%(DirT,Dir1))
    os.system("mkdir %s"%(Dir2))
    os.chdir("%s/%s/%s"%(DirT,Dir1,Dir2))
    os.system("mkdir %s"%(Dir3))
def mkdir_running(DirT,Dir1,Dir2,num):
    os.chdir("%s"%(DirT))
    os.system("mkdir %s"%(Dir1))
    os.chdir("%s/%s"%(DirT,Dir1))
    for i in range(num):
      os.system("mkdir %s%s"%(Dir2,str(i+1)))
def select_values_based_term(DirT,DirR,Folder,file,Term,num,PdbID):
    os.chdir("%s"%(DirR))
    data = ''
    for i in range(num):
      DirS = DirT + '/' + Folder + str(i+1)
      filename = DirT + '/' + Folder + str(i+1) + '/' + file
      with open (filename,'r') as fopen:
        lines = fopen.readlines()
      line = lines[0]
      line_num = len(lines)
      Term_num = len(line)
      #print line 
      for j in range(Term_num):
        if line.split()[j] == Term:
           key = j
           break
      #print key
         #  print Term
         #  print line.split()[j]
      Amount = 0
     # print line_num
      for k in range(line_num/2):
        #print lines[line_num/2 + k]
        if float(lines[line_num/2  + k].split()[key]) < Amount:
           Amount = float(lines[line_num/2  + k].split()[key])
           snapshot = str(line_num/2 +  k - 1)
      #print "python /home/xc25/AWSEM/awsemmd-amylometer/results_analysis_tools/BuildAllAtomsFromLammps_seq.py %s/dump.lammpstrj %s-%s.pdb %s/%s.seq %s"%(DirS,PdbID,str(i+1),DirS,PdbID,snapshot)
      os.system("python /home/xc25/AWSEM/awsemmd-amylometer/results_analysis_tools/BuildAllAtomsFromLammps_seq.py %s/dump.lammpstrj %s-%s.pdb %s/%s.seq %s"%(DirS,PdbID,str(i+1),DirS,PdbID,snapshot))
      data += snapshot + '000,' + str(Amount) + '\n'
    outputfile = DirR + '/' + Term + '.txt' 
    with open(outputfile,'w') as fwrite:
     fwrite.writelines(data)
def generate_matrix(DirR,Name,num):    
   data = ''
   inputfile = DirR + '/output.txt'
   outputfile = DirR + '/heatmap.txt'
   os.chdir("%s"%(DirR))
   for i in range(num):
     for j in range(num):
      #print "python /home/xc25/AWSEM/awsemmd-amylometer/results_analysis_tools/CalcPdbQ.py %s-%s.pdb %s-%s.pdb output.txt"%(Name,str(i+1),Name,str(j+1))
      os.system("python /home/xc25/AWSEM/awsemmd-amylometer/results_analysis_tools/CalcPdbQ.py %s-%s.pdb %s-%s.pdb output.txt"%(Name,str(i+1),Name,str(j+1)))
      with open(inputfile,'r+') as fread:
        lines = fread.readlines()
        data +=  lines[0].split()[0]+ ','
        print(lines[0].split()[0])
        os.system("rm output.txt")
     data += '\n'
   with open(outputfile,'w') as fwrite:
      fwrite.writelines(data)
def Copybackup(Dir1,Dir2,Dir3,Dir4):
   Dir_target = '/scratch/xc25/' + Dir1 + '/' + Dir2
   Dir_mv = '/scratch/xc25/'  + Dir1 + '/' + Dir3 + '/' + Dir4
   os.system("cp -R  %s/* %s/"%(Dir_target,Dir_mv))
   print("cp -R  %s/* %s/"%(Dir_target,Dir_mv))
def revisevelocity(DirT,Temp,PdbID):
   data = ''
   PdbID = PdbID 
   inputfile = DirT + '/' + PdbID + '.in'
   with open (inputfile,'r') as fopen:
     for line in fopen.readlines():
      if line.find("timestep") == 0:
        line = 'timestep 5'  + '\n'
      elif line.find('velocity') == 0:
        y = random.randint(2000, 200000)
        line = 'velocity    all create ' + Temp  + '.0 '+ str(y) + '\n'
      elif line.find("restart ") == 0:
        line = 'restart       100000   ' + PdbID + 'tw.1 ' + PdbID + 'tw.2 ' + '\n'
      data += line
   with open(inputfile,'w') as fwrite:
      fwrite.writelines(data)
def reviseslurm(DirT,Name):
   slurm = DirT + '/slurm'
   data = ''
   with open(slurm,'r') as fopen:
     for line in fopen.readlines():
      if(line.find('#SBATCH --job-name') == 0 ):
         line = '#SBATCH --job-name=' + Name + '\n'
      data += line
   with open(slurm,'w') as fwrite:
     fwrite.writelines(data)
#def select_structure_rg(DirT,DirR,Dirn,num_D,num_Total,num_start,num_skip,rg,delta):
#    os.system()
#    for i in num():
def combine_frame(DirT,DirR,Folder,Pdb_Name,Frame_Name,num,num_start):
    File = DirR + '/' + Frame_Name + '.pdb'
    data = ''
    for i in range(num):
       DirF = DirT + '/' + Folder + str(i+1) 
       os.chdir(DirF)
       os.system("python /home/xc25/AWSEM/awsemmd-amylometer/results_analysis_tools/BuildAllAtomsFromLammps_seq.py  dump.lammpstrj full %s.seq"%(Pdb_Name))
       Clock = 0
       with open('full.pdb','r') as fopen:
          for line in fopen.readlines():
             if Clock >= num_start:
                data += line
             if line.split()[0] == 'END':
                Clock += 1
       with open(File,'w') as fwrite:
          fwrite.writelines(data) 
def compute_distance_end_to_end(DirT,DirR,PdbID):
    Pdbfile = DirT + '/full.pdb'
    os.chdir(DirT)
    os.system("python /home/xc25/AWSEM/awsemmd-amylometer/results_analysis_tools/BuildAllAtomsFromLammps_seq.py  dump.lammpstrj full %s.seq"%(PdbID))
    seqfile = DirT + '/' + PdbID + '.seq'
    with open(seqfile,'r') as fopen:
       line = fopen.readline().split('\n')[0]
    #print line 
    length = len(line)
    outputfile = DirR + '/Dee'
    Flag = 0
    #print length
    data = ''
    with open(Pdbfile,'r') as fopen:
            for line in fopen.readlines():
              #print line
              if line.find('ATOM') == 0:
                    #print
                    if line.split()[5] == str(1) and line.split()[2] == 'CA':
                       CoodCx = float(line[30:37])
                       CoodCy = float(line[38:45])
                       CoodCz = float(line[46:53])
                    elif line.split()[5] == str(length) and line.split()[2] == 'CA':
                       CoodCX = float(line[30:37])
                       CoodCY = float(line[38:45])
                       CoodCZ = float(line[46:53])
                       D = ((CoodCx-CoodCX)*(CoodCx-CoodCX)+(CoodCy-CoodCY)*(CoodCy-CoodCY)+(CoodCz-CoodCZ)*(CoodCz-CoodCZ))**(0.5)
                       data += str(D) + '\n'
                      # print D
                       #print("%s-%s"%(str(l),str(D)))
                 #if line == str(l*1000 + 6001000) + '\n':
                 #   Flag = 1
                 #   l = l+1
                 #else:
                 #   Flag = 0
                # print("%s"%(str(l)))

    data += '\n'
    with open(outputfile,'w') as fwrite:
         fwrite.writelines(data) 
def select_1D(DirT,DirR,Folder,filename,num_bins,num_start,num_select,num_pdb,prefix,Pdbname):
    file = DirR + '/' + filename
    #with open(file,'r') as f:
    #       foo = f.readlines()
    #print file
    cun = []
    num = []
    data = np.loadtxt(file)
    dt = (max(data)-min(data))/num_bins
    [P,x] = np.histogram(data,num_bins)
    Flag = max(P)
    os.chdir(DirR)   
    for i in range(num_pdb):
        if i == 0:
          for j in range(num_bins): 
            if P[j] == Flag:
                cun.append(P[j])
                num.append(j)  
                break
        else:
          Flag = min(P)
          for j in range(num_bins):
              if P[j] < cun[i-1] and P[j] > Flag:    
                    Flag = P[j]
                    suspend = j
          num.append(suspend)
          cun.append(Flag)  
    for i in range(num_pdb):
        N = 0
        with open(file,'r') as fopen:
          for line in fopen.readlines():
            #print x[num[i]] + dt/2.0 + dt/100
            if (float(line.split()[0]) < (x[num[i]] + dt/2.0 + dt/100)) and (float(line.split()[0]) > (x[num[i]] + dt/2.0 - dt/100)):
               Step = N
               break
            N = N + 1
        refix = str(int(N/num_select)  + 1)
        snapshot = str(N%num_select + 1 + num_start)
        print N 
        print refix
        print  snapshot
        #print ("python /home/xc25/AWSEM/awsemmd-amylometer/results_analysis_tools/BuildAllAtomsFromLammps_seq.py  %s/%s%s/dump.lammpstrj %s-P-%s-%s-%s %s %s/%s%s/%s.seq"%(DirT,Folder,refix,prefix,str(cun[i]),filename,str(x[num[i]] + dt/2.0),snapshot,DirT,Folder,refix,Pdbname))
        os.system("python /home/xc25/AWSEM/awsemmd-amylometer/results_analysis_tools/BuildAllAtomsFromLammps_seq.py  %s/%s%s/dump.lammpstrj %s-P-%s-%s-%s %s/%s%s/%s.seq %s"%(DirT,Folder,refix,prefix,str(cun[i]),filename,str(x[num[i]] + dt/2.0),DirT,Folder,refix,Pdbname,snapshot))
def histogram_2D(DirR,filename1,filename2,num_bins):
    file1 = DirR + '/' + filename1
    file2 = DirR + '/' + filename2
    data1 = np.loadtxt(file1)
    data2 = np.loadtxt(file2)
    num_totali = len(data1)
    num_totalf = float(str(len(data1)))
    [P1,x1] = np.histogram(data1,num_bins)
    [P2,x2] = np.histogram(data2,num_bins)
    inds1 = np.digitize(data1,x1)
    matrix = np.zeros([num_bins,num_bins])
    for i in range(num_totali):
         for j in range(num_bins):
             if data2[i] > x2[j] and data2[i] < x2[j+1]:
                matrix[j][inds[i]-1] = matrix[j][inds[i]-1] + 1
    return(matrix)  
def select_2D(DirT,DirR,Folder,filename1,filename2,num_bins,num_start,num_select,num_pdb,prefix,Pdbname):               
    file1 = DirR + '/' + filename1
    file2 = DirR + '/' + filename2
    data1 = np.loadtxt(file1)
    data2 = np.loadtxt(file2)
    [P1,x1] = np.histogram(data1,num_bins)
    [P2,x2] = np.histogram(data2,num_bins)
    matrix = histogram_2D(DirR,filename1,filename2,num_bins)
    Flag = max(matrix)
    num_total = len(P1)
    cun = []
    numx1 = []
    numx2 = []
    for i in range(num-pdb):
     if i == 0:
      for j in range(num_bins):
        for k in range(num_bins):          
                matrix[j][k] == Flag
                cun.append(Flag)
                numx1.append(k)
                numx2.append(j)
                break
     else:
       Flag = min(matrix)
       for j in range(num_bins):
        for k in range(num_bins):
              if matrix[j][k] < cun[i-1] and  matrix[j][k] > Flag:
                cunf = Flag
                numx1f = k
                numx2f = j
     cun.append(Flag)
     numx1.append(numx1f)
     numx2.append(numx2f) 
    dx1 = (x1[num_bins-1] - x1[0])/num_bins/100
    dx2 = (x2[num_bins-1] - x2[0])/num_bins/100      
    for i in range(num_pdb):
       N = 0
       if data1[i] > (x1[numx1[i]] - dx1) and data1[i] < (x1[numx1[i]] + dx1) and data2[i] > (x2[numx2[i]] - dx2) and data2[i] < (x2[numx2[i]] + dx2):
         Step = N
         break
       N = N+1
       refix = str(int(N/num_select)  + 1)
       snapshot = str(N%num_select + 1 + num_start)
       print N
       print refix
       print  snapshot 
       os.system("python /home/xc25/AWSEM/awsemmd-amylometer/results_analysis_tools/BuildAllAtomsFromLammps_seq.py  %s/%s%s/dump.lammpstrj %s-P-%s-%s-%s-%s-%s %s/%s%s/%s.seq %s"%(DirT,Folder,refix,prefix,str(cun[i]),filename1,str(x1([numx1[i]] + numx1[i+1])/2.0),filename1,str(x1([numx1[i]] + numx1[i+1])/2.0),DirT,Folder,refix,Pdbname,snapshot)) 

def combine_lastframe(DirT,DirR,Folder,filename,num_total,num_choose,num_folder,term):