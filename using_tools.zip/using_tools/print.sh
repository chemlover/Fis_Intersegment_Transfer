num=$1
for ((i=1; i<=$num; i++)); do
   cd run$i
   awk '{print $19}' energy.log > energy_out
   tail -n +2 energy_out > energy
   awk '{if(min>$1||NR==1){min=$1}} END{print min}' energy  >> ../best.dat
   cd ..
done  
