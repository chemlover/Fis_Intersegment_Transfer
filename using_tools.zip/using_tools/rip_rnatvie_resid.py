import os
import sys
import numpy as np
inputfile = sys.argv[1]
resid = int(sys.argv[2])-1
outputfile = sys.argv[3]
data = np.loadtxt(inputfile)
[m,n] = np.shape(data)
for i in range(m):
    data[i][resid] = 0.0
for i in range(n):
    data[resid][i] = 0.0
np.savetxt(outputfile,data,fmt="%.6f",delimiter=" ")
