import sys
import os
import numpy as np
import math
atom_desc = {'1' : 'P', '2' : 'O5', '3' : 'XXX', '4' : 'XXX', '5' : 'XXX', '6' : 'XXX','7' : 'P_start2','8' : 'XXX','9' : 'XXX','10' : 'P_start1','11' : 'XXX','12' : 'XXX','13' : 'P_end','14' : 'XXX','15' : 'C-Alpha', '16' : 'N', '17' : 'O', '18' : 'C-Beta', '19' : 'H-Beta', '20' : 'C-Prime'}


def get_file_len(filename):
    exeline="wc -l "+filename ;
    stdout=os.popen(exeline).readline();
    stdout=stdout.split()
    return int(stdout[0])

def getline_range(filename, line1, line2):
    assert(line1 <= line2)
    nline=line2-line1+1
    exeline="head -n"+str(line2)+" "+filename+" | tail -n"+str(nline) ;
    #print exeline
    stdout=os.popen(exeline).readlines()
    return stdout

def get_natoms(dump_file):
        line=getline_range(dump_file, 4,4); line=line[0].split()
        natoms=int(line[0])
        return natoms

def get_nline_snapshot(dump_file):
        natoms=get_natoms(dump_file)
        nline=natoms + 9
        return nline

def get_dump_i(dump_file, i):
        nline=get_nline_snapshot(dump_file)
        line_start = 1 + nline*i ; line_end = nline*(i+1)
        dump_part=getline_range(dump_file, line_start, line_end)
        return dump_part

def get_protein_len(filename):
    exeline="wc -l" + filename
    stdout=os.popen(exeline).readline()
    stdout=stdout.split()
    return int(stdout[2]-1)

def get_atoms_dump(dump_lines):
        ca_atoms_dump = []; box = []; A = []
        cb_atoms_dump = []
        o_atoms_dump = []
        p_atoms_dump = []
        o5_atoms_dump=[]
        flag = 'off'
        #print dump_lines
        for l in dump_lines:
                l = l.strip()
                #print l
                if l[:5]=="ITEM:": item = l[6:]
                elif item[:10] == "BOX BOUNDS":
                    box.append(l)
                    l = l.split()
                    A.append([float(l[0]), float(l[1])])
                elif item[:5] == "ATOMS":
                        l = l.split()  ; i_atom = l[0]
                        x = float(l[2]); y = float(l[3]); z = float(l[4])
                        x = (A[0][1] - A[0][0])*x + A[0][0]
                        y = (A[1][1] - A[1][0])*y + A[1][0]
                        z = (A[2][1] - A[2][0])*z + A[2][0]
                        #print atom_desc
                        #print l[1]
                        desc = atom_desc[l[1]]
                        if desc=='C-Alpha':
                                atom_CA = [x,y,z]
                                ca_atoms_dump.append(atom_CA)
                        if desc=='C-Beta':
                                atom = [x,y,z]
                                #print atom
                                cb_atoms_dump.append(atom)
                        if desc=='H-Beta' :
                                cb_atoms_dump.append(atom_CA)
                        if desc=='O' :
                                atom = [x,y,z]
                                o_atoms_dump.append(atom)
                        if desc=='O5' :
                                o5_atom = [x,y,z]
                                o5_atoms_dump.append(o5_atom)
                        #        if flag == "off":
                        #           p_atoms_dump.append(atom)
                        #           flag = "on"
                        if desc=='P' :
                                atom = [x,y,z]
                                p_atoms_dump.append(atom)
                        if desc=='P_start1' or desc== 'P_start2':
                                p_atoms_dump.append(o5_atom)
        return ca_atoms_dump, cb_atoms_dump, o_atoms_dump,p_atoms_dump,o5_atoms_dump

def compute_bind_site(cb_atoms,p_atoms,cutoff):
    dna_length = len(p_atoms)
    p1_atoms  =  p_atoms[0:dna_length/2] 
    p2_atoms  =  p_atoms[dna_length/2:dna_length]
    critia = cutoff**2 
    protein_length = len(cb_atoms)
    site_domain = []
    for j in range(dna_length/2):
        for i in range(protein_length):
          dist1 = (cb_atoms[i][0]-p1_atoms[j][0])**2 + (cb_atoms[i][1]-p1_atoms[j][1])**2 + (cb_atoms[i][2]-p1_atoms[j][2])**2 
          dist2 = (cb_atoms[i][0]-p2_atoms[j][0])**2 + (cb_atoms[i][1]-p2_atoms[j][1])**2 + (cb_atoms[i][2]-p2_atoms[j][2])**2 
          if dist1 <= critia or dist2 <= critia:
             site_domain.append(j+1)
             break
    if len(site_domain) == 0:
           site = 0
    else:
           site = sum(site_domain)/len(site_domain)
    return site

def compute_bind_site_dump(dumpfile,cutoff):
    with open(dumpfile,'r') as fopen:
         lines = fopen.readlines()
    file_len       = get_file_len(dumpfile)
    nline_snapshot = get_nline_snapshot(dumpfile)
    n_snapshot     = file_len / nline_snapshot
    file_bindsite = open("bindc",'w')
    for i in range(n_snapshot):
        i_dump  = get_dump_i(dumpfile, i)
        ca_atoms, cb_atoms, o_atoms,p_atoms,o5_atoms = get_atoms_dump(i_dump)
        site = compute_bind_site(cb_atoms,p_atoms,cutoff)
        file_bindsite.write(str(site)+'\n')
    file_bindsite.close()

def main():
    dumpfile = sys.argv[1]
    cutoff = 6.5
    compute_bind_site_dump(dumpfile,cutoff)

if __name__ == '__main__':
    main()


        
