# /usr/bin/env python3
import os
import string
import re
PdbID = 'T0857'
f = open('%s.excel'%(PdbID),'w')
f.close()
outputfile = '/scratch/xc25/%s.excel'%(PdbID)
for x in range (20):
    y = 0.0
    z = 0.0
    data = ' '
    dir1 = '/scratch/xc25/'+ PdbID + str(x)
    datafile = dir1 + '/wham.dat'
    os.chdir('%s'%(dir1))
    with open(datafile,'r+') as fread:
         for line in fread.readlines():
             line = re.split(r'\s+ ',line)[1]
             line = line.split(' ')[0]
     #        line = line.split(' ')[-5]
     #        line = line.split(' ')[0]
             
             if re.match(r'^\d.\d+',line):
                z = float(line)
             else:
                print('%s'%(line))
             if y < z :
                y = z
    with open(outputfile,'a') as fwrite:
         data+= str(y) + '\n'
         fwrite.writelines(data)
