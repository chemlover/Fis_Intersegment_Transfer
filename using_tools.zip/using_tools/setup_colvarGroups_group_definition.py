import sys
import os
inputfile = sys.argv[1]
data = ''
with open(inputfile,'r') as fopen:
   for line in fopen.readlines():
     if line != '\n':
        if line.split()[0] == 'group':
           data += line + '\n'
with open('group_definitions.txt','w') as fopen:
       fopen.writelines(data)
