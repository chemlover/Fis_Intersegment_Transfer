#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# Written by Shikai Jin on 2018-Nov-7, latest modified on 2019-May-30
# Modified from Mingchen's python2 version calculate_Q_value_dump_pdb.py
# Only work one one chain
# Example in Linux: Python calculate_Q_value_dump_pdb.py test.pdb dump.lammpstrj q_output 0

import argparse
import sys
from Bio.PDB.PDBParser import PDBParser
from math import *


def vector(p1, p2):
    return [p2[0] - p1[0], p2[1] - p1[1], p2[2] - p1[2]]


def vabs(a):
    return sqrt(pow(a[0], 2) + pow(a[1], 2) + pow(a[2], 2))


atom_type = {'1': 'C', '2': 'N', '3': 'O', '4': 'C', '5': 'H', '6': 'C'}

PDB_type = {'1': 'CA', '2': 'N', '3': 'O', '4': 'CB', '5': 'HB', '6': 'C'}
cutoff = 9.5


# For the equation of calculate the Q value read dx.doi.org/10.1021/jp212541y

def compute_Q_dump_pdb(ca_atoms_pdb, ca_atoms_dump, q_type, sigma_sq):
    Q_value = 0
    count_a = 0
    #ca_length = len(ca_atoms_dump)
    if q_type == 1:
        minimum_separation = 4
    elif q_type == 0:
        minimum_separation = 3
    else:
        print("The Q value type %s should be either 1 or 0" % q_type)
        exit()

    pdb_atoms_index = sorted(ca_atoms_pdb)
    #print("pdb_atoms_index is")
    #print(pdb_atoms_index)
    #print(pdb_atoms_index)
    if pdb_atoms_index[-1] > len(ca_atoms_dump):
        sys.exit("The number of ca atoms in dump file cannot fulfill the pdb selection")
        
    ca_atoms_dump_selection = {}
    for residue_index in ca_atoms_pdb.keys():
        ca_atoms_dump_selection[residue_index] = ca_atoms_dump[residue_index]
        

    new_ca_atoms_pdb = {i + 1: ca_atoms_pdb[k] for i, k in enumerate(sorted(ca_atoms_pdb.keys()))}
    new_ca_atoms_dump = {i + 1: ca_atoms_dump_selection[k] for i, k in enumerate(sorted(ca_atoms_dump_selection.keys()))}
    #print("new pdb dictionary is ")
    #print(new_ca_atoms_pdb)
    
    if len(new_ca_atoms_pdb) != len(new_ca_atoms_dump):
        sys.exit("ERROR! The length of pdb is different with dump selection area!")

    for ia in range(1, len(new_ca_atoms_pdb) + 1):
        for ja in range(ia + minimum_separation, len(new_ca_atoms_pdb) + 1):
            if (ia + 1) in new_ca_atoms_pdb and (ja + 1) in new_ca_atoms_pdb:
                rij_N = vabs(vector(new_ca_atoms_pdb[ia + 1], new_ca_atoms_pdb[ja + 1]))
                if q_type == 1 and rij_N >= cutoff:  # What's the function of this line?
                    continue
                rij = vabs(vector(new_ca_atoms_dump[ia], new_ca_atoms_dump[ja]))
                dr = rij - rij_N
                Q_value = Q_value + exp(-dr * dr / (2 * sigma_sq[ja - ia]))
                count_a = count_a + 1
    Q_value = Q_value / count_a
    print(Q_value)
    return Q_value


def calc_sigma_sq(ca_atoms_pdb):
    sigma = []
    sigma_sq = []
    sigma_exp = 0.15

    for i in range(0, len(ca_atoms_pdb) + 1):
        sigma.append((1 + i) ** sigma_exp)
        sigma_sq.append(sigma[-1] * sigma[-1])

    return sigma_sq

def pdb_load(pdb_file, start_text, end_text):
    verbose = True
    if start_text == None:
        start_pair = [None]
    else:
        start_pair = start_text.split(',')
    if end_text == None:
        end_pair = [None]
    else:
        end_pair = end_text.split(',')
        
    if len(start_pair) != len(end_pair):
        sys.exit("The pair number of start point and end point are different")
        
    print("start_pair is")
    print(start_pair)
    print("end_pair is")
    print(end_pair)

    p = PDBParser(PERMISSIVE=1)  # Useful when find errors in PDB
    s = p.get_structure('pdb', pdb_file)
    chains = s[0].get_list()  # Compatible for multiple chains, but only for first model
    chain_id = 0
    ca_atoms_pdb = {}  # A new dictionary to record the C_alpha atom coordinate in pdb file
    pdb_chain_id = []

    for chain in chains:
        for pair_index in range(len(start_pair)):
            chain_id = chain_id + 1
            first_residue = chain.get_unpacked_list()[0]
            last_residue = chain.get_unpacked_list()[-1]
            sequence_id_flag = 0
            if end_pair[pair_index] is None:  # Default end point is last residue
                end = int(last_residue.get_id()[1])
                # print("End value is %s" %end)
                # print(chain[353]['CA'].get_coord())
            else:
                end = int(end_pair[pair_index])
            if start_pair[pair_index] is None:  # Some fxxking pdbs start from -7
                start = int(first_residue.get_id()[1])
            else:
                start = int(start_pair[pair_index])
            for res in chain:
                is_regular_res = (res.has_id('CA') and res.has_id('O')) or (
                    res.get_id()[1] == last_residue and res.has_id(
                        'CA'))  # Some pdbs lack the O atom of the last one residue...interesting
                hetero_flag = res.get_id()[
                    0]  # Get a list for each residue, include hetero flag, sequence identifier and insertion code
                # https://biopython.org/wiki/The_Biopython_Structural_Bioinformatics_FAQ
                if (hetero_flag == ' ' or hetero_flag == 'H_MSE' or hetero_flag == 'H_M3L' or hetero_flag == 'H_CAS') \
                        and is_regular_res:
                    # The residue_id indicates that there is not a hetero_residue or water ('W')
                    sequence_id = res.get_id()[1]
                    # print(sequence_id)
                    if sequence_id_flag == 0:
                        last_sequence_id = sequence_id
                    else:
                        if last_sequence_id != int(sequence_id) - 1:
                            if verbose:
                                print ("WARNING: the residues between %s and %s are lost" % (last_sequence_id, sequence_id))
                            else:
                                pass
                            # Some fxxking pdbs lost residues halfway
                        last_sequence_id = sequence_id
                        # print(res.get_id())
                    if sequence_id >= start and sequence_id <= end:
                        ca_atoms_pdb[sequence_id] = res['CA'].get_coord() # Biopython only gets first CA if occupancy is not 1
                        # print(ca_atoms_pdb.keys())
                        # ca_atoms_pdb.append(res['CA'].get_coord())
                        pdb_chain_id.append(chain_id)
                    sequence_id_flag = sequence_id_flag + 1
        # print(ca_atoms_pdb.keys())
    return ca_atoms_pdb



def lammps_load_and_calc(lammpsdump_file, ca_atoms_pdb, q_type, sigma_sq, output_file, atom_desc):
    ca_atoms_dump = {}
    box_type = []
    box_boundary = []
    with open(lammpsdump_file, 'r') as dump_file:
        for dump_line in dump_file:
            dump_line = dump_line.strip()
            if dump_line[:5] == "ITEM:":
                item = dump_line[6:]  # Then check next line what happened
            else:
                if item == "TIMESTEP":
                    if len(ca_atoms_dump) > 0:
                        #print(ca_atoms_dump.keys())
                        q = compute_Q_dump_pdb(ca_atoms_pdb, ca_atoms_dump, q_type,
                                               sigma_sq)  # Calculate Q online, one frame by one frame
                        with open(output_file, 'a+') as out:
                            out.write(str(round(q, 3)))
                            out.write(' ')
                            out.write('\n')
                            # After calculation for each frame, refresh the three lists
                        ca_atoms_dump = {}
                        box_type = []
                        box_boundary = []

                elif item == "NUMBER OF ATOMS":
                    continue
                elif item[:10] == "BOX BOUNDS":
                    box_type.append(dump_line)
                    dump_line = dump_line.split()
                    box_boundary.append([float(dump_line[0]), float(dump_line[1])])
                elif item[:5] == "ATOMS":
                    dump_line = dump_line.split()
                    i_atom = dump_line[0]
                    x = float(dump_line[2])
                    y = float(dump_line[3])
                    z = float(dump_line[4])
                    x_position = (box_boundary[0][1] - box_boundary[0][0]) * x + box_boundary[0][0]
                    y_position = (box_boundary[1][1] - box_boundary[1][0]) * y + box_boundary[1][0]
                    z_position = (box_boundary[2][1] - box_boundary[2][0]) * z + box_boundary[2][0]
                    desc = atom_desc[dump_line[1]]
                    if desc == 'C-Alpha':
                        residue_id = int((int(i_atom) + 2) / 3)
                        ca_coord = [x_position, y_position, z_position]  # record C_alpha atom coordinate
                        ca_atoms_dump[residue_id] = ca_coord

    q = compute_Q_dump_pdb(ca_atoms_pdb, ca_atoms_dump, q_type, sigma_sq)  # For last frame
    with open(output_file, 'a+') as out:
        out.write(str(round(q, 3)))
        out.write(' ')
        out.write('\n')

    
def main():
    parser = argparse.ArgumentParser(
        description="This script calculates Q value for each chain in a pdb with every frame of a dump.lammpstrj from AWSEM")
    parser.add_argument("PDB_filename", help="The file name of input pdb", type=str)
    parser.add_argument("dump_filename", help="The file name of dump file, usually dump.lammpstrj", type=str)
    parser.add_argument("output_filename", help="The file name of output file", type=str)
    parser.add_argument("q_type", help="The alignment file name", type=int, default=1)
    parser.add_argument("--start",  help="The start residue of protein", type=str)
    parser.add_argument("--end",  help="The end residue of protein", type=str)
    parser.add_argument('--dna', action='store_true', default=False, help='use dna version of atom_desc')
    args = parser.parse_args()
    pdb_file = args.PDB_filename
    dump_file = args.dump_filename
    output_file = args.output_filename
    q_type = args.q_type
    start_text = args.start
    end_text = args.end

    if args.dna == False:
        atom_desc = {'1': 'C-Alpha', '2': 'N', '3': 'O',
                     '4': 'C-Beta', '5': 'H-Beta', '6': 'C-Prime'}
    else:
        atom_desc = {'1': 'N', '2': 'N', '3': 'N', '4': 'N', '5': 'N', '6': 'N','7': 'N',
                     '8': 'N','9': 'N','10': 'N','11': 'N','12': 'N','13': 'N','14': 'N',
                     '15': 'C-Alpha', '16': 'N', '17': 'O', '18': 'C-Beta', '19': 'H-Beta', '20': 'C-Prime'
                     }

    if pdb_file[-4:].lower() != ".pdb":
        print("It must be a pdb file.")
        exit()

    ca_atoms_pdb = pdb_load(pdb_file, start_text, end_text)
    sigma_sq = calc_sigma_sq(ca_atoms_pdb)
    lammps_load_and_calc(dump_file, ca_atoms_pdb, q_type, sigma_sq, output_file, atom_desc)


if __name__ == '__main__':
    main()
