import os
import sys
import numpy as np

def get_position_lowest(filename):
    energy_term = np.loadtxt(filename)
    snapshot = np.argmin(energy_term)
    return snapshot 

def Build_pdb(dumpfile,seqfile,snapshot):
    os.system("python /home/xc25/AWSEM/awsemmd-amylometer/results_analysis_tools/BuildAllAtomsFromLammps_seq.py %s lowest_energy.pdb %s %d"%(dumpfile,seqfile,snapshot)) 

def main():
    print "file should be only digit and one column"
    dumpfile = sys.argv[1]
    seqfile  = sys.argv[2]
    energyfile = sys.argv[3]
    snapshot = get_position_lowest(energyfile)
    Build_pdb(dumpfile,seqfile,snapshot)

if __name__ == '__main__':
    main()                                  
