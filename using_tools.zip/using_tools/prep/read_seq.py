# /usr/bin/env python3
import os
import string
import re
import sys


print('python read_seq.py inpputfile outputfile')
inputfile = sys.argv[1]
outputfile = sys.argv[2]

with open(inputfile,'r') as fopen:
   lines = fopen.readlines()
data = ''
for line in lines:
     if line.split()[0] == 'ATOM':
        Numi = line.split()[5]
        break
with open(outputfile,'a') as fwrite:
   for line in lines:
     if line.split()[0] == 'ATOM':
        if line.split()[4] == 'A':
         if line.split()[2] == 'C':
           if line.split()[3] == 'ALA':
              data += 'A'
           elif line.split()[3] == 'VAL':
              data += 'V'
           elif line.split()[3] == 'LEU':
              data += 'L'
           elif line.split()[3] == 'ILE':
              data += 'I'
           elif line.split()[3] == 'PRO':
              data += 'P'
           elif line.split()[3] == 'PHE':
              data += 'F'
           elif line.split()[3] == 'TRP':
              data += 'W'
           elif line.split()[3] == 'MET':
              data += 'M'
           elif line.split()[3] == 'GLY':
              data += 'G'
           elif line.split()[3] == 'SER':
              data += 'S'
           elif line.split()[3] == 'THR':
              data += 'T'
           elif line.split()[3] == 'CYS':
              data += 'C'
           elif line.split()[3] == 'TYR':
              data += 'Y'
           elif line.split()[3] == 'ASN':
              data += 'N'
           elif line.split()[3] == 'GLN':
              data += 'Q'
           elif line.split()[3] == 'ASP':
              data += 'D'
           elif line.split()[3] == 'GLU':
              data += 'E'
           elif line.split()[3] == 'LYS':
              data += 'K'
           elif line.split()[3] == 'ARG':
              data += 'R'
           elif line.split()[3] == 'HIS':
              data += 'H'
           Numf = line.split()[5] 
   data += '\n'
   line = Numi + ' ' + Numf
   fwrite.writelines(data)
   fwrite.writelines(line)

