# /usr/bin/env python3
import os
import string
import re
import sys


print('python refine_protein.py inpputfile outputfile')
inputfile = sys.argv[1]
outputfile = sys.argv[2]

with open(inputfile,'r') as fopen:
   lines = fopen.readlines()
with open(outputfile,'a') as fwrite:
   for line in lines:
     if line.split()[0] == 'ATOM':
        if line.split()[4] == 'A':
           data = line 
           fwrite.writelines(data)
   data =  'End\n'
   fwrite.writelines(data)




