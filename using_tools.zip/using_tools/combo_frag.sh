#! /bin/bash
PdbID=$1
module load GCC/4.9.3  OpenMPI/1.8.8 Python/2.7.9
python /home/xc25/using_tools/final_test.py database-prefix "$PdbID".fasta 20 2 95 
mv fragsLAMW.mem frag_HO.mem
python /home/xc25/using_tools/prepFragsLAMW_index.py database-prefix "$PdbID".fasta 20 1 
mv fragsLAMW.mem frag_HE.mem
module load GCC/6.4.0  OpenMPI/2.1.2 Python/3.6.4
python /home/xc25/using_tools/hybrid.py $PdbID
module load GCC/4.9.3  OpenMPI/1.8.8 Python/2.7.9

