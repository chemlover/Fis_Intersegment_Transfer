import os 
import sys
inputfile = sys.argv[1]
data = ''
with open(inputfile,'r') as fopen:
    for line in fopen.readlines():
      if len(line.split()) > 2 and line.split()[0] == 'group':
         data += line + '\n'
with open('group_definitions.txt','w') as fwrite:
    fwrite.writelines(data)
