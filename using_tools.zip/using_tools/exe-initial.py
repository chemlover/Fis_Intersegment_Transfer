#!/usr/local/bin/python

import commands, os
import sys
import re
import string

# submit the first job
slurm1 = 'Job1.bat'
cmd = 'sbatch ' + slurm1
print ("Submitting Job1 with command: %s"%(cmd))
(status, jobnum) = commands.getstatusoutput(cmd)
jobnum = jobnum.split()[3]
if (status == 0 ):
    print ("Job1 is %s"%(jobnum))
else:
    print ("Error submitting Job1")

