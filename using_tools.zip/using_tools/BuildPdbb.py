from Bio.PDB.Polypeptide import *
from Bio.PDB.PDBParser import PDBParser
from Bio.PDB import PDBList
from Bio.PDB import PDBIO
import numpy as np
import os
import argparse
seqlist=[]
parser = argparse.ArgumentParser(
    description="This is a python3 script to\
    automatic copy the template file, \
    run simulations")

parser.add_argument("protein", help="The name of the protein for initial start")
parser.add_argument("--movie", default="movie.pdb", help="Name of the simulation outputpdb")
parser.add_argument("--outputpdb", default="refine.pdb", help=" outputpdb")
args = parser.parse_args()
pdbfile = args.protein
moviefile = args.movie
outputfile = args.outputpdb
p = PDBParser(PERMISSIVE=1)
structure = p.get_structure(pdbfile, pdbfile)
for model in structure:
    for chain in model:
        for residue in chain:
            seqlist.append(residue.get_resname())
#print (seqlist)
length = len(seqlist) - 1
flag = 0
order = 0
out = open(outputfile,"w")
with open(moviefile,'r') as fopen:
     for line in fopen.readlines():
         if len(line.split()) > 7:
            if int(line[22:26]) != flag:
               order = (order + 1) % length
               flag = int(line[22:26])
            if seqlist[order] == 'GLY' and line[13:15] == "CB":
               data = "ATOM  " + line[6:13] + "HB  " + seqlist[order] + line[20:81]
            else:
               data = "ATOM  " + line[6:17] + seqlist[order] + line[20:81]
         elif line.split()[0] == "TER":
            data = line[0:17] + seqlist[order] + line[20:27]
         elif line.split()[0] == "ENDMDL":
            data = "END"
         else:
            continue
         out.write(data)
             

