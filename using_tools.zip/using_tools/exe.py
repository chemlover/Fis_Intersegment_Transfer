#!/usr/local/bin/python

import commands, os
import sys
import re
import string

# submit the first job
slurm1 = 'Job1.bat'
cmd = 'sbatch ' + slurm1 
print ("Submitting Job1 with command: %s"%(cmd))
(status, jobnum) = commands.getstatusoutput(cmd)
jobnum = jobnum.split()[3]
if (status == 0 ):
    print ("Job1 is %s"%(jobnum))
else:
    print ("Error submitting Job1")

# submit the second job to be dependent on the first
slurm2 = 'Job2.bat'
cmd = 'sbatch --depend=afterany:' +  jobnum + '  ' + slurm2
print ("Submitting Job2 with command: %s"%(cmd))
(status,jobnum) = commands.getstatusoutput(cmd)
jobnum = jobnum.split()[3]
if (status == 0 ):
    print ("Job2 is %s"%(jobnum))
else:
    print ("Error submitting Job2")


# submit the third job to be dependent on the first
cmd = 'sbatch --depend=afterany:' +  jobnum + '  ' + slurm2
print ("Submitting Job3 with command: %s"%(cmd))
(status,jobnum) = commands.getstatusoutput(cmd)
jobnum = jobnum.split()[3]
if (status == 0 ):
    print ("Job3 is %s"%(jobnum))
else:
    print ("Error submitting Job3")

# submit the fourth job to be dependent on the first
cmd = 'sbatch --depend=afterany:' +  jobnum + '  ' + slurm2
print ("Submitting Job4 with command: %s"%(cmd))
(status,jobnum) = commands.getstatusoutput(cmd)
jobnum = jobnum.split()[3]
if (status == 0 ):
    print ("Job4 is %s"%(jobnum))
else:
    print ("Error submitting Job4")



# submit the third job (a swarm) to be dependent on the second
#cmd = 'swarm -f swarmfile --module blast  --depend=afterany:' + jobnum + '  ' + slurm2
#print ("Submitting swarm job  with command: %s"%(cmd))
#(status,jobnum) = commands.getstatusoutput(cmd)
#jobnum = jobnum.split()[3]
#if (status == 0 ):
#    print("Job3 is %s"%(jobnum))
#else:
#    print("Error submitting Job3")

# submit the third job (a swarm) to be dependent on the second
#cmd = ' swarm -f swarmfile --module blast  --depend=afterany:' + jobnum + '  ' + slurm2
#print ("Submitting swarm job  with command: %s"%(cmd))
#(status,jobnum) = commands.getstatusoutput(cmd)
#jobnum = jobnum.split()[3]
#if (status == 0 ):
#    print("Job4 is %s"%(jobnum))
#else:
#    print("Error submitting Job4")


print ("\nCurrent status:\n")
#show the current status with 'sjobs'
os.system("sjobs")
