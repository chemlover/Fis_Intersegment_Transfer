import os
import sys
import re
import random
import numpy as np
#import pandas
#import prody 
#import matplotlib.pylot as plt
#import set_printoptions
def caculate_mean(DirT,Folder,file,Term,num_total,num):
      filename = DirT + '/' + Folder + str(1) + '/' + file
      with open(filename,'r') as fopen:
         lines = fopen.readlines()
         print Term
         for i in range(19):
           if lines[0].split()[i] == Term:
             print Term
             Key = i
             print  '%d'%(i)
         num_whole = int(lines[-1].split()[0])/1000
         num_start = num_whole - num_total
      sum = 0.0
      for i in range(num):
       inputfile = DirT + '/' + Folder + str(i+1) + '/' + file
       with open(filename,'r') as fopen:
         lines = fopen.readlines()
       for line in lines:
        if line.split()[0] != 'Step':
         if int(line.split()[0]) > num_start*1000:
           sum = sum + float(line.split()[Key])
      mean = sum/num_total/num
      print '%.3f'%(mean)
      return(mean)
def caculate_stardard_deviation(DirT,Folder,file,Term,num_total,num,mean):
      filename = DirT + '/' + Folder + str(1) + '/' + file
      with open(filename,'r') as fopen:
         lines = fopen.readlines()
         for i in range(19):
           if lines[0].split()[i] == Term:
             print(Term)
             Key = i
         num_whole = int(lines[-1].split()[0])/1000
         num_start = num_whole - num_total
      sum = 0.0
      for i in range(num):
       inputfile = DirT + '/' + Folder + str(i+1) + '/' + file
       with open(filename,'r') as fopen:
         lines = fopen.readlines()
       for line in lines:
        if line.split()[0] != 'Step':
         if int(line.split()[0]) > num_start*1000:
           sum = sum + (float(line.split()[Key])-mean)**2
      std = (sum/num_total/num)**(0.5)
      return(std)
def mkdir_download(DirT,Dir1,Dir2,Dir3):
    os.chdir("%s"%(DirT))
    os.system("mkdir %s"%(Dir1))
    os.chdir("%s/%s"%(DirT,Dir1))
    os.system("mkdir %s"%(Dir2))
    os.chdir("%s/%s/%s"%(DirT,Dir1,Dir2))
    os.system("mkdir %s"%(Dir3))
def mkdir_running(DirT,Dir1,Dir2,num):
    os.chdir("%s"%(DirT))
    os.system("mkdir %s"%(Dir1))
    os.chdir("%s/%s"%(DirT,Dir1))
    for i in range(num):
      os.system("mkdir %s%s"%(Dir2,str(i+1)))
def select_values_based_term(DirT,DirR,Folder,file,Term,num,PdbID):
    os.chdir("%s"%(DirR))
    data = ''
    for i in range(num):
      DirS = DirT + '/' + Folder + str(i+1)
      filename = DirT + '/' + Folder + str(i+1) + '/' + file
      with open (filename,'r') as fopen:
        lines = fopen.readlines()
      line = lines[0]
      line_num = len(lines)
      Term_num = len(line)
      #print line 
      for j in range(Term_num):
        if line.split()[j] == Term:
           key = j
           break
      #print key
         #  print Term
         #  print line.split()[j]
      Amount = 0
     # print line_num
      for k in range(line_num/2):
        #print lines[line_num/2 + k]
        if float(lines[line_num/2  + k].split()[key]) < Amount:
           Amount = float(lines[line_num/2  + k].split()[key])
           snapshot = str(line_num/2 +  k - 1)
      #print "python /home/xc25/AWSEM/awsemmd-amylometer/results_analysis_tools/BuildAllAtomsFromLammps_seq.py %s/dump.lammpstrj %s-%s.pdb %s/%s.seq %s"%(DirS,PdbID,str(i+1),DirS,PdbID,snapshot)
      os.system("python /home/xc25/AWSEM/awsemmd-amylometer/results_analysis_tools/BuildAllAtomsFromLammps_seq.py %s/dump.lammpstrj %s-%s.pdb %s/%s.seq %s"%(DirS,PdbID,str(i+1),DirS,PdbID,snapshot))
      data += snapshot + '000,' + str(Amount) + '\n'
    outputfile = DirR + '/' + Term + '.txt' 
    with open(outputfile,'w') as fwrite:
     fwrite.writelines(data)
def generate_matrix(DirR,Name,num):    
   data = ''
   inputfile = DirR + '/output.txt'
   outputfile = DirR + '/heatmap.txt'
   os.chdir("%s"%(DirR))
   for i in range(num):
     for j in range(num):
      #print "python /home/xc25/AWSEM/awsemmd-amylometer/results_analysis_tools/CalcPdbQ.py %s-%s.pdb %s-%s.pdb output.txt"%(Name,str(i+1),Name,str(j+1))
      os.system("python /home/xc25/AWSEM/awsemmd-amylometer/results_analysis_tools/CalcPdbQ.py %s-%s.pdb %s-%s.pdb output.txt"%(Name,str(i+1),Name,str(j+1)))
      with open(inputfile,'r+') as fread:
        lines = fread.readlines()
        data +=  lines[0].split()[0]+ ','
        print(lines[0].split()[0])
        os.system("rm output.txt")
     data += '\n'
   with open(outputfile,'w') as fwrite:
      fwrite.writelines(data)
def Copybackup(Dir1,Dir2,Dir3,Dir4):
   Dir_target = '/scratch/xc25/' + Dir1 + '/' + Dir2
   Dir_mv = '/scratch/xc25/'  + Dir1 + '/' + Dir3 + '/' + Dir4
   os.system("cp -R  %s/* %s/"%(Dir_target,Dir_mv))
   print("cp -R  %s/* %s/"%(Dir_target,Dir_mv))
def revisevelocity(DirT,Temp,PdbID):
   data = ''
   PdbID = PdbID 
   inputfile = DirT + '/' + PdbID + '.in'
   with open (inputfile,'r') as fopen:
     for line in fopen.readlines():
      if line.find("timestep") == 0:
        line = 'timestep 5'  + '\n'
      elif line.find('velocity') == 0:
        y = random.randint(2000, 200000)
        line = 'velocity    all create ' + Temp  + '.0 '+ str(y) + '\n'
      elif line.find("restart ") == 0:
        line = 'restart       100000   ' + PdbID + 'tw.1 ' + PdbID + 'tw.2 ' + '\n'
      data += line
   with open(inputfile,'w') as fwrite:
      fwrite.writelines(data)
def reviseslurm(DirT,Name):
   slurm = DirT + '/slurm'
   data = ''
   with open(slurm,'r') as fopen:
     for line in fopen.readlines():
      if(line.find('#SBATCH --job-name') == 0 ):
         line = '#SBATCH --job-name=' + Name + '\n'
      data += line
   with open(slurm,'w') as fwrite:
     fwrite.writelines(data)
#def select_structure_rg(DirT,DirR,Dirn,num_D,num_Total,num_start,num_skip,rg,delta):
#    os.system()
#    for i in num():
def combine_frame(DirT,DirR,Folder,Pdb_Name,Frame_Name,num_folder,num_start):
    File = DirR + '/' + Frame_Name + '.pdb'
    data = ''
    for i in range(num_folder):
       DirF = DirT + '/' + Folder + str(i+1)
       print DirF 
       os.chdir(DirF)
       os.system("python /home/xc25/AWSEM/awsemmd-amylometer/results_analysis_tools/BuildAllAtomsFromLammps_seq.py  dump.lammpstrj full %s.seq"%(Pdb_Name))
       Clock = 0
       with open( 'full.pdb','r') as fopen:
          for line in fopen.readlines():
             if Clock >= num_start:
                #print num_start
                data += line
                #print Clock
             if line.split()[0] == 'END':
                Clock += 1
    with open(File,'w') as fwrite:
          fwrite.writelines(data) 
def select_1D(DirT,DirR,Folder,filename,num_bins,num_start,num_select,num_pdb,prefix,Pdbname):
    file = DirR + '/' + filename
    cun = []
    num = []
    data = np.loadtxt(file)
    dt = (max(data)-min(data))/num_bins
    [P,x] = np.histogram(data,num_bins)
    Flag = max(P)
    os.chdir(DirR)
    for i in range(num_pdb):
        if i == 0:
          for j in range(num_bins):
            if P[j] == Flag:
                cun.append(P[j])
                num.append(j)
                break
        else:
          Flag = min(P)
          for j in range(num_bins):
              if P[j] < cun[i-1] and P[j] > Flag:
                    Flag = P[j]
                    suspend = j
          num.append(suspend)
          cun.append(Flag)
    for i in range(num_pdb):
        N = 0
        with open(file,'r') as fopen:
          for line in fopen.readlines():
            #print x[num[i]] + dt/2.0 + dt/100
            if (float(line.split()[0]) < (x[num[i]] + dt/2.0 + dt/100)) and (float(line.split()[0]) > (x[num[i]] + dt/2.0 - dt/100)):
               Step = N
               break
            N = N + 1
        refix = str(int(N/num_select)  + 1)
        snapshot = str(N%num_select + 1 + num_start)
        print N
        print refix
        print snapshot
        #print ("python /home/xc25/AWSEM/awsemmd-amylometer/results_analysis_tools/BuildAllAtomsFromLammps_seq.py  %s/%s%s/dump.lammpstrj %s-P-%s-%s-%s %s %s/%s%s/%s.seq"%(DirT,Folder,refix,prefix,str(cun[i]),filename,str(x[num[i]] + dt/2.0),snapshot,DirT,Folder,refix,Pdbname))
        os.system("python /home/xc25/AWSEM/awsemmd-amylometer/results_analysis_tools/BuildAllAtomsFromLammps_seq.py  %s/%s%s/dump.lammpstrj %s-P-%s-%s-%s %s/%s%s/%s.seq %s"%(DirT,Folder,refix,prefix,str(cun[i]),filename,str(x[num[i]] + dt/2.0),DirT,Folder,refix,Pdbname,snapshot))

def compute_distance_end_to_end(DirT,DirR,PdbID):
    Pdbfile = DirT + '/full.pdb'
    os.chdir(DirT)
    os.system("python /home/xc25/AWSEM/awsemmd-amylometer/results_analysis_tools/BuildAllAtomsFromLammps_seq.py  dump.lammpstrj full %s.seq"%(PdbID))
    seqfile = DirT + '/' + PdbID + '.seq'
    with open(seqfile,'r') as fopen:
       line = fopen.readline().split('\n')[0]
    #print line 
    length = len(line)
    outputfile = DirR + '/Dee'
    Flag = 0
    #print length
    data = ''
    with open(Pdbfile,'r') as fopen:
            for line in fopen.readlines():
              #print line
              if line.find('ATOM') == 0:
                    #print
                    if line.split()[5] == str(1) and line.split()[2] == 'CA':
                       CoodCx = float(line[30:37])
                       CoodCy = float(line[38:45])
                       CoodCz = float(line[46:53])
                    elif line.split()[5] == str(length) and line.split()[2] == 'CA':
                       CoodCX = float(line[30:37])
                       CoodCY = float(line[38:45])
                       CoodCZ = float(line[46:53])
                       D = ((CoodCx-CoodCX)*(CoodCx-CoodCX)+(CoodCy-CoodCY)*(CoodCy-CoodCY)+(CoodCz-CoodCZ)*(CoodCz-CoodCZ))**(0.5)
                       data += str(D) + '\n'
                      # print D
                       #print("%s-%s"%(str(l),str(D)))
                 #if line == str(l*1000 + 6001000) + '\n':
                 #   Flag = 1
                 #   l = l+1
                 #else:
                 #   Flag = 0
                # print("%s"%(str(l)))

    data += '\n'
    with open(outputfile,'w') as fwrite:
         fwrite.writelines(data)
def combine_lastframe(DirT,DirR,Folder,filename,num_total,num_choose,num_folder,term):
     outputfile = DirR + '/' + term + '.txt'
     data = '' 
     if term == 'qo' or term == 'qw' or term == 'Dee':
        for i in range(num_folder):
          file = DirT + '/' + Folder + str(i+1)  + '/' + filename
          x = np.loadtxt(file)
          for j in range(num_choose):
            #data += str(x[num_total-num_choose + 1 + j]) + '\n'
             data += str(x[num_total-num_choose  + j]) + '\n'
     elif term == 'rg':
        for i in range(num_folder):
          file = DirT + '/' + Folder + str(i+1)  + '/' + filename
          with open(file,'r') as fopen:
             line = fopen.readlines()[0]
          for j in range(num_choose):
            data += line.split(',')[num_total-num_choose + 1 + j] + '\n'
     elif term == 'Vtotal':
       file = DirT + '/' + Folder + str(1)  + '/' + filename
       with open(file,'r') as fopen:
             line = fopen.readlines()[0]
       for i in range(19):
             if line.split()[i] == term:
                Key = i
       Key = 18
       for i in range(num_folder):
          file = DirT + '/' + Folder + str(i+1)  + '/' + filename
          with open(file,'r') as fopen:
             lines = fopen.readlines()
          for j in range(num_choose):
           # data += lines[num_total-num_choose + 1 + j].split()[Key] + '\n'
             data += lines[num_total-num_choose  + j].split()[Key] + '\n'  
     elif term == 'tc':
       file = DirT + '/' + Folder + str(1)  + '/' + filename
       with open(file,'r') as fopen:
             line = fopen.readlines()[0]
       for i in range(6):
             if line.split()[i] == term:
                Key = i
       Key = 4
       for i in range(num_folder):
          file = DirT + '/' + Folder + str(i+1)  + '/' + filename
          with open(file,'r') as fopen:
             lines = fopen.readlines()
          for j in range(num_choose):
             #print j
             #print lines[num_total-num_choose + 1 + j]
            data += lines[num_total-num_choose + 1 + j].split()[Key] + '\n'
             #data += lines[num_total-num_choose  + j].split()[Key] + '\n' 
     with open(outputfile,'w') as fwrite:
          fwrite.writelines(data)

def histogram_2D(DirR,filename1,filename2,num_bins):
    file1 = DirR + '/' + filename1
    file2 = DirR + '/' + filename2
    data1 = np.loadtxt(file1)
    data2 = np.loadtxt(file2)
    num_totali = len(data1)
    num_totalf = float(str(len(data1)))
    [P1,x1] = np.histogram(data1,num_bins)
    [P2,x2] = np.histogram(data2,num_bins)
    inds1 = np.digitize(data1,x1)
    matrix = np.zeros([num_bins,num_bins])
    for i in range(num_totali):
         for j in range(num_bins):
             if data2[i] > x2[j] and data2[i] < x2[j+1]:
                #print x1
                #print max(data1)
                #print min(data1)
                #if inds1[i] > 50 
                subsit = matrix[j][inds1[i]-2] 
                matrix[j][inds1[i]-2] = subsit + 1
   # np.set_printoptions(threshold='nan')
    #print matrix
    return(matrix)

def select_2D(DirT,DirR,Folder,filename1,filename2,num_bins,num_start,num_select,num_pdb,prefix,Pdbname):
    file1 = DirR + '/' + filename1
    file2 = DirR + '/' + filename2
    data1 = np.loadtxt(file1)
    data2 = np.loadtxt(file2)
    [P1,x1] = np.histogram(data1,num_bins)
    [P2,x2] = np.histogram(data2,num_bins)
    matrix = histogram_2D(DirR,filename1,filename2,num_bins)
    print matrix
    Flag = np.amax(matrix)
    num_total = len(data1)
    cun = []
    numx1 = []
    numx2 = []
    for i in range(num_pdb):
     if i == 0:
      Flag = np.amax(matrix)
      for j in range(num_bins):
        for k in range(num_bins):
              if matrix[j][k] == Flag:
                numx1f = k
                numx2f = j
                break
     else:
       Flag = np.amin(matrix)
       for j in range(num_bins):
        for k in range(num_bins):
              if matrix[j][k] < cun[i-1] and  matrix[j][k] > Flag:
                Flag = matrix[j][k]
              #  print(cunf)
                numx1f = k
                numx2f = j
     cun.append(Flag)
     numx1.append(numx1f)
     numx2.append(numx2f)
     #print Flag
     #print matrix[numx2f][numx1f]
    dx1 = (x1[num_bins-1] - x1[0])/num_bins/2
    dx2 = (x2[num_bins-1] - x2[0])/num_bins/2
    print cun
    print numx1
    print numx2
    for i in range(num_pdb):
       N = 0
       for j in range(num_total):
        #print ("%.3f-%.3f-%.3f",(x1[numx1[i]]/2 + x1[numx1[i]+1]/2 - dx1),data1[j],(x1[numx1[i]]/2 + x1[numx1[i]+1]/2 + dx1))
        if data1[j] > (x1[numx1[i]]/2 + x1[numx1[i]+1]/2 - dx1) and data1[j] < (x1[numx1[i]]/2 + x1[numx1[i]+1]/2 + dx1) and data2[j] > (x2[numx2[i]]/2 + x2[numx2[i]+1]/2 - dx2) and data2[j] < (x2[numx2[i]]/2 + x2[numx2[i]+1]/2 + dx2):
         Step = N
         break
        N = N +1
      # print N
      # print min(data2)
      # print max(data2)
      # print (x2[numx2[i]]/2 + x2[numx2[i]+1]/2 - dx2)
      # print (x2[numx2[i]]/2 + x2[numx2[i]+1]/2 + dx2)
      # print min(data1)
      # print max(data1)
      # print (x1[numx1[i]]/2 + x1[numx1[i]+1]/2 - dx1)
      # print (x1[numx1[i]]/2 + x1[numx1[i]+1]/2 + dx1)
       refix = str(int(Step/num_select)  + 1)
       snapshot = str(Step%num_select + 1 + num_start)
       print N
       print refix
       print snapshot
       d1 = x1[numx1[i]]/2 + x1[numx1[i]+1]/2
       d2 = x2[numx2[i]]/2 + x2[numx2[i]+1]/2 
       #print ("python /home/xc25/AWSEM/awsemmd-amylometer/results_analysis_tools/BuildAllAtomsFromLammps_seq.py  %s/%s%s/dump.lammpstrj %s-P-%s-%s-%s-%s-%s %s/%s%s/%s.seq %s"%(DirT,Folder,refix,prefix,str(cun[i]),filename1,str(x1([numx1[i]] + numx1[i+1])/2.0),filename1,str(x1([numx1[i]] + numx1[i+1])/2.0),DirT,Folder,refix,Pdbname,snapshot))
       os.chdir(DirR)
       os.system("python /home/xc25/AWSEM/awsemmd-amylometer/results_analysis_tools/BuildAllAtomsFromLammps_seq.py  %s/%s%s/dump.lammpstrj %s-P-%s-%s-%s-%s-%s %s/%s%s/%s.seq %s"%(DirT,Folder,refix,prefix,str(cun[i]),filename1,str(d1),filename2,str(d2),DirT,Folder,refix,Pdbname,snapshot))
def combine_structure(DirT,DirR,Folder,num_folder,num_total,num_select,PdbID,name_output):
    #Pdbfile = DirT + '/full.pdb'
    #os.chdir(DirT)
    #os.system("python /home/xc25/AWSEM/awsemmd-amylometer/results_analysis_tools/BuildAllAtomsFromLammps_seq.py  dump.lammpstrj full %s.seq"%(PdbID))
    outputfile = DirR + '/' + name_output + '.pdb'
    seqfile = DirT + '/'+ Folder + str(1) + '/' + PdbID + '.seq'
    lines = ''
    with open(seqfile,'r') as fopen:
       for line in fopen.readline():
         lines += line.split('\n')[0]
    length = len(lines)
    N = 0
    data = ''
    num_start = num_total-num_select 
    for i in range(num_folder):
         os.chdir("%s/%s%s"%(DirT,Folder,str(i+1)))
         #os.system("python /home/xc25/AWSEM/awsemmd-amylometer/results_analysis_tools/BuildAllAtomsFromLammps_seq.py  dump.lammpstrj full %s.seq"%(PdbID))
         Pdbfile = DirT + '/'+ Folder + str(i+1) + '/full-1.pdb'
         N = 0
         with open (Pdbfile,'r') as fopen:
              lines = fopen.readlines()
         for line in lines:
           if N >= num_start + 1:
             data += line
           if line.split()[0] == 'END':
             N += 1
    with open(outputfile,'w') as fwrite:
       fwrite.writelines(data)
def compute_contactmap(DirT,DirR,PdbID,seqlen,n_frame):
    Pdbfile = DirT + '/' +  PdbID + '.pdb'
    #outputfile = DirR + '/' + name_output + '.txt'
    trajectory = prody.parsePDB(Pdbfile)
    contactmp = np.zeros((seqlen,seqlen))
    for snapshot in trajectory.getCoordsets()[np.arange(0,n_frame,1)]:
       #print snapshot
       snap = snapshot[trajectory.getNames()=='CA']
       i = 0  
       for x1,y1,z1 in snap:
           i = i +1 
           j = 0
           for x2,y2,z2 in snap:
                j = j + 1
                if j > i + 1:
                     #print [np.sqrt((x1-x2)**2 + (y1-y2)**2) + (z1-z2)**2]
                     if np.sqrt((x1-x2)**2 + (y1-y2)**2 + (z1-z2)**2)< 6.5:
                         contactmp[i-1][j-1] += 0.0001
                         contactmp[j-1][i-1] = contactmp[i-1][j-1]
    return(contactmp)
def print_matrix(DirR,name_output,seqlen,matrix):
    outputfile = DirR + '/' + name_output + '.txt'
    data = ''
    np.set_printoptions(threshold=np.nan)
    print matrix
    for i in range(seqlen):
       for j in range(seqlen):
          #print matrix[i-1][j-1]
          data += str(matrix[i-1][j-1]) + ','
       data += '\n' 
    with open (outputfile,'w') as fwrite:
       fwrite.writelines(data)
def make_serial_frame_for_stride(DirT,DirR,prefix,num_folder,Folder,seq_name,num_total,num_select): 
    os.chdir("%s"%(DirR))
    num_start = num_total - num_select
    for i in range(num_folder):
       File = DirT + '/' + Folder + str(i+1) + '/dump.lammpstrj'
       seq = DirT + '/' + Folder + str(i+1) + '/' + seq_name + '.seq'
       for j in range(num_select):
         refix = i*num_select + j + 1
         snapshot = num_start + j + 1
         os.system("/home/xc25/AWSEM/awsemmd-amylometer/results_analysis_tools/BuildAllAtomsFromLammps_seqforstride.py %s %s-%s %s %s"%(File,prefix,refix,seq,snapshot)) 
    os.system("rm *.psf") 
def get_value_space(DirT,Folder,file,num_folder,num_total,num_select):
    num_start = num_total - num_select
    qwmax = np.zeros(num_folder)
    qwmin = np.zeros(num_folder)
    qwspace = np.zeros(num_folder) 
    for i in range(num_folder):
        N = 0
        File = DirT + '/'  + Folder + str(i+1) + '/' + file
        with open(File,'r') as fopen:
          lines = fopen.readlines()
        for line in lines:
           if N == num_start:
              qwmax[i] = float(line.split()[0])
              qwmin[i] = float(line.split()[0])
           elif N > num_start:
              if  qwmax[i] < float(line.split()[0]):
                   qwmax[i] = float(line.split()[0])
              if  qwmin[i] > float(line.split()[0]):
                   qwmin[i] = float(line.split()[0])
           N += 1
    qwspace = np.subtract(qwmax,qwmin)
    print qwspace
    spacemax = np.max(qwspace)
    spacemin = np.min(qwspace)
    print spacemax
    print spacemin
def combine_file(pathT,filename,start,num):
    outputfile = pathT + '/' + filename
    data = ''
    for i in range(num):
      if filename != 'qw':
        File = pathT + '/' + filename.split('.')[0] + '-' + str(start+i) + '.' + filename.split('.')[1] 
      else:
        File = pathT + '/' + filename + '-' + str(start+i)
      #print File
      with open (File,'r') as fopen:
           N = 0
           for line in fopen.readlines():
     #        print line
             if N == 1:
                data += line 
             N = 1      
   # print outputfile
    with open (outputfile,'w') as fwrite:
        fwrite.writelines(data)      
def continue_run_restartfile(Path,folder,num_folder,restartfile1,restartfile2,runfile):
    os.chdir(Path)
    for i in range(num_folder):
      os.chdir("%s/%s%d"%(Path,folder,i+1))
      print ("%s/%s%d"%(Path,folder,i+1))
      os.system("rm %s1 "%(restartfile2))
      os.system("rm %s2 "%(restartfile2))
      os.system("cp %s/%s1/tau_pentamer-restart* ./"%(Path,folder))
      os.system("cp %s/%s1/%s  ./"%(Path,folder,runfile))
      os.system("cp %s980000 %s1"%(restartfile1,restartfile2))
      os.system("cp %s990000 %s2"%(restartfile1,restartfile2))   
      os.system("python %s"%(runfile)) 
def combine_difference_file(Path,Folder,num_folder,filename,num_file):
    if filename == 'qw-m' or filename == 'dump.lammpstrj-m':
       Nddl = 1
    elif filename == 'energy.log-m':
       Nddl = 2
    elif filename == 'energyQ.log-m':
       Nddl = 3
    if filename ==  'dump.lammpstrj-m':
       stonemark = 'ITEM: TIMESTEP'
    else:
       stonemark = 'None'
    for i in range(num_folder):
        Pathr = Path + '/' + Folder + str(i+1)
        os.chdir(Pathr)
        data = ''
        print Pathr
        for j in range(num_file):
           N = 0
           Flag = 'off'
           #section = filename + '-' + str(j+1)
           section = filename  + str(j+1)
           with open (section,'r') as fopen:
              for line in fopen.readlines():
                  #print line
                  if stonemark == 'None':
                     N = N + 1
                  elif line.find(stonemark) == 0:
                     N = N + 1 
                  if N > Nddl:
                     Flag = 'on'
                  if Flag == 'on':
                     data += line
        with open(filename,'w') as fwrite:
          fwrite.writelines(data)
def Backup(DirT,DirR,Folder,num_folder):
       for i in range(num_folder):
          os.chdir(DirR)
          os.system("mkdir %s%d"%(Folder,i+1))
          pathT = DirT + '/' + Folder + str(i+1)
          pathR = DirR + '/' + Folder + str(i+1)
          os.system("cp %s/energy* %s/"%(pathT,pathR))
          os.system("cp %s/qw* %s/"%(pathT,pathR))
          os.system("cp %s/wham* %s/"%(pathT,pathR))
          #os.system("cp %s/full.pdb %s/"%(pathT,pathR)) 
          os.system("cp %s/dump.lammpstrj %s/"%(pathT,pathR))
          os.system("cp %s/*m %s/"%(pathT,pathR))
          os.system("cp %s/*.in %s/"%(pathT,pathR))
          os.system("cp %s/*slurm %s/"%(pathT,pathR))
          os.system("cp %s/*.py %s/"%(pathT,pathR))
       os.chdir(DirR)
       os.system("mkdir Basefile")
       os.system("cp -R %s/* ./Basefile/"%(pathT))
       os.chdir("%s/Basefile"%(DirR))
       os.system("rm -rf enengy* qw* wham* *000 *.in *.slurm dump* full*")
def combine_cutoff_rnative(inputfile,len_chaini,outputfile,len_chaino,cutoff,num_chain):
   Matrix_i = np.loadtxt(inputfile)
   L_total = num_chain*len_chaino
   print L_total
   dist = 5.0
   l_delta = len_chaino - len_chaini
   Matrix_o = np.zeros((L_total,L_total))
   if np.amax(Matrix_i) > cutoff:
      print "cutoff is too small"
      exit
   else:
      print "no problem"
   print np.amax(Matrix_i)
   for i in range(num_chain): 
       for j in range(num_chain):
           for ii in range(len_chaino):
               for jj in range(len_chaino):
                   if ii >= l_delta and jj >= l_delta:
                      #print j*len_chaini+jj-l_delta
                      Matrix_o[i*len_chaino+ii][j*len_chaino+jj] = Matrix_i[i*len_chaini+ii-l_delta][j*len_chaini+jj-l_delta]
                      #print j*len_chaino+jj
                   else: 
                      Matrix_o[i*len_chaino+ii][j*len_chaino+jj] = cutoff
   for i in range(L_total):
#      print Matrix_o[i][i]
      if Matrix_o[i][i] == 1000.0:
         Matrix_o[i][i] = 0.0
   for i in range(num_chain):
    for j in range(len_chaino):
     if i != 0:
      for k in range(i):
       if Matrix_o[i*len_chaino+j][k*len_chaino+j] == 1000.0:
             Matrix_o[i*len_chaino+j][k*len_chaino+j] = (i-k)*dist
       for l in range(4):
        if j - l - 1 >= 0:
         if Matrix_o[i*len_chaino+j][k*len_chaino+j-l-1] == 1000.0:
             Matrix_o[i*len_chaino+j][k*len_chaino+j-l-1] = (i-k)*dist
        if j+l+1 <= len_chaino-1:
         if Matrix_o[i*len_chaino+j][k*len_chaino+j+l+1] == 1000.0:
             Matrix_o[i*len_chaino+j][k*len_chaino+j+l+1] = (i-k)*dist
     if i != num_chain-1:
      for k in range(num_chain-1-i):
       if Matrix_o[i*len_chaino+j][(k+i+1)*len_chaino+j] == 1000.0:
             Matrix_o[i*len_chaino+j][(k+i+1)*len_chaino+j] = (k+1)*dist
       for ll in range(4):
        if j - ll -1 >= 0:
         if Matrix_o[i*len_chaino+j][(k+i+1)*len_chaino+j-ll-1] == 1000.0:
            Matrix_o[i*len_chaino+j][(k+i+1)*len_chaino+j-ll-1] = (k+1)*dist 
        if j +ll + 1 <= len_chaino-1:
         if Matrix_o[i*len_chaino+j][(k+i+1)*len_chaino+j+ll+1] == 1000.0:
            Matrix_o[i*len_chaino+j][(k+i+1)*len_chaino+j+ll+1] = (k+1)*dist
  
   print Matrix_o
   print outputfile
   #print "np.savetxt(outputfile,Matrix_o,fmt="%.6f",delimiter= " ")"
   np.savetxt(outputfile,Matrix_o,fmt="%.6f",delimiter= " ")    
def get_homolog_information(frag_HO,frag_HE,outputfile,Dir_homolog,pathT):
    os.system("mkdir %s"%(Dir_homolog))
    with open(frag_HE,'r')  as fopenE:  
      linesE = fopenE.readlines()
    with open(frag_HO,'r')  as fopenO:
      linesO = fopenO.readlines()
    Flag = 0
    data = ''
    for lineO in linesO:
        for lineE in linesE:
           if lineE == '\n' or lineO == '\n' or lineE.split()[0] == lineO.split()[0]:
              Flag = 1
              break
        if Flag == 0 and len(lineO) > 10 :
              print lineO  
              print Flag
              #data+= lineO.split()[0].split('/')[-1].split('.')[0] + ' ' + lineO.split()[1] + ' ' +  lineO.split()[2] + ' ' + lineO.split()[3] + '\n'
              os.system("mv %s/%s* ./%s"%(pathT,lineO.split()[0].split('/')[-1].split('.')[0],Dir_homolog))
        Flag = 0
    with open(outputfile,'w') as fwrite:
         fwrite.writelines(data)
                             
