import os
import sys
#import pandas as pd
import numpy as np
from sklearn.cluster import AgglomerativeClustering
from sklearn.cluster import KMeans
from sklearn.cluster import DBSCAN
from scipy.cluster.hierarchy import linkage
from scipy.cluster.hierarchy import dendrogram
import matplotlib.pyplot as plt
def select_symbol_cluster(matrix,pure_cluster):
  Q = np.zeros(len(pure_cluster))
  for i in range(len(pure_cluster)):
     for j in pure_cluster:
       index1 = int(pure_cluster[i])
       index2 = int(j)
       Q[i] += matrix[index1][index2]
#  print ("PdbID: %d  Cluster_size: %d)"%(int(pure_cluster[np.argmax(Q)]),len(pure_cluster))
  print  pure_cluster[np.argmax(Q)]
filename = sys.argv[1]
n = int(sys.argv[2])
matrix = np.loadtxt(filename)
kmeans = KMeans(n)
kmeans.fit(matrix)
kmeans_pred=kmeans.fit_predict(matrix)
print kmeans_pred
flag = np.zeros(n)
clusters =np.zeros((n,(len(kmeans_pred))))
for i in range(len(kmeans_pred)):
  index1 = int(kmeans_pred[i])
  index2 = int(flag[index1])
  clusters[index1][index2] = i+1
    #   print i
  flag[kmeans_pred[i]] += 1
for i in range(n):
     #  print clusters[i]    
   pure_cluster = []
   for j in range(len(kmeans_pred)):
    if clusters[i][j] != 0:
     pure_cluster.append(clusters[i][j]-1)
   select_symbol_cluster(matrix,pure_cluster)
#linkage_matrix = linkage(matrix,"single")
#print linkage_matrix
#xlabel = np.arange(1,len(matrix)+1)
#dendrogram(linkage_matrix,color_threshold=1,show_leaf_counts=True)
#plt.savefig("cluster.png")
$:plt.show()                 
