# /usr/bin/env python3
import os
import sys
Filename = sys.argv[1]
Path = os.getcwd()
inputfile = Path + '/' + Filename
outputfile = Path + '/ssweight'
print(inputfile)
data = ''
with open(inputfile,'r+') as fopen:
    #line = fopen.readlines()
    ch = fopen.read(1)
    while ch:       
         if ch == 'E':
            data += '0.0 1.0\n'
         elif ch == 'H' or ch == 'G':
            data += '1.0 0.0\n'
         #elif ch == 'C' :
         elif ch != "\n":
            data += '0.0 0.0\n'
         #print ch
         ch = fopen.read(1)
with open(outputfile,'w') as fwrite:
     fwrite.writelines(data)
    

       
