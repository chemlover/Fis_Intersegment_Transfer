import os
import sys
inputfile = sys.argv[1]
num = int(sys.argv[2])
data1 = ''
data2 = ''
with open(inputfile,'r') as fopen:
  for line in fopen.readlines():
   if len(line.split()) != 5:
      data1 += line
      data2 += line
   else:
      if int(line.split()[0]) <= num and int(line.split()[1]) <= num:
        data1 += line
      elif int(line.split()[0]) > num and int(line.split()[1]) > num:
        data2 += str(int(line.split()[0])-num) + ' ' + str(int(line.split()[1])-num) + ' ' +  line.split()[2] + ' ' +  line.split()[3]+ ' ' +  line.split()[4] + '\n'
with open("contactmap_part1","w") as fwrite:
     fwrite.writelines(data1)
with open("contactmap_part2","w") as fwrite:
     fwrite.writelines(data2)

