import sys
import os
import numpy as np
pdbfile = sys.argv[1]
dumpfile = sys.argv[2]
cutoff = 6.5
#atom_desc = {'15' : 'C-Alpha', '16' : 'N', '17' : 'O', '18' : 'C-Beta', '19' : 'H-Beta', '1' : 'P','2':'O5'}
PDB_type = {'1' : 'CA', '2' : 'N', '3' : 'O', '4' : 'CB', '5' : 'HB', '6' : 'C' }
atom_desc = {'1' : 'P', '2' : 'O5', '3' : 'XXX', '4' : 'XXX', '5' : 'XXX', '6' : 'XXX','7' : 'XXX','8' : 'XXX','9' : 'XXX','10' : 'P_start','11' : 'XXX','12' : 'XXX','13' : 'P_end','14' : 'XXX','15' : 'C-Alpha', '16' : 'N', '17' : 'O', '18' : 'C-Beta', '19' : 'H-Beta', '20' : 'C-Prime'}
def get_dna_atoms(data):
    N=0
    coord = []
    for line in data:
        if line != '\n' and line.split()[0] == 'ATOM' and len(line.split()[3]) == 2: 
         #print line
         if N == 0 and line.split()[2] == 'O5\'':     
           #print line     
           x = float(line[30:38])
           y = float(line[38:46])
           z = float(line[46:54])
           atom=[x,y,z]
           #print atom
           coord.append(atom)
           #print line.split()[5]
           #print coord
         if line.split()[2] == 'P':
           x = float(line[30:38])
           y = float(line[38:46])
           z = float(line[46:54])
           #print line.split()[5]
           atom = [x,y,z]
           coord.append(atom)
           N += 1
    #print len(coord)
    dna_atoms_coord = coord 
    return dna_atoms_coord,N

def get_protein_atoms(data):
    N=0
    coord = []
    for line in data:
        if line != '\n' and line.split()[0] == 'ATOM' and len(line.split()[3]) == 3:
         if line.split()[3] == 'GLY' and line.split()[2] == 'CA':
           x = float(line[30:38])
           y = float(line[38:46])
           z = float(line[46:54])
           atom = [x,y,z]
           coord.append(atom)
         if line.split()[2] == 'CB':
           x = float(line[30:38])
           y = float(line[38:46])
           z = float(line[46:54])
           atom = [x,y,z]
           coord.append(atom)
           N += 1
    #print len(coord)
    protein_atoms_coord = coord
    return protein_atoms_coord,N
    #print protein_atoms_coord

def calucate_native_contacts(pdbfile,cutoff):
    with open(pdbfile,'r') as fopen:
        lines = fopen.readlines()
    (p_atoms,p_num) = get_dna_atoms(lines)
    (cb_atoms,cb_num) = get_protein_atoms(lines)
    contacts_list = []
    contacts_num = 0
    critia = cutoff*cutoff
    for i in range(cb_num):
        contact = i + 1
        for j in range(p_num):
            dist = (cb_atoms[i][0]-p_atoms[j][0])**2 + (cb_atoms[i][1]-p_atoms[j][1])**2 + (cb_atoms[i][2]-p_atoms[j][2])**2
            if dist <= critia:
               contacts_list.append(contact)
               contacts_num += 1
               break
    #print contacts_list
    return contacts_list,contacts_num
    #print contacts_list

def get_file_len(filename):
    exeline="wc -l "+filename ;
    stdout=os.popen(exeline).readline();
    stdout=stdout.split()
    return int(stdout[0])

def getline_range(filename, line1, line2):
    assert(line1 <= line2)
    nline=line2-line1+1
    exeline="head -n"+str(line2)+" "+filename+" | tail -n"+str(nline) ;
    #print exeline
    stdout=os.popen(exeline).readlines()
    return stdout

def get_natoms(dump_file):
        line=getline_range(dump_file, 4,4); line=line[0].split()
        natoms=int(line[0])
        return natoms

def get_nline_snapshot(dump_file):
        natoms=get_natoms(dump_file)
        nline=natoms + 9
        return nline

def get_dump_i(dump_file, i):
        nline=get_nline_snapshot(dump_file)
        line_start = 1 + nline*i ; line_end = nline*(i+1)
        dump_part=getline_range(dump_file, line_start, line_end)
        return dump_part

def get_protein_len(filename):
    exeline="wc -l" + filename
    stdout=os.popen(exeline).readline()
    stdout=stdout.split()
    return int(stdout[2]-1)

def get_atoms_dump(dump_lines):
        ca_atoms_dump = []; box = []; A = []
        cb_atoms_dump = []
        o_atoms_dump = []
        p_atoms_dump = []
        o5_atoms_dump=[] 
        flag = 'off'
        #print dump_lines
        for l in dump_lines:
                l = l.strip()
                if l[:5]=="ITEM:": item = l[6:]
                elif item[:10] == "BOX BOUNDS":
                    box.append(l)
                    l = l.split()
                    A.append([float(l[0]), float(l[1])])
                elif item[:5] == "ATOMS":
                        l = l.split()  ; i_atom = l[0]
                        x = float(l[2]); y = float(l[3]); z = float(l[4])
                        x = (A[0][1] - A[0][0])*x + A[0][0]
                        y = (A[1][1] - A[1][0])*y + A[1][0]
                        z = (A[2][1] - A[2][0])*z + A[2][0]
                        #print atom_desc
                        #print l[1]
                        desc = atom_desc[l[1]]
                        if desc=='C-Alpha':
                                atom_CA = [x,y,z]
                                ca_atoms_dump.append(atom_CA)
                        if desc=='C-Beta':
                                atom = [x,y,z]
                                #print atom
                                cb_atoms_dump.append(atom)
                        if desc=='H-Beta' :
                                cb_atoms_dump.append(atom_CA)
                        if desc=='O' :
                                atom = [x,y,z]
                                o_atoms_dump.append(atom)
                        if desc=='O5' :
                                atom = [x,y,z]
                                o5_atoms_dump.append(atom)
                        #        if flag == "off":
                        #           p_atoms_dump.append(atom)
                        #           flag = "on"
                        if desc=='P' or desc=='P_start' or desc=='P_end':
                                atom = [x,y,z]  
                                p_atoms_dump.append(atom) 
        return ca_atoms_dump, cb_atoms_dump, o_atoms_dump,p_atoms_dump,o5_atoms_dump

def compute_Q(cb_atoms,p_atoms,contacts_list,cutoff):
    #print len(cb_atoms)
    dump_contacts = []
    critia = cutoff**2
    for i in range(len(cb_atoms)):
        contact = i + 1
        for j in range(len(p_atoms)):
            dist = (cb_atoms[i][0]-p_atoms[j][0])**2 + (cb_atoms[i][1]-p_atoms[j][1])**2 + (cb_atoms[i][2]-p_atoms[j][2])**2
            if dist <= critia:
               np.append(dump_contacts,contact)
               break
    contact_same = [c for c in dump_contacts if c in contacts_list]
    #print dump_contacts
    #print contacts_list 
    Q = len(contact_same)/float(len(contacts_list))
    #print Q
    return Q

def compute_Q_dump(pdbfile,dumpfile,cutoff):
    contacts_list = calucate_native_contacts(pdbfile,cutoff)
    file_len       = get_file_len(dumpfile)
    nline_snapshot = get_nline_snapshot(dumpfile)
    n_snapshot     = file_len / nline_snapshot
    file_Q = open('Qc','w')
    for i in range(n_snapshot):
        i_dump  = get_dump_i(dumpfile, i)
        ca_atoms, cb_atoms, o_atoms,p_atoms,o5_atoms = get_atoms_dump(i_dump)
        Q = compute_Q(cb_atoms,p_atoms,contacts_list,cutoff)
        file_Q.write(str(Q)+'\n')
    file_Q.close()

def main():
   #with open(dumpfile,'r') as fopen:
   #     lines = fopen.readlines()
   #print "haha"
   #ca_atoms_dump, cb_atoms_dump, o_atoms_dump,p_atoms_dump,o5_atoms_dump=get_atoms_dump(lines)
   #contacts_list = calucate_native_contacts(pdbfile,cutoff)
   #compute_Q(cb_atoms_dump,p_atoms_dump,contacts_list,cutoff)
   #calucate_native_contacts(pdbfile,cutoff)
   #get_protein_atoms(lines)  
   compute_Q_dump(pdbfile,dumpfile,cutoff) 
if __name__ == '__main__':
    main()
 



 

     
