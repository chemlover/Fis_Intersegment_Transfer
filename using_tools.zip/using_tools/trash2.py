import os
import re
import sys
#import numpy as np
from functionbyxun1 import *
PdbID = 'tau_pentamer'
DirT = '/home/xun/Downloads/tau_pentamer-300K'
DirR = '/home/xun/Downloads/tau_pentamer-300K'
Folder = 'tau_pentamer'
num_total = 4000
num_choose = 4000
num_select = 4000
num_folder = 50
num_start = 3999
start = 2
num = 2
Frame_Name = PdbID
Pdb_Name = PdbID
name_output = PdbID
term_list = ['qw','VTotal']
filename_list = ['qw','energy.log']
#for i in range(1):
#   filename = filename_list[i]
#   for j in range(50):
#      pathT = DirT + '/'+ PdbID + str(j+1)
#      combine_file(pathT,filename,start,num)
#for i in range(2):
#    term = term_list[i]
#    filename = filename_list[i]
#    combine_lastframe(DirT,DirR,Folder,filename,num_total,num_choose,num_folder,term)   
num_start = 3999
num_file = 4
#Backup(DirT,DirR,Folder,num_folder)
#filename ='energy.log'
combine_frame(DirT,DirR,Folder,Pdb_Name,Frame_Name,num_folder,num_start)
#combine_difference_file(DirT,Folder,num_folder,filename,num_file)
