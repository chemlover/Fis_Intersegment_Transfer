#!bin/sh
#{
for（i=0;i<20;i++)
{

cd /sratch/xc25/T0829
mkdir T0829$1
cp -rf  *  /sratch/xc25/T0829$1

}

}
