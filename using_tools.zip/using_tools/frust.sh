python /home/xc25/AWSEM/awsemmd-amylometer/frag_mem_tools/Pdb2Gro.py 3gso.pdb 3gso.gro
perl /home/xc25/using_tools/my_groTocharge.pl 3gso.gro > charge_on_residues.dat
cp /home/xc25/frustration/* ./
python ./Buildprepare.py 3gso 3gso
python /home/xc25/protein_dna_tools/setup_colvarGroups_group_definition.py 3gso.in
sed "s/NUMBER/3gso/g" frustration_configuration.in > conf.in
/home/xc25/using_tools/lmp_serial < conf.in
mv  tertiary_frustration.dat  configuration.dat
mv  tertiary_frustration.tcl  configuration.tcl
sed "s/NUMBER/3gso/g" frustration_mutual.in > mutual.in
/home/xc25/using_tools/lmp_serial < mutual.in
mv  tertiary_frustration.dat  mutational.dat
mv  tertiary_frustration.tcl  mutational.tcl
sed "s/NUMBER/3gso/g" frustration_singleresidue.in > singleresidue.in
/home/xc25/using_tools/lmp_serial < singleresidue.in
mv  tertiary_frustration.dat  singleresidue.dat
mv  tertiary_frustration.tcl  singleresidue.tcl

