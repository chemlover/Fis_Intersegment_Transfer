import os
import sys
import numpy as np
# this file is only to add two atom at the begin and end of protein to startup
# Take attention this is fake structure.only to use as start of simulation 
inputfile = sys.argv[1]
outputfile = sys.argv[2]
N_start = np.zeros(3)
O_end = np.zeros(3)
delta = np.zeros(3)
with  open (inputfile,'r') as fopen:
  lines = fopen.readlines()
Flag = 0
for line in lines:
   if line != '\n' and len(line.split()) > 5:
    if line.split()[1] == str(1):
       AA_start = line.split()[3]
    else:
       AA_end = line.split()[3]
    if line.split()[2] == 'N':
     if Flag == 0:
       N_start[0] = float(line[30:38])
       N_start[1] = float(line[38:46])
       N_start[2] = float(line[46:54])
       Flag += 1
       N_line = line
     elif  Flag == 1:   
       delta[0] = N_start[0] -  float(line[30:38])
       delta[1] = N_start[1] -  float(line[38:46])
       delta[2] = N_start[2] -  float(line[46:54])
       Flag += 1
    elif line.split()[2] == 'C':
      O_end[0] = float(line[30:38])
      O_end[1] = float(line[38:46])
      O_end[2] = float(line[46:54])
      O_line = line
data = ''
data += N_line[0:4] + str(1).rjust(7,' ' ) + N_line[11:17] +AA_start + N_line[20:22] + str(1).rjust(4,' ') + str(round(N_start[0] + delta[0],3)).rjust(12,' ') + str(round(N_start[1] + delta[1],3)).rjust(8,' ') + str(round(N_start[2] + delta[2],3)).rjust(8,' ') + N_line[54:81]
for line in lines:
    if line != '\n' and len(line.split()) > 5:
       data += line[0:4] + str(int(line.split()[1])+1).rjust(7,' ' ) + line[11:81]
       O_numx  = int(line.split()[1])+2
       O_numy  = int(line.split()[5])
data += O_line[0:4] + str(O_numx).rjust(7,' ' ) + O_line[11:17]+ AA_end +O_line[20:22] + str(O_numy).rjust(4,' ') + str(round(O_end[0] - delta[0],3)).rjust(12,' ') + str(round(O_end[1] - delta[1],3)).rjust(8,' ') + str(round(O_end[2] - delta[2],3)).rjust(8,' ') + O_line[54:81]      
data += 'END' 
with open(outputfile,'w') as fwrite:
     fwrite.writelines(data)
