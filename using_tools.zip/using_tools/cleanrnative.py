import os
import numpy as np
import sys
inputfile = sys.argv[1]
outputfile = sys.argv[2]
data = np.loadtxt(inputfile)
np.savetxt(outputfile,data,fmt="%.3f",delimiter=" ")
