# submit the second job to be dependent on the first
slurm2 = 'Job2.bat'
cmd = 'sbatch --depend=afterany:' +  jobnum + '  ' + slurm2
print ("Submitting Job2 with command: %s"%(cmd))
(status,jobnum) = commands.getstatusoutput(cmd)
jobnum = jobnum.split()[3]
if (status == 0 ):
    print ("Job2 is %s"%(jobnum))
else:
    print ("Error submitting Job2")

