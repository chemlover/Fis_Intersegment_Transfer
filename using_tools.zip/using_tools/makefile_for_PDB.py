## /usr/bin/env/python3

import os
import string
import re
import parser
PdbID = 'T0729'
whethomo = '0'
Num = '20'
Project_name = PdbID + 'HO'
Dir = '/scratch/xc25/'+ Project_name 
os.chdir("/scratch/xc25/%s"%(Project_name))
os.system("python /home/xc25/AWSEM/awsemmd-amylometer/create_project_tools/PdbCoordsLammps.sh %s %s"%(PdbID,Project_name))
os.system("cp %s.seq /scratch/xc25"%(Project_name))
os.system("mv /scratch/xc25/%s.seq %s.fasta"%(Project_name,Project_name))
Pdbfasta = "/scratch/xc25/" + Project_name + '/' + Pdb + '.fasta'  
with open(Pdbfasta,'r+') as fopen:
   lines = fopen.readlines()
with open(Pdbfasta,'a') as fopen
   data = '>' + PdbID + ':A|PDBID|CHAIN|SEQUENCE\n'
   fopen.writelines(data)
   for line in  lines:
      fopen.writelines(line)
os.system("python /home/xc25/AWSEM/awsemmd-amylometer/create_project_tools/GetCACADistancesFile.py %s native.dat"%(PdbID))
os.system("python /home/xc25/AWSEM/awsemmd-amylometer/create_project_tools/GetCACoordinatesFromPDB.py %s nativecoords.dat"%(PdbID))
os.system("cp /home/xc25/parameter/* /scratch/xc25/%s"%(Project_name))
os.system("cp /home/xc25/runfile/* /scratch/xc25/%s"%(Project_name))
os.system("cp /home/xc25/database/* /scratch/xc25/%s"%(Project_name))
os.syetem("export PATH=$PATH:/home/xc25/ncbi-blast-2.6.0+/bin")
os.system("python /home/xc25/AWSEM/awsemmd-amylometer/frag_mem_tools/prepFragsLAMW_index.py database-prefix %s.fasta %s %s"(PdbID,Num,whethomo))
slurm = Dir + '/' +Project_name +'.slurm'
os.system("mv /scratch/xc25/slurm %s.slurm"%(Project_name))
with open(slurm,'r+') with fopen:
    lines = fopen.readlines()
with open (slurm,'a') with fwrite:
    for line in lines:
      fwrite.writelines(line)
    data = '%s/lmp_serial < %s\n'%(Dir.slurm)
    fwrite.writelines(data)


with open('')
