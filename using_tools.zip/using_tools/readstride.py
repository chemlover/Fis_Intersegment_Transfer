import os
import sys
stridefile = sys.argv[1]
seq = ""
with open(stridefile,"r") as fopen:
     for line in fopen.readlines():
         if len(line) > 50:
            if line[0:3] == "SEQ":
               seqlen = int(line.split()[3])
            elif line[0:3] == "STR":
               seq += line[11:61]
outputfile = sys.argv[2]
#print len(seq)
with open(outputfile,"w") as fwrite:
     fwrite.writelines(seq[0:seqlen])
