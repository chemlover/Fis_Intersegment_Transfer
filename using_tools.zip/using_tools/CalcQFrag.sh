#!/bin/bash
if [ $# -ne 3 ]; then
  echo "Usage: exe PDB log.mem qfrag_out"
  exit
fi
pdb=$1
logmem=$2
qfrag_out=$3
Frag_lib_path=/work/cms16/xc25/opt/script/PDBs/
if [ -e $qfrag_out ];then
   rm $qfrag_out
fi
if [ ! -e $pdb.pdb ]; then
   echo "$pdb.pdb does not exist !"
   exit
fi
path=$Frag_lib_path
while read line;do
  if [ $(echo  "$line" | cut -d'/' -f2 ) == "fraglib" ]; then 
     sub=$line
     namepath=$( echo "$sub" | cut -d' ' -f1 )
     name=$( echo "$namepath" | cut -d'/' -f3)
     i_start=$( echo "$sub" | cut -d' ' -f2 )
     j_start=$( echo "$sub" | cut -d' ' -f3 )
     frag_len=$( echo "$sub" | cut -d' ' -f4 )
     #echo -e "$i_start $frag_len " >> $qfrag_out
     python /home/xc25/using_tools/CalcQFrag.py $pdb $Frag_lib_path $name $i_start $j_start $frag_len >> $qfrag_out
     echo -e "$i_start $frag_len " >> $qfrag_out
     #echo -e "\n" >> $qfrag_out

     
  fi 
done < $logmem
