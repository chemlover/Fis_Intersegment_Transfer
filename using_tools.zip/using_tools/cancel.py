# /usr/bin/env python3

import os
import sys
print("python cancel.py jobid number")
Num  = sys.argv[1]
num = int(sys.argv[2])

for x in range(num):
   y = int(Num)
   os.system("scancel %s"%(str(x+y)))

