import sys
def readasmatrix(file,length):
    temp=open(file,'r')
    Matrix=[ [ 0 for i in range(length) ] for j in range(length) ]
    count=0
    for line in temp:
        strs=line.split()
        for i in range(length):
            Matrix[count][i]=float(strs[i])
        count=count+1           
    temp.close()
    return Matrix


rnative1="rnative1.dat";
rnative2="rnative2.dat";
rnative3="rnative3.dat";

length = int(sys.argv[1])
out = open('rnative.dat','w');

m1=readasmatrix(rnative1,length);
m2=readasmatrix(rnative2,length);
m3=readasmatrix(rnative3,length);
fm = [ [ 0.0 for i in range(length) ] for j in range(length) ];

freq = [ [ 0 for i in range(length) ] for j in range(length) ];

for i in range(length):
	for j in range(length):
		array = [m1[i][j],m2[i][j],m3[i][j]];
		nonzero = 0;
		for k in range(3):
			if array[k]!=0:
				nonzero = nonzero + 1;
		temp = m1[i][j]+m2[i][j]+m3[i][j];
		if nonzero != 0:
			fm[i][j]=temp/nonzero
        	out.write( str(round(fm[i][j], 6)) )
        	out.write( ' ' )
	out.write( '\n' )  
out.close()
