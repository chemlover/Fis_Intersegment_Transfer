#########################################################################
# Author: Charlse.Zhang
# Created Time: Thu 10 Apr 2014 07:44:33 AM CDT
# File Name: buildAllAtom.sh
# Description: 
#########################################################################
#!/bin/bash

comdir="/home/mt42/work/awsemmd_proteinDNA/fis2DNA_3IV5_Go/commons/"
python ~/opt/script/BuildAllAtomsFromLammps_multiChain.py DUMP_FILE_temp300.lammpstrj fisDna_traj.pdb -seq $comdir/buildProtein/fis_two.seq  \
        -dnaPdb $comdir/cg_xtalDna.pdb -dnaBond $comdir/buildDna/dnaBondFromPsf.txt
